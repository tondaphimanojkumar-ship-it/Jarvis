---
name: telnyx-numbers-services-java
description: >-
  Configure voicemail, voice channels, and emergency (E911) services for your
  phone numbers. This skill provides Java SDK examples.
metadata:
  author: telnyx
  product: numbers-services
  language: java
  generated_by: telnyx-openapi-pipeline
---

<!-- Auto-generated from Telnyx OpenAPI specs. Do not edit. -->

# Telnyx Numbers Services - Java

## Installation

```text
<!-- Maven -->
<dependency>
    <groupId>com.telnyx.sdk</groupId>
    <artifactId>telnyx</artifactId>
    <version>6.95.0</version>
</dependency>

// Gradle
implementation("com.telnyx.sdk:telnyx:6.95.0")
```

## Setup

```java
import com.telnyx.sdk.client.TelnyxClient;
import com.telnyx.sdk.client.okhttp.TelnyxOkHttpClient;

// fromEnv() reads TELNYX_API_KEY and TELNYX_PUBLIC_KEY (the public key is required for
// client.webhooks().unwrap() — webhook verification)
TelnyxClient client = TelnyxOkHttpClient.fromEnv();
```

All examples below assume `client` is already initialized as shown above.

## Error Handling

All API calls can fail with network errors, rate limits (429), validation errors (422),
or authentication errors (401). Always handle errors in production code:

```java
import com.telnyx.sdk.errors.TelnyxServiceException;

try {
    var result = client.messages().send(params);
} catch (TelnyxServiceException e) {
    System.err.println("API error " + e.statusCode() + ": " + e.getMessage());
    if (e.statusCode() == 422) {
        System.err.println("Validation error — check required fields and formats");
    } else if (e.statusCode() == 429) {
        // Rate limited — wait, then retry the request (bounded exponential backoff)
        Thread.sleep(1000);
        // ...retry the call here (give up after a few attempts)
    }
    throw e; // Re-throw: a failed request must never look like success to the caller
}
```

Common error codes: `401` invalid API key, `403` insufficient permissions,
`404` resource not found, `422` validation error (check field formats),
`429` rate limited (retry with exponential backoff).

## Important Notes

- **Pagination:** List methods return a page. Use `.autoPager()` for automatic iteration: `for (var item : page.autoPager()) { ... }`. For manual control, use `.hasNextPage()` and `.nextPage()`.

## List your voice channels for non-US zones

Returns the non-US voice channels for your account. voice channels allow you to use Channel Billing for calls to your Telnyx phone numbers. Please check the Telnyx Support Articles section for full information and examples of how to utilize Channel Billing.

`GET /channel_zones`

```java
import com.telnyx.sdk.models.channelzones.ChannelZoneListPage;
import com.telnyx.sdk.models.channelzones.ChannelZoneListParams;

ChannelZoneListPage page = client.channelZones().list();
```

Returns: `channels` (int64), `countries` (array[string]), `created_at` (string), `id` (string), `name` (string), `record_type` (enum: channel_zone), `updated_at` (string)

## Update voice channels for non-US Zones

Update the number of Voice Channels for the Non-US Zones. This allows your account to handle multiple simultaneous inbound calls to Non-US numbers. Use this endpoint to increase or decrease your capacity based on expected call volume.

`PUT /channel_zones/{channel_zone_id}` — Required: `channels`

```java
import com.telnyx.sdk.models.channelzones.ChannelZoneUpdateParams;
import com.telnyx.sdk.models.channelzones.ChannelZoneUpdateResponse;

ChannelZoneUpdateParams params = ChannelZoneUpdateParams.builder()
    .channelZoneId("550e8400-e29b-41d4-a716-446655440000")
    .channels(0L)
    .build();
ChannelZoneUpdateResponse channelZone = client.channelZones().update(params);
```

Returns: `channels` (int64), `countries` (array[string]), `created_at` (string), `id` (string), `name` (string), `record_type` (enum: channel_zone), `updated_at` (string)

## List dynamic emergency addresses

Returns the dynamic emergency addresses according to filters

`GET /dynamic_emergency_addresses`

```java
import com.telnyx.sdk.models.dynamicemergencyaddresses.DynamicEmergencyAddressListPage;
import com.telnyx.sdk.models.dynamicemergencyaddresses.DynamicEmergencyAddressListParams;

DynamicEmergencyAddressListPage page = client.dynamicEmergencyAddresses().list();
```

Returns: `administrative_area` (string), `country_code` (enum: US, CA, PR), `created_at` (string), `extended_address` (string), `house_number` (string), `house_suffix` (string), `id` (string), `locality` (string), `postal_code` (string), `record_type` (string), `sip_geolocation_id` (string), `status` (enum: pending, activated, rejected), `street_name` (string), `street_post_directional` (string), `street_pre_directional` (string), `street_suffix` (string), `updated_at` (string)

## Create a dynamic emergency address.

Creates a dynamic emergency address, the validated physical location used when provisioning dynamic emergency endpoints.

`POST /dynamic_emergency_addresses` — Required: `house_number`, `street_name`, `locality`, `administrative_area`, `postal_code`, `country_code`

Optional: `created_at` (string), `extended_address` (string), `house_suffix` (string), `id` (string), `record_type` (string), `sip_geolocation_id` (string), `status` (enum: pending, activated, rejected), `street_post_directional` (string), `street_pre_directional` (string), `street_suffix` (string), `updated_at` (string)

```java
import com.telnyx.sdk.models.dynamicemergencyaddresses.DynamicEmergencyAddress;
import com.telnyx.sdk.models.dynamicemergencyaddresses.DynamicEmergencyAddressCreateResponse;

DynamicEmergencyAddress params = DynamicEmergencyAddress.builder()
    .administrativeArea("TX")
    .countryCode(DynamicEmergencyAddress.CountryCode.US)
    .houseNumber("600")
    .locality("Austin")
    .postalCode("78701")
    .streetName("Congress")
    .build();
DynamicEmergencyAddressCreateResponse dynamicEmergencyAddress = client.dynamicEmergencyAddresses().create(params);
```

Returns: `administrative_area` (string), `country_code` (enum: US, CA, PR), `created_at` (string), `extended_address` (string), `house_number` (string), `house_suffix` (string), `id` (string), `locality` (string), `postal_code` (string), `record_type` (string), `sip_geolocation_id` (string), `status` (enum: pending, activated, rejected), `street_name` (string), `street_post_directional` (string), `street_pre_directional` (string), `street_suffix` (string), `updated_at` (string)

## Get a dynamic emergency address

Returns the dynamic emergency address based on the ID provided

`GET /dynamic_emergency_addresses/{id}`

```java
import com.telnyx.sdk.models.dynamicemergencyaddresses.DynamicEmergencyAddressRetrieveParams;
import com.telnyx.sdk.models.dynamicemergencyaddresses.DynamicEmergencyAddressRetrieveResponse;

DynamicEmergencyAddressRetrieveResponse dynamicEmergencyAddress = client.dynamicEmergencyAddresses().retrieve("182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e");
```

Returns: `administrative_area` (string), `country_code` (enum: US, CA, PR), `created_at` (string), `extended_address` (string), `house_number` (string), `house_suffix` (string), `id` (string), `locality` (string), `postal_code` (string), `record_type` (string), `sip_geolocation_id` (string), `status` (enum: pending, activated, rejected), `street_name` (string), `street_post_directional` (string), `street_pre_directional` (string), `street_suffix` (string), `updated_at` (string)

## Delete a dynamic emergency address

Deletes the dynamic emergency address based on the ID provided

`DELETE /dynamic_emergency_addresses/{id}`

```java
import com.telnyx.sdk.models.dynamicemergencyaddresses.DynamicEmergencyAddressDeleteParams;
import com.telnyx.sdk.models.dynamicemergencyaddresses.DynamicEmergencyAddressDeleteResponse;

DynamicEmergencyAddressDeleteResponse dynamicEmergencyAddress = client.dynamicEmergencyAddresses().delete("182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e");
```

Returns: `administrative_area` (string), `country_code` (enum: US, CA, PR), `created_at` (string), `extended_address` (string), `house_number` (string), `house_suffix` (string), `id` (string), `locality` (string), `postal_code` (string), `record_type` (string), `sip_geolocation_id` (string), `status` (enum: pending, activated, rejected), `street_name` (string), `street_post_directional` (string), `street_pre_directional` (string), `street_suffix` (string), `updated_at` (string)

## List dynamic emergency endpoints

Returns the dynamic emergency endpoints according to filters

`GET /dynamic_emergency_endpoints`

```java
import com.telnyx.sdk.models.dynamicemergencyendpoints.DynamicEmergencyEndpointListPage;
import com.telnyx.sdk.models.dynamicemergencyendpoints.DynamicEmergencyEndpointListParams;

DynamicEmergencyEndpointListPage page = client.dynamicEmergencyEndpoints().list();
```

Returns: `callback_number` (string), `caller_name` (string), `created_at` (string), `dynamic_emergency_address_id` (string), `id` (string), `record_type` (string), `sip_from_id` (string), `status` (enum: pending, activated, rejected), `updated_at` (string)

## Create a dynamic emergency endpoint.

Creates a dynamic emergency endpoint, associating a callback number and location with a device for emergency calling.

`POST /dynamic_emergency_endpoints` — Required: `dynamic_emergency_address_id`, `callback_number`, `caller_name`

Optional: `created_at` (string), `id` (string), `record_type` (string), `sip_from_id` (string), `status` (enum: pending, activated, rejected), `updated_at` (string)

```java
import com.telnyx.sdk.models.dynamicemergencyendpoints.DynamicEmergencyEndpoint;
import com.telnyx.sdk.models.dynamicemergencyendpoints.DynamicEmergencyEndpointCreateResponse;

DynamicEmergencyEndpoint params = DynamicEmergencyEndpoint.builder()
    .callbackNumber("+13125550000")
    .callerName("Jane Doe Desk Phone")
    .dynamicEmergencyAddressId("0ccc7b54-4df3-4bca-a65a-3da1ecc777f0")
    .build();
DynamicEmergencyEndpointCreateResponse dynamicEmergencyEndpoint = client.dynamicEmergencyEndpoints().create(params);
```

Returns: `callback_number` (string), `caller_name` (string), `created_at` (string), `dynamic_emergency_address_id` (string), `id` (string), `record_type` (string), `sip_from_id` (string), `status` (enum: pending, activated, rejected), `updated_at` (string)

## Get a dynamic emergency endpoint

Returns the dynamic emergency endpoint based on the ID provided

`GET /dynamic_emergency_endpoints/{id}`

```java
import com.telnyx.sdk.models.dynamicemergencyendpoints.DynamicEmergencyEndpointRetrieveParams;
import com.telnyx.sdk.models.dynamicemergencyendpoints.DynamicEmergencyEndpointRetrieveResponse;

DynamicEmergencyEndpointRetrieveResponse dynamicEmergencyEndpoint = client.dynamicEmergencyEndpoints().retrieve("182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e");
```

Returns: `callback_number` (string), `caller_name` (string), `created_at` (string), `dynamic_emergency_address_id` (string), `id` (string), `record_type` (string), `sip_from_id` (string), `status` (enum: pending, activated, rejected), `updated_at` (string)

## Delete a dynamic emergency endpoint

Deletes the dynamic emergency endpoint based on the ID provided

`DELETE /dynamic_emergency_endpoints/{id}`

```java
import com.telnyx.sdk.models.dynamicemergencyendpoints.DynamicEmergencyEndpointDeleteParams;
import com.telnyx.sdk.models.dynamicemergencyendpoints.DynamicEmergencyEndpointDeleteResponse;

DynamicEmergencyEndpointDeleteResponse dynamicEmergencyEndpoint = client.dynamicEmergencyEndpoints().delete("182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e");
```

Returns: `callback_number` (string), `caller_name` (string), `created_at` (string), `dynamic_emergency_address_id` (string), `id` (string), `record_type` (string), `sip_from_id` (string), `status` (enum: pending, activated, rejected), `updated_at` (string)

## List your voice channels for US Zone

Returns the US Zone voice channels for your account. voice channels allows you to use Channel Billing for calls to your Telnyx phone numbers. Please check the Telnyx Support Articles section for full information and examples of how to utilize Channel Billing.

`GET /inbound_channels`

```java
import com.telnyx.sdk.models.inboundchannels.InboundChannelListParams;
import com.telnyx.sdk.models.inboundchannels.InboundChannelListResponse;

InboundChannelListResponse inboundChannels = client.inboundChannels().list();
```

Returns: `channels` (integer), `record_type` (string)

## Update voice channels for US Zone

Update the number of Voice Channels for the US Zone. This allows your account to handle multiple simultaneous inbound calls to US numbers. Use this endpoint to increase or decrease your capacity based on expected call volume.

`PATCH /inbound_channels` — Required: `channels`

```java
import com.telnyx.sdk.models.inboundchannels.InboundChannelUpdateParams;
import com.telnyx.sdk.models.inboundchannels.InboundChannelUpdateResponse;

InboundChannelUpdateParams params = InboundChannelUpdateParams.builder()
    .channels(7L)
    .build();
InboundChannelUpdateResponse inboundChannel = client.inboundChannels().update(params);
```

Returns: `channels` (integer), `record_type` (string)

## List All Numbers using Channel Billing

Retrieve a list of all phone numbers using Channel Billing, grouped by Zone.

`GET /list`

```java
import com.telnyx.sdk.models.list.ListRetrieveAllParams;
import com.telnyx.sdk.models.list.ListRetrieveAllResponse;

ListRetrieveAllResponse response = client.list().retrieveAll();
```

Returns: `number_of_channels` (integer), `numbers` (array[object]), `zone_id` (string), `zone_name` (string)

## List Numbers using Channel Billing for a specific Zone

Retrieve a list of phone numbers using Channel Billing for a specific Zone.

`GET /list/{channel_zone_id}`

```java
import com.telnyx.sdk.models.list.ListRetrieveByZoneParams;
import com.telnyx.sdk.models.list.ListRetrieveByZoneResponse;

ListRetrieveByZoneResponse response = client.list().retrieveByZone("550e8400-e29b-41d4-a716-446655440000");
```

Returns: `number_of_channels` (integer), `numbers` (array[object]), `zone_id` (string), `zone_name` (string)

## Get voicemail

Returns the voicemail settings for a phone number

`GET /phone_numbers/{phone_number_id}/voicemail`

```java
import com.telnyx.sdk.models.phonenumbers.voicemail.VoicemailRetrieveParams;
import com.telnyx.sdk.models.phonenumbers.voicemail.VoicemailRetrieveResponse;

VoicemailRetrieveResponse voicemail = client.phoneNumbers().voicemail().retrieve("123455678900");
```

Returns: `enabled` (boolean), `greeting` (object), `pin` (string)

## Create voicemail

Create voicemail settings for a phone number. You can also configure a custom greeting by setting the `greeting` object: use `mode` `custom_greeting` together with a `media_name` that points to an audio file uploaded through the Media Storage API, or `mode` `default` to use the standard system greeting.

`POST /phone_numbers/{phone_number_id}/voicemail`

Optional: `enabled` (boolean), `greeting` (object), `pin` (string)

```java
import com.telnyx.sdk.models.phonenumbers.voicemail.VoicemailCreateParams;
import com.telnyx.sdk.models.phonenumbers.voicemail.VoicemailCreateResponse;
import com.telnyx.sdk.models.phonenumbers.voicemail.VoicemailRequest;

VoicemailCreateParams params = VoicemailCreateParams.builder()
    .phoneNumberId("123455678900")
    .voicemailRequest(VoicemailRequest.builder().build())
    .build();
VoicemailCreateResponse voicemail = client.phoneNumbers().voicemail().create(params);
```

Returns: `enabled` (boolean), `greeting` (object), `pin` (string)

## Update voicemail

Update voicemail settings for a phone number. You can also configure a custom greeting by setting the `greeting` object: use `mode` `custom_greeting` together with a `media_name` that points to an audio file uploaded through the Media Storage API, or `mode` `default` to use the standard system greeting.

`PATCH /phone_numbers/{phone_number_id}/voicemail`

Optional: `enabled` (boolean), `greeting` (object), `pin` (string)

```java
import com.telnyx.sdk.models.phonenumbers.voicemail.VoicemailRequest;
import com.telnyx.sdk.models.phonenumbers.voicemail.VoicemailUpdateParams;
import com.telnyx.sdk.models.phonenumbers.voicemail.VoicemailUpdateResponse;

VoicemailUpdateParams params = VoicemailUpdateParams.builder()
    .phoneNumberId("123455678900")
    .voicemailRequest(VoicemailRequest.builder().build())
    .build();
VoicemailUpdateResponse voicemail = client.phoneNumbers().voicemail().update(params);
```

Returns: `enabled` (boolean), `greeting` (object), `pin` (string)
