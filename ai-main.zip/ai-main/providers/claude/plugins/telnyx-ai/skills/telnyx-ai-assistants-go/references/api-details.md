# AI Assistants (Go) — API Details

<!-- Auto-generated reference file. Do not edit. -->

## Table of Contents

- [Response Schemas](#response-schemas)
- [Optional Parameters](#optional-parameters)

## Response Schemas

**Returned by:** List assistants, Create an assistant, Import assistants from external provider, Get an assistant, Update an assistant, Clone Assistant, Restore an assistant, Get all versions of an assistant, Get a specific assistant version, Update a specific assistant version, Promote an assistant version to main

| Field | Type |
|-------|------|
| `a2a_agents` | array[object] |
| `avatar_settings` | object |
| `conversation_flow` | object |
| `created_at` | date-time |
| `delegation_settings` | object |
| `description` | string |
| `dynamic_variables` | object |
| `dynamic_variables_webhook_timeout_ms` | integer |
| `dynamic_variables_webhook_url` | string |
| `enabled_features` | array[string] |
| `external_llm` | object |
| `fallback_config` | object |
| `greeting` | string |
| `id` | string |
| `import_metadata` | object |
| `insight_settings` | object |
| `instructions` | string |
| `integrations` | array[object] |
| `interruption_settings` | object |
| `llm_api_key_ref` | string |
| `mcp_servers` | array[object] |
| `messaging_settings` | object |
| `model` | string |
| `name` | string |
| `observability_settings` | object |
| `post_conversation_settings` | object |
| `privacy_settings` | object |
| `related_mission_ids` | array[string] |
| `tags` | array[string] |
| `telephony_settings` | object |
| `tools` | array[object] |
| `transcription` | object |
| `version_created_at` | date-time |
| `version_id` | string |
| `version_name` | string |
| `voice_settings` | object |
| `websocket_settings` | object |
| `widget_settings` | object |

**Returned by:** List deleted assistants, Get a deleted assistant

| Field | Type |
|-------|------|
| `a2a_agents` | array[object] |
| `avatar_settings` | object |
| `conversation_flow` | object |
| `created_at` | date-time |
| `delegation_settings` | object |
| `deleted_at` | date-time |
| `description` | string |
| `dynamic_variables` | object |
| `dynamic_variables_webhook_timeout_ms` | integer |
| `dynamic_variables_webhook_url` | string |
| `enabled_features` | array[string] |
| `external_llm` | object |
| `fallback_config` | object |
| `greeting` | string |
| `id` | string |
| `import_metadata` | object |
| `insight_settings` | object |
| `instructions` | string |
| `integrations` | array[object] |
| `interruption_settings` | object |
| `llm_api_key_ref` | string |
| `mcp_servers` | array[object] |
| `messaging_settings` | object |
| `model` | string |
| `name` | string |
| `observability_settings` | object |
| `permanently_deleted_at` | date-time |
| `post_conversation_settings` | object |
| `privacy_settings` | object |
| `related_mission_ids` | array[string] |
| `tags` | array[string] |
| `telephony_settings` | object |
| `tools` | array[object] |
| `transcription` | object |
| `version_created_at` | date-time |
| `version_id` | string |
| `version_name` | string |
| `voice_settings` | object |
| `websocket_settings` | object |
| `widget_settings` | object |

**Returned by:** Get All Tags, Add Assistant Tag, Remove Assistant Tag

| Field | Type |
|-------|------|
| `tags` | array[string] |

**Returned by:** List assistant tests with pagination, Create a new assistant test, Get assistant test by ID, Update an assistant test

| Field | Type |
|-------|------|
| `created_at` | date-time |
| `description` | string |
| `destination` | string |
| `instructions` | string |
| `max_duration_seconds` | integer |
| `name` | string |
| `rubric` | array[object] |
| `telnyx_conversation_channel` | object |
| `test_id` | uuid |
| `test_suite` | string |

**Returned by:** Get all test suite names

| Field | Type |
|-------|------|
| `data` | array[string] |

**Returned by:** Get test suite run history, Get test run history for a specific test, Trigger a manual test run, Get specific test run details

| Field | Type |
|-------|------|
| `completed_at` | date-time |
| `conversation_id` | string |
| `conversation_insights_id` | string |
| `created_at` | date-time |
| `detail_status` | array[object] |
| `logs` | string |
| `run_id` | uuid |
| `status` | enum: pending, starting, running, passed, failed, error |
| `test_id` | uuid |
| `test_suite_run_id` | uuid |
| `triggered_by` | string |
| `updated_at` | date-time |

**Returned by:** Delete an assistant

| Field | Type |
|-------|------|
| `deleted` | boolean |
| `id` | string |
| `object` | string |

**Returned by:** Get Canary Deploy, Create Canary Deploy, Update Canary Deploy

| Field | Type |
|-------|------|
| `assistant_id` | string |
| `created_at` | date-time |
| `rules` | array[object] |
| `updated_at` | date-time |

**Returned by:** Assistant Chat

| Field | Type |
|-------|------|
| `content` | string |

**Returned by:** Assistant Sms Chat

| Field | Type |
|-------|------|
| `conversation_id` | string |

**Returned by:** Assistant WhatsApp Chat

| Field | Type |
|-------|------|
| `conversation_id` | string |
| `message_id` | string |

**Returned by:** List scheduled events

| Field | Type |
|-------|------|
| `data` | array[object] |
| `meta` | object |

**Returned by:** Test Assistant Tool

| Field | Type |
|-------|------|
| `content_type` | string |
| `request` | object |
| `response` | string |
| `status_code` | integer |
| `success` | boolean |

**Returned by:** Create MCP Server, Get MCP Server, Update MCP Server

| Field | Type |
|-------|------|
| `allowed_tools` | array \| null |
| `api_key_ref` | string \| null |
| `created_at` | date-time |
| `id` | string |
| `name` | string |
| `type` | string |
| `url` | string |

**Returned by:** List Tools, Create Tool, Get Tool, Update Tool

| Field | Type |
|-------|------|
| `created_at` | string |
| `display_name` | string |
| `id` | string |
| `timeout_ms` | integer |
| `tool_definition` | object |
| `type` | string |

## Optional Parameters

### Create an assistant — `client.AI.Assistants.New()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `Model` | string | ID of the model to use when `external_llm` is not set. |
| `Tools` | array[object] | Deprecated for new integrations. |
| `McpServers` | array[object] | MCP servers attached to the assistant. |
| `A2aAgents` | array[object] | A2A agents this assistant can delegate to. |
| `ToolIds` | array[string] | IDs of shared tools to attach to the assistant. |
| `Description` | string |  |
| `Greeting` | string | Text that the assistant will use to start the conversation. |
| `LlmApiKeyRef` | string | This is only needed when using third-party inference providers selected by `m... |
| `ExternalLlm` | object |  |
| `FallbackConfig` | object |  |
| `VoiceSettings` | object |  |
| `AvatarSettings` | object | **Beta:** Optional avatar configuration for supported realtime browser conver... |
| `Transcription` | object |  |
| `TelephonySettings` | object |  |
| `MessagingSettings` | object |  |
| `EnabledFeatures` | array[string] |  |
| `InsightSettings` | object |  |
| `PrivacySettings` | object |  |
| `DynamicVariablesWebhookUrl` | string (URL) | If `dynamic_variables_webhook_url` is set, Telnyx sends a POST request to thi... |
| `DynamicVariablesWebhookTimeoutMs` | integer | Timeout in milliseconds for the dynamic variables webhook. |
| `DynamicVariables` | object | Map of dynamic variables and their default values |
| `WidgetSettings` | object | Configuration settings for the assistant's web widget. |
| `InterruptionSettings` | object | Settings for interruptions and how the assistant decides the user has finishe... |
| `Integrations` | array[object] | Connected integrations attached to the assistant. |
| `ObservabilitySettings` | object |  |
| `Tags` | array[string] | Tags associated with the assistant. |
| `PostConversationSettings` | object | Configuration for post-conversation processing. |
| `DelegationSettings` | object | Splits the conversation between a frontend model that talks to the caller and... |
| `WebsocketSettings` | object | Streams conversation and telephony events to a WebSocket server you host, and... |
| `ConversationFlow` | object | Conversation flow as supplied by API clients (create / update). |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Import assistants from external provider — `client.AI.Assistants.Imports()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `ImportIds` | array[string] | Optional list of assistant IDs to import from the external provider. |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Create a new assistant test — `client.AI.Assistants.Tests.New()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `Description` | string | Optional detailed description of what this test evaluates and its purpose. |
| `TelnyxConversationChannel` | object | The communication channel through which the test will be conducted. |
| `MaxDurationSeconds` | integer | Maximum duration in seconds that the test conversation should run before timi... |
| `TestSuite` | string | Optional test suite name to group related tests together. |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Trigger test suite execution — `client.AI.Assistants.Tests.TestSuites.Runs.Trigger()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `DestinationVersionId` | string (UUID) | Optional assistant version ID to use for all test runs in this suite. |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Update an assistant test — `client.AI.Assistants.Tests.Update()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `Name` | string | Updated name for the assistant test. |
| `Description` | string | Updated description of the test's purpose and evaluation criteria. |
| `TelnyxConversationChannel` | enum (phone_call, web_call, sms_chat, web_chat) |  |
| `Destination` | string | Updated target destination for test conversations. |
| `MaxDurationSeconds` | integer | Updated maximum test duration in seconds. |
| `TestSuite` | string | Updated test suite assignment for better organization. |
| `Instructions` | string | Updated test scenario instructions and objectives. |
| `Rubric` | array[object] | Updated evaluation criteria for assessing assistant performance. |

### Trigger a manual test run — `client.AI.Assistants.Tests.Runs.Trigger()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `DestinationVersionId` | string (UUID) | Optional assistant version ID to use for this test run. |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Update an assistant — `client.AI.Assistants.Update()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `Name` | string |  |
| `Model` | string | ID of the model to use when `external_llm` is not set. |
| `Instructions` | string | System instructions for the assistant. |
| `Tools` | array[object] | Deprecated for new integrations. |
| `McpServers` | array[object] | MCP servers attached to the assistant. |
| `A2aAgents` | array[object] | A2A agents this assistant can delegate to. |
| `ToolIds` | array[string] | IDs of shared tools to attach to the assistant. |
| `Description` | string |  |
| `Greeting` | string | Text that the assistant will use to start the conversation. |
| `LlmApiKeyRef` | string | This is only needed when using third-party inference providers selected by `m... |
| `ExternalLlm` | object |  |
| `FallbackConfig` | object |  |
| `VoiceSettings` | object |  |
| `AvatarSettings` | object | **Beta:** Replaces the assistant's avatar configuration. |
| `Transcription` | object |  |
| `TelephonySettings` | object |  |
| `MessagingSettings` | object |  |
| `EnabledFeatures` | array[string] |  |
| `InsightSettings` | object |  |
| `PrivacySettings` | object |  |
| `DynamicVariablesWebhookUrl` | string (URL) | If `dynamic_variables_webhook_url` is set, Telnyx sends a POST request to thi... |
| `DynamicVariablesWebhookTimeoutMs` | integer | Timeout in milliseconds for the dynamic variables webhook. |
| `DynamicVariables` | object | Map of dynamic variables and their default values |
| `WidgetSettings` | object | Configuration settings for the assistant's web widget. |
| `InterruptionSettings` | object | Settings for interruptions and how the assistant decides the user has finishe... |
| `Integrations` | array[object] | Connected integrations attached to the assistant. |
| `ObservabilitySettings` | object |  |
| `Tags` | array[string] | Tags associated with the assistant. |
| `VersionName` | string | Human-readable name for the assistant version. |
| `PostConversationSettings` | object | Configuration for post-conversation processing. |
| `DelegationSettings` | object | Splits the conversation between a frontend model that talks to the caller and... |
| `WebsocketSettings` | object | Streams conversation and telephony events to a WebSocket server you host, and... |
| `ConversationFlow` | object | Conversation flow as supplied by API clients (create / update). |
| `PromoteToMain` | boolean | Indicates whether the assistant should be promoted to the main version. |

### Create Canary Deploy — `client.AI.Assistants.CanaryDeploys.New()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `Rules` | array[object] |  |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Update Canary Deploy — `client.AI.Assistants.CanaryDeploys.Update()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `Rules` | array[object] |  |

### Assistant Chat — `client.AI.Assistants.Chat()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `Name` | string | The optional display name of the user sending the message |
| `Stream` | boolean | When true, the response is streamed as Server-Sent Events (`text/event-stream... |

### Assistant Sms Chat — `client.AI.Assistants.SendSMS()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `Text` | string |  |
| `ConversationMetadata` | object |  |
| `ShouldCreateConversation` | boolean |  |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Assistant WhatsApp Chat — `client.AI.Assistants.Whatsapp()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `ConversationMetadata` | object | Metadata stored on the conversation. |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Clone Assistant — `client.AI.Assistants.Clone()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Enhance Assistant Instructions — `client.AI.Assistants.Instructions.Enhance()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `EnhancementPrompt` | object | Optional guidance describing how the instructions should be enhanced. |
| `Instructions` | object | The instructions to enhance. |

### Create a scheduled event — `client.AI.Assistants.ScheduledEvents.New()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `Text` | string | Required for sms scheduled events. |
| `ConversationMetadata` | object | Metadata associated with the conversation. |
| `DynamicVariables` | object | A map of dynamic variable names to values. |
| `MaxRetriesClientErrors` | integer | Configure number of retries on client errors: busy, no-answer, failed, cancel... |
| `RetryIntervalSecs` | integer |  |
| `CallSettings` | object | Per-call telephony overrides applied when a scheduled phone-call event dispat... |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Test Assistant Tool — `client.AI.Assistants.Tools.Test()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `Arguments` | object | Key-value arguments to use for the webhook test |
| `DynamicVariables` | object | Key-value dynamic variables to use for the webhook test |

### Update a specific assistant version — `client.AI.Assistants.Versions.Update()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `Name` | string |  |
| `Model` | string | ID of the model to use when `external_llm` is not set. |
| `Instructions` | string | System instructions for the assistant. |
| `Tools` | array[object] | Deprecated for new integrations. |
| `McpServers` | array[object] | MCP servers attached to the assistant. |
| `A2aAgents` | array[object] | A2A agents this assistant can delegate to. |
| `ToolIds` | array[string] | IDs of shared tools to attach to the assistant. |
| `Description` | string |  |
| `Greeting` | string | Text that the assistant will use to start the conversation. |
| `LlmApiKeyRef` | string | This is only needed when using third-party inference providers selected by `m... |
| `ExternalLlm` | object |  |
| `FallbackConfig` | object |  |
| `VoiceSettings` | object |  |
| `AvatarSettings` | object | **Beta:** Replaces the assistant's avatar configuration. |
| `Transcription` | object |  |
| `TelephonySettings` | object |  |
| `MessagingSettings` | object |  |
| `EnabledFeatures` | array[string] |  |
| `InsightSettings` | object |  |
| `PrivacySettings` | object |  |
| `DynamicVariablesWebhookUrl` | string (URL) | If `dynamic_variables_webhook_url` is set, Telnyx sends a POST request to thi... |
| `DynamicVariablesWebhookTimeoutMs` | integer | Timeout in milliseconds for the dynamic variables webhook. |
| `DynamicVariables` | object | Map of dynamic variables and their default values |
| `WidgetSettings` | object | Configuration settings for the assistant's web widget. |
| `InterruptionSettings` | object | Settings for interruptions and how the assistant decides the user has finishe... |
| `Integrations` | array[object] | Connected integrations attached to the assistant. |
| `ObservabilitySettings` | object |  |
| `Tags` | array[string] | Tags associated with the assistant. |
| `VersionName` | string | Human-readable name for the assistant version. |
| `PostConversationSettings` | object | Configuration for post-conversation processing. |
| `DelegationSettings` | object | Splits the conversation between a frontend model that talks to the caller and... |
| `WebsocketSettings` | object | Streams conversation and telephony events to a WebSocket server you host, and... |
| `ConversationFlow` | object | Conversation flow as supplied by API clients (create / update). |

### Create MCP Server — `client.AI.McpServers.New()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `ApiKeyRef` | string |  |
| `AllowedTools` | array[string] |  |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Update MCP Server — `client.AI.McpServers.Update()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `Id` | string (UUID) |  |
| `Name` | string |  |
| `Type` | string |  |
| `Url` | string (URL) |  |
| `ApiKeyRef` | string |  |
| `AllowedTools` | array[string] |  |
| `CreatedAt` | string (date-time) |  |

### Create Tool — `client.AI.Tools.New()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `Function` | object |  |
| `Retrieval` | object |  |
| `Handoff` | object |  |
| `Invite` | object |  |
| `Webhook` | object |  |
| `Pay` | object |  |
| `ClientSideTool` | object |  |
| `UpdateDynamicVariables` | object | Configuration for an update_dynamic_variables tool. |
| `Vision` | object |  |
| `TimeoutMs` | integer |  |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Update Tool — `client.AI.Tools.Update()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `Type` | string |  |
| `DisplayName` | string |  |
| `Function` | object |  |
| `Retrieval` | object |  |
| `Handoff` | object |  |
| `Invite` | object |  |
| `Webhook` | object |  |
| `Pay` | object |  |
| `ClientSideTool` | object |  |
| `UpdateDynamicVariables` | object | Configuration for an update_dynamic_variables tool. |
| `Vision` | object |  |
| `TimeoutMs` | integer |  |
