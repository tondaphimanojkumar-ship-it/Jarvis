# AI Assistants (JavaScript) — API Details

<!-- Auto-generated reference file. Do not edit. -->

## Table of Contents

- [Response Schemas](#response-schemas)
- [Optional Parameters](#optional-parameters)

## Response Schemas

**Returned by:** List assistants, Create an assistant, Import assistants from external provider, Get an assistant, Update an assistant, Clone Assistant, Restore an assistant, Get all versions of an assistant, Get a specific assistant version, Update a specific assistant version, Promote an assistant version to main

| Field | Type |
|-------|------|
| `a2a_agents` | array[object] |
| `avatar_settings` | object |
| `conversation_flow` | object |
| `created_at` | date-time |
| `delegation_settings` | object |
| `description` | string |
| `dynamic_variables` | object |
| `dynamic_variables_webhook_timeout_ms` | integer |
| `dynamic_variables_webhook_url` | string |
| `enabled_features` | array[string] |
| `external_llm` | object |
| `fallback_config` | object |
| `greeting` | string |
| `id` | string |
| `import_metadata` | object |
| `insight_settings` | object |
| `instructions` | string |
| `integrations` | array[object] |
| `interruption_settings` | object |
| `llm_api_key_ref` | string |
| `mcp_servers` | array[object] |
| `messaging_settings` | object |
| `model` | string |
| `name` | string |
| `observability_settings` | object |
| `post_conversation_settings` | object |
| `privacy_settings` | object |
| `related_mission_ids` | array[string] |
| `tags` | array[string] |
| `telephony_settings` | object |
| `tools` | array[object] |
| `transcription` | object |
| `version_created_at` | date-time |
| `version_id` | string |
| `version_name` | string |
| `voice_settings` | object |
| `websocket_settings` | object |
| `widget_settings` | object |

**Returned by:** List deleted assistants, Get a deleted assistant

| Field | Type |
|-------|------|
| `a2a_agents` | array[object] |
| `avatar_settings` | object |
| `conversation_flow` | object |
| `created_at` | date-time |
| `delegation_settings` | object |
| `deleted_at` | date-time |
| `description` | string |
| `dynamic_variables` | object |
| `dynamic_variables_webhook_timeout_ms` | integer |
| `dynamic_variables_webhook_url` | string |
| `enabled_features` | array[string] |
| `external_llm` | object |
| `fallback_config` | object |
| `greeting` | string |
| `id` | string |
| `import_metadata` | object |
| `insight_settings` | object |
| `instructions` | string |
| `integrations` | array[object] |
| `interruption_settings` | object |
| `llm_api_key_ref` | string |
| `mcp_servers` | array[object] |
| `messaging_settings` | object |
| `model` | string |
| `name` | string |
| `observability_settings` | object |
| `permanently_deleted_at` | date-time |
| `post_conversation_settings` | object |
| `privacy_settings` | object |
| `related_mission_ids` | array[string] |
| `tags` | array[string] |
| `telephony_settings` | object |
| `tools` | array[object] |
| `transcription` | object |
| `version_created_at` | date-time |
| `version_id` | string |
| `version_name` | string |
| `voice_settings` | object |
| `websocket_settings` | object |
| `widget_settings` | object |

**Returned by:** Get All Tags, Add Assistant Tag, Remove Assistant Tag

| Field | Type |
|-------|------|
| `tags` | array[string] |

**Returned by:** List assistant tests with pagination, Create a new assistant test, Get assistant test by ID, Update an assistant test

| Field | Type |
|-------|------|
| `created_at` | date-time |
| `description` | string |
| `destination` | string |
| `instructions` | string |
| `max_duration_seconds` | integer |
| `name` | string |
| `rubric` | array[object] |
| `telnyx_conversation_channel` | object |
| `test_id` | uuid |
| `test_suite` | string |

**Returned by:** Get all test suite names

| Field | Type |
|-------|------|
| `data` | array[string] |

**Returned by:** Get test suite run history, Get test run history for a specific test, Trigger a manual test run, Get specific test run details

| Field | Type |
|-------|------|
| `completed_at` | date-time |
| `conversation_id` | string |
| `conversation_insights_id` | string |
| `created_at` | date-time |
| `detail_status` | array[object] |
| `logs` | string |
| `run_id` | uuid |
| `status` | enum: pending, starting, running, passed, failed, error |
| `test_id` | uuid |
| `test_suite_run_id` | uuid |
| `triggered_by` | string |
| `updated_at` | date-time |

**Returned by:** Delete an assistant

| Field | Type |
|-------|------|
| `deleted` | boolean |
| `id` | string |
| `object` | string |

**Returned by:** Get Canary Deploy, Create Canary Deploy, Update Canary Deploy

| Field | Type |
|-------|------|
| `assistant_id` | string |
| `created_at` | date-time |
| `rules` | array[object] |
| `updated_at` | date-time |

**Returned by:** Assistant Chat

| Field | Type |
|-------|------|
| `content` | string |

**Returned by:** Assistant Sms Chat

| Field | Type |
|-------|------|
| `conversation_id` | string |

**Returned by:** Assistant WhatsApp Chat

| Field | Type |
|-------|------|
| `conversation_id` | string |
| `message_id` | string |

**Returned by:** List scheduled events

| Field | Type |
|-------|------|
| `data` | array[object] |
| `meta` | object |

**Returned by:** Test Assistant Tool

| Field | Type |
|-------|------|
| `content_type` | string |
| `request` | object |
| `response` | string |
| `status_code` | integer |
| `success` | boolean |

**Returned by:** Create MCP Server, Get MCP Server, Update MCP Server

| Field | Type |
|-------|------|
| `allowed_tools` | array \| null |
| `api_key_ref` | string \| null |
| `created_at` | date-time |
| `id` | string |
| `name` | string |
| `type` | string |
| `url` | string |

**Returned by:** List Tools, Create Tool, Get Tool, Update Tool

| Field | Type |
|-------|------|
| `created_at` | string |
| `display_name` | string |
| `id` | string |
| `timeout_ms` | integer |
| `tool_definition` | object |
| `type` | string |

## Optional Parameters

### Create an assistant — `client.ai.assistants.create()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `model` | string | ID of the model to use when `external_llm` is not set. |
| `tools` | array[object] | Deprecated for new integrations. |
| `mcp_servers` | array[object] | MCP servers attached to the assistant. |
| `a2a_agents` | array[object] | A2A agents this assistant can delegate to. |
| `tool_ids` | array[string] | IDs of shared tools to attach to the assistant. |
| `description` | string |  |
| `greeting` | string | Text that the assistant will use to start the conversation. |
| `llm_api_key_ref` | string | This is only needed when using third-party inference providers selected by `m... |
| `external_llm` | object |  |
| `fallback_config` | object |  |
| `voice_settings` | object |  |
| `avatar_settings` | object | **Beta:** Optional avatar configuration for supported realtime browser conver... |
| `transcription` | object |  |
| `telephony_settings` | object |  |
| `messaging_settings` | object |  |
| `enabled_features` | array[string] |  |
| `insight_settings` | object |  |
| `privacy_settings` | object |  |
| `dynamic_variables_webhook_url` | string (URL) | If `dynamic_variables_webhook_url` is set, Telnyx sends a POST request to thi... |
| `dynamic_variables_webhook_timeout_ms` | integer | Timeout in milliseconds for the dynamic variables webhook. |
| `dynamic_variables` | object | Map of dynamic variables and their default values |
| `widget_settings` | object | Configuration settings for the assistant's web widget. |
| `interruption_settings` | object | Settings for interruptions and how the assistant decides the user has finishe... |
| `integrations` | array[object] | Connected integrations attached to the assistant. |
| `observability_settings` | object |  |
| `tags` | array[string] | Tags associated with the assistant. |
| `post_conversation_settings` | object | Configuration for post-conversation processing. |
| `delegation_settings` | object | Splits the conversation between a frontend model that talks to the caller and... |
| `websocket_settings` | object | Streams conversation and telephony events to a WebSocket server you host, and... |
| `conversation_flow` | object | Conversation flow as supplied by API clients (create / update). |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Import assistants from external provider — `client.ai.assistants.imports()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `import_ids` | array[string] | Optional list of assistant IDs to import from the external provider. |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Create a new assistant test — `client.ai.assistants.tests.create()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `description` | string | Optional detailed description of what this test evaluates and its purpose. |
| `telnyx_conversation_channel` | object | The communication channel through which the test will be conducted. |
| `max_duration_seconds` | integer | Maximum duration in seconds that the test conversation should run before timi... |
| `test_suite` | string | Optional test suite name to group related tests together. |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Trigger test suite execution — `client.ai.assistants.tests.testSuites.runs.trigger()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `destination_version_id` | string (UUID) | Optional assistant version ID to use for all test runs in this suite. |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Update an assistant test — `client.ai.assistants.tests.update()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `name` | string | Updated name for the assistant test. |
| `description` | string | Updated description of the test's purpose and evaluation criteria. |
| `telnyx_conversation_channel` | enum (phone_call, web_call, sms_chat, web_chat) |  |
| `destination` | string | Updated target destination for test conversations. |
| `max_duration_seconds` | integer | Updated maximum test duration in seconds. |
| `test_suite` | string | Updated test suite assignment for better organization. |
| `instructions` | string | Updated test scenario instructions and objectives. |
| `rubric` | array[object] | Updated evaluation criteria for assessing assistant performance. |

### Trigger a manual test run — `client.ai.assistants.tests.runs.trigger()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `destination_version_id` | string (UUID) | Optional assistant version ID to use for this test run. |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Update an assistant — `client.ai.assistants.update()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `name` | string |  |
| `model` | string | ID of the model to use when `external_llm` is not set. |
| `instructions` | string | System instructions for the assistant. |
| `tools` | array[object] | Deprecated for new integrations. |
| `mcp_servers` | array[object] | MCP servers attached to the assistant. |
| `a2a_agents` | array[object] | A2A agents this assistant can delegate to. |
| `tool_ids` | array[string] | IDs of shared tools to attach to the assistant. |
| `description` | string |  |
| `greeting` | string | Text that the assistant will use to start the conversation. |
| `llm_api_key_ref` | string | This is only needed when using third-party inference providers selected by `m... |
| `external_llm` | object |  |
| `fallback_config` | object |  |
| `voice_settings` | object |  |
| `avatar_settings` | object | **Beta:** Replaces the assistant's avatar configuration. |
| `transcription` | object |  |
| `telephony_settings` | object |  |
| `messaging_settings` | object |  |
| `enabled_features` | array[string] |  |
| `insight_settings` | object |  |
| `privacy_settings` | object |  |
| `dynamic_variables_webhook_url` | string (URL) | If `dynamic_variables_webhook_url` is set, Telnyx sends a POST request to thi... |
| `dynamic_variables_webhook_timeout_ms` | integer | Timeout in milliseconds for the dynamic variables webhook. |
| `dynamic_variables` | object | Map of dynamic variables and their default values |
| `widget_settings` | object | Configuration settings for the assistant's web widget. |
| `interruption_settings` | object | Settings for interruptions and how the assistant decides the user has finishe... |
| `integrations` | array[object] | Connected integrations attached to the assistant. |
| `observability_settings` | object |  |
| `tags` | array[string] | Tags associated with the assistant. |
| `version_name` | string | Human-readable name for the assistant version. |
| `post_conversation_settings` | object | Configuration for post-conversation processing. |
| `delegation_settings` | object | Splits the conversation between a frontend model that talks to the caller and... |
| `websocket_settings` | object | Streams conversation and telephony events to a WebSocket server you host, and... |
| `conversation_flow` | object | Conversation flow as supplied by API clients (create / update). |
| `promote_to_main` | boolean | Indicates whether the assistant should be promoted to the main version. |

### Create Canary Deploy — `client.ai.assistants.canaryDeploys.create()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `rules` | array[object] |  |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Update Canary Deploy — `client.ai.assistants.canaryDeploys.update()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `rules` | array[object] |  |

### Assistant Chat — `client.ai.assistants.chat()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `name` | string | The optional display name of the user sending the message |
| `stream` | boolean | When true, the response is streamed as Server-Sent Events (`text/event-stream... |

### Assistant Sms Chat — `client.ai.assistants.sendSMS()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `text` | string |  |
| `conversation_metadata` | object |  |
| `should_create_conversation` | boolean |  |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Assistant WhatsApp Chat — `client.ai.assistants.whatsapp()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `conversation_metadata` | object | Metadata stored on the conversation. |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Clone Assistant — `client.ai.assistants.clone()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Enhance Assistant Instructions — `client.ai.assistants.instructions.enhance()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `enhancement_prompt` | object | Optional guidance describing how the instructions should be enhanced. |
| `instructions` | object | The instructions to enhance. |

### Create a scheduled event — `client.ai.assistants.scheduledEvents.create()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `text` | string | Required for sms scheduled events. |
| `conversation_metadata` | object | Metadata associated with the conversation. |
| `dynamic_variables` | object | A map of dynamic variable names to values. |
| `max_retries_client_errors` | integer | Configure number of retries on client errors: busy, no-answer, failed, cancel... |
| `retry_interval_secs` | integer |  |
| `call_settings` | object | Per-call telephony overrides applied when a scheduled phone-call event dispat... |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Test Assistant Tool — `client.ai.assistants.tools.test()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `arguments` | object | Key-value arguments to use for the webhook test |
| `dynamic_variables` | object | Key-value dynamic variables to use for the webhook test |

### Update a specific assistant version — `client.ai.assistants.versions.update()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `name` | string |  |
| `model` | string | ID of the model to use when `external_llm` is not set. |
| `instructions` | string | System instructions for the assistant. |
| `tools` | array[object] | Deprecated for new integrations. |
| `mcp_servers` | array[object] | MCP servers attached to the assistant. |
| `a2a_agents` | array[object] | A2A agents this assistant can delegate to. |
| `tool_ids` | array[string] | IDs of shared tools to attach to the assistant. |
| `description` | string |  |
| `greeting` | string | Text that the assistant will use to start the conversation. |
| `llm_api_key_ref` | string | This is only needed when using third-party inference providers selected by `m... |
| `external_llm` | object |  |
| `fallback_config` | object |  |
| `voice_settings` | object |  |
| `avatar_settings` | object | **Beta:** Replaces the assistant's avatar configuration. |
| `transcription` | object |  |
| `telephony_settings` | object |  |
| `messaging_settings` | object |  |
| `enabled_features` | array[string] |  |
| `insight_settings` | object |  |
| `privacy_settings` | object |  |
| `dynamic_variables_webhook_url` | string (URL) | If `dynamic_variables_webhook_url` is set, Telnyx sends a POST request to thi... |
| `dynamic_variables_webhook_timeout_ms` | integer | Timeout in milliseconds for the dynamic variables webhook. |
| `dynamic_variables` | object | Map of dynamic variables and their default values |
| `widget_settings` | object | Configuration settings for the assistant's web widget. |
| `interruption_settings` | object | Settings for interruptions and how the assistant decides the user has finishe... |
| `integrations` | array[object] | Connected integrations attached to the assistant. |
| `observability_settings` | object |  |
| `tags` | array[string] | Tags associated with the assistant. |
| `version_name` | string | Human-readable name for the assistant version. |
| `post_conversation_settings` | object | Configuration for post-conversation processing. |
| `delegation_settings` | object | Splits the conversation between a frontend model that talks to the caller and... |
| `websocket_settings` | object | Streams conversation and telephony events to a WebSocket server you host, and... |
| `conversation_flow` | object | Conversation flow as supplied by API clients (create / update). |

### Create MCP Server — `client.ai.mcpServers.create()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `api_key_ref` | string |  |
| `allowed_tools` | array[string] |  |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Update MCP Server — `client.ai.mcpServers.update()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `id` | string (UUID) |  |
| `name` | string |  |
| `type` | string |  |
| `url` | string (URL) |  |
| `api_key_ref` | string |  |
| `allowed_tools` | array[string] |  |
| `created_at` | string (date-time) |  |

### Create Tool — `client.ai.tools.create()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `function` | object |  |
| `retrieval` | object |  |
| `handoff` | object |  |
| `invite` | object |  |
| `webhook` | object |  |
| `pay` | object |  |
| `client_side_tool` | object |  |
| `update_dynamic_variables` | object | Configuration for an update_dynamic_variables tool. |
| `vision` | object |  |
| `timeout_ms` | integer |  |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Update Tool — `client.ai.tools.update()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `type` | string |  |
| `display_name` | string |  |
| `function` | object |  |
| `retrieval` | object |  |
| `handoff` | object |  |
| `invite` | object |  |
| `webhook` | object |  |
| `pay` | object |  |
| `client_side_tool` | object |  |
| `update_dynamic_variables` | object | Configuration for an update_dynamic_variables tool. |
| `vision` | object |  |
| `timeout_ms` | integer |  |
