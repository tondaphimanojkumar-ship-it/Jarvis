<!-- SDK reference: telnyx-voice-go -->

# Telnyx Voice - Go

## Installation

```bash
go get github.com/team-telnyx/telnyx-go
```

## Setup

```go
import (
  "context"
  "fmt"
  "os"

  "github.com/team-telnyx/telnyx-go"
  "github.com/team-telnyx/telnyx-go/option"
)

client := telnyx.NewClient(
  option.WithAPIKey(os.Getenv("TELNYX_API_KEY")),
  option.WithPublicKey(os.Getenv("TELNYX_PUBLIC_KEY")), // Required for client.Webhooks.Unwrap (webhook verification)
)
```

All examples below assume `client` is already initialized as shown above.

## Error Handling

All API calls can fail with network errors, rate limits (429), validation errors (422),
or authentication errors (401). Always handle errors in production code:

```go
import "errors"

response, err := client.Calls.Dial(context.Background(), telnyx.CallDialParams{
		ConnectionID: "7267xxxxxxxxxxxxxx",
		From:         "+18005550101",
		To: telnyx.CallDialParamsToUnion{
			OfString: telnyx.String("+18005550100"),
		},
	})
if err != nil {
  var apiErr *telnyx.Error
  if errors.As(err, &apiErr) {
    switch apiErr.StatusCode {
    case 422:
      fmt.Println("Validation error — check required fields and formats")
    case 429:
      // Rate limited — wait, then retry the request (bounded exponential backoff)
      fmt.Println("Rate limited, retrying...")
    default:
      fmt.Printf("API error %d: %s\n", apiErr.StatusCode, apiErr.Error())
    }
  } else {
    fmt.Println("Network error — check connectivity and retry")
  }
  return err // Propagate: a failed request must never look like success to the caller
}
```

Common error codes: `401` invalid API key, `403` insufficient permissions,
`404` resource not found, `422` validation error (check field formats),
`429` rate limited (retry with exponential backoff).

## Important Notes

- **Phone numbers** must be in E.164 format (e.g., `+13125550001`). Include the `+` prefix and country code. No spaces, dashes, or parentheses.
- **Pagination:** Use `ListAutoPaging()` for automatic iteration: `iter := client.Resource.ListAutoPaging(ctx, params); for iter.Next() { item := iter.Current() }`.

## Operational Caveats

- Call Control is event-driven. After `dial()` or an inbound webhook, issue follow-up commands from webhook handlers using the `call_control_id` in the event payload.
- Outbound and inbound flows are different: outbound calls start with `dial()`, while inbound calls must be answered from the incoming webhook before other commands run.
- A publicly reachable webhook endpoint is required for real call control. Without it, calls may connect but your application cannot drive the live call state.

## Reference Use Rules

Do not invent Telnyx parameters, enums, response fields, or webhook fields.

- If the parameter, enum, or response field you need is not shown inline in this skill, read the Optional Parameters section below and the shared SDK API Details reference before writing code.
- Before using any operation in `## Additional Operations`, read the Optional Parameters section below and [the response-schemas section](../../references/sdk-api-details/voice.md#response-schemas).
- Before reading or matching webhook fields beyond the inline examples, read [the webhook payload reference](../../references/sdk-api-details/voice.md#webhook-payload-fields).

## Core Tasks

### Dial an outbound call

Primary voice entrypoint. Agents need the async call-control identifiers returned here.

`client.Calls.Dial()` — `POST /calls`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `To` | string (E.164) | Yes | The DID or SIP URI to dial out to. |
| `From` | string (E.164) | Yes | The `from` number to be used as the caller id presented to t... |
| `ConnectionId` | string (UUID) | Yes | The ID of the Call Control App (formerly ID of the connectio... |
| `TimeoutSecs` | integer | No | The number of seconds that Telnyx will wait for the call to ... |
| `BillingGroupId` | string (UUID) | No | Use this field to set the Billing Group ID for the call. |
| `ClientState` | string | No | Use this field to add state to every subsequent webhook. |
| ... | | | +59 optional params in the Optional Parameters section below and the shared SDK API Details reference |

```go
	response, err := client.Calls.Dial(context.Background(), telnyx.CallDialParams{
		ConnectionID: "7267xxxxxxxxxxxxxx",
		From:         "+18005550101",
		To: telnyx.CallDialParamsToUnion{
			OfString: telnyx.String("+18005550100"),
		},
	})
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("%+v\n", response.Data)
```

Primary response fields:
- `response.Data.CallControlID`
- `response.Data.CallLegID`
- `response.Data.CallSessionID`
- `response.Data.IsAlive`
- `response.Data.RecordingID`
- `response.Data.CallDuration`

### Answer an inbound call

Primary inbound call-control command.

`client.Calls.Actions.Answer()` — `POST /calls/{call_control_id}/actions/answer`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `CallControlId` | string (UUID) | Yes | Unique identifier and token for controlling the call |
| `BillingGroupId` | string (UUID) | No | Use this field to set the Billing Group ID for the call. |
| `ClientState` | string | No | Use this field to add state to every subsequent webhook. |
| `WebhookUrl` | string (URL) | No | Use this field to override the URL for which Telnyx will sen... |
| ... | | | +29 optional params in the Optional Parameters section below and the shared SDK API Details reference |

```go
	response, err := client.Calls.Actions.Answer(
		context.Background(),
		"call_control_id",
		telnyx.CallActionAnswerParams{},
	)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("%+v\n", response.Data)
```

Primary response fields:
- `response.Data.Result`
- `response.Data.RecordingID`

### Transfer a live call

Common post-answer control path with downstream webhook implications.

`client.Calls.Actions.Transfer()` — `POST /calls/{call_control_id}/actions/transfer`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `To` | string (E.164) | Yes | The DID or SIP URI to dial out to. |
| `CallControlId` | string (UUID) | Yes | Unique identifier and token for controlling the call |
| `TimeoutSecs` | integer | No | The number of seconds that Telnyx will wait for the call to ... |
| `ClientState` | string | No | Use this field to add state to every subsequent webhook. |
| `WebhookUrl` | string (URL) | No | Use this field to override the URL for which Telnyx will sen... |
| ... | | | +37 optional params in the Optional Parameters section below and the shared SDK API Details reference |

```go
	response, err := client.Calls.Actions.Transfer(
		context.Background(),
		"call_control_id",
		telnyx.CallActionTransferParams{
			To: "+18005550100",
		},
	)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("%+v\n", response.Data)
```

Primary response fields:
- `response.Data.Result`

---

### Webhook Verification

Telnyx signs webhooks with Ed25519. Each request includes `telnyx-signature-ed25519`
and `telnyx-timestamp` headers. Always verify signatures in production:

Verification needs your account's **public key** (Mission Control Portal → API Keys → Public Key).
The SDK reads it from `TELNYX_PUBLIC_KEY` (the `## Setup` block above passes it explicitly);
without it every valid webhook fails verification and the handler below returns 400.

```go
// In your webhook handler:
func handleWebhook(w http.ResponseWriter, r *http.Request) {
  body, _ := io.ReadAll(r.Body)
  event, err := client.Webhooks.Unwrap(body, r.Header)
  if err != nil {
    http.Error(w, "Invalid signature", http.StatusBadRequest)
    return
  }
  // Signature valid — event is the parsed webhook payload
  fmt.Println("Received event:", event.Data.EventType)
  w.WriteHeader(http.StatusOK)
}
```

## Webhooks

These webhook payload fields are inline because they are part of the primary integration path.

### Call Answered

| Field | Type | Description |
|-------|------|-------------|
| `data.record_type` | enum: event | Identifies the type of the resource. |
| `data.event_type` | enum: call.answered | The type of event being delivered. |
| `data.id` | uuid | Identifies the type of resource. |
| `data.occurred_at` | date-time | ISO 8601 datetime of when the event occurred. |
| `data.payload.call_control_id` | string | Call ID used to issue commands via Call Control API. |
| `data.payload.connection_id` | string | Call Control App ID (formerly Telnyx connection ID) used in the call. |
| `data.payload.call_leg_id` | string | ID that is unique to the call and can be used to correlate webhook events. |
| `data.payload.call_session_id` | string | ID that is unique to the call session and can be used to correlate webhook ev... |

### Call Hangup

| Field | Type | Description |
|-------|------|-------------|
| `data.record_type` | enum: event | Identifies the type of the resource. |
| `data.event_type` | enum: call.hangup | The type of event being delivered. |
| `data.id` | uuid | Identifies the type of resource. |
| `data.occurred_at` | date-time | ISO 8601 datetime of when the event occurred. |
| `data.payload.call_control_id` | string | Call ID used to issue commands via Call Control API. |
| `data.payload.connection_id` | string | Call Control App ID (formerly Telnyx connection ID) used in the call. |
| `data.payload.call_leg_id` | string | ID that is unique to the call and can be used to correlate webhook events. |
| `data.payload.call_session_id` | string | ID that is unique to the call session and can be used to correlate webhook ev... |

### Call Initiated

| Field | Type | Description |
|-------|------|-------------|
| `data.record_type` | enum: event | Identifies the type of the resource. |
| `data.event_type` | enum: call.initiated | The type of event being delivered. |
| `data.id` | uuid | Identifies the type of resource. |
| `data.occurred_at` | date-time | ISO 8601 datetime of when the event occurred. |
| `data.payload.call_control_id` | string | Call ID used to issue commands via Call Control API. |
| `data.payload.connection_id` | string | Call Control App ID (formerly Telnyx connection ID) used in the call. |
| `data.payload.connection_codecs` | string | The list of comma-separated codecs enabled for the connection. |
| `data.payload.offered_codecs` | string | The list of comma-separated codecs offered by caller. |

If you need webhook fields that are not listed inline here, read [the webhook payload reference](../../references/sdk-api-details/voice.md#webhook-payload-fields) before writing the handler.

---

## Important Supporting Operations

Use these when the core tasks above are close to your flow, but you need a common variation or follow-up step.

### Hangup call

End a live call from your webhook-driven control flow.

`client.Calls.Actions.Hangup()` — `POST /calls/{call_control_id}/actions/hangup`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `CallControlId` | string (UUID) | Yes | Unique identifier and token for controlling the call |
| `ClientState` | string | No | Use this field to add state to every subsequent webhook. |
| `CommandId` | string (UUID) | No | Use this field to avoid duplicate commands. |
| `CustomHeaders` | array[object] | No | Custom headers to be added to the SIP BYE message. |
| ... | | | +1 optional params in the Optional Parameters section below and the shared SDK API Details reference |

```go
	response, err := client.Calls.Actions.Hangup(
		context.Background(),
		"call_control_id",
		telnyx.CallActionHangupParams{},
	)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("%+v\n", response.Data)
```

Primary response fields:
- `response.Data.Result`

### Bridge calls

Trigger a follow-up action in an existing workflow rather than creating a new top-level resource.

`client.Calls.Actions.Bridge()` — `POST /calls/{call_control_id}/actions/bridge`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `CallControlIDToBridgeWith` | string (UUID) | Yes | The Call Control ID of the call you want to bridge with, can... |
| `CallControlId` | string (UUID) | Yes | Unique identifier and token for controlling the call |
| `ClientState` | string | No | Use this field to add state to every subsequent webhook. |
| `CommandId` | string (UUID) | No | Use this field to avoid duplicate commands. |
| `VideoRoomId` | string (UUID) | No | The ID of the video room you want to bridge with, can't be u... |
| ... | | | +16 optional params in the Optional Parameters section below and the shared SDK API Details reference |

```go
	response, err := client.Calls.Actions.Bridge(
		context.Background(),
		"call_control_id",
		telnyx.CallActionBridgeParams{
			CallControlIDToBridgeWith: "v3:MdI91X4lWFEs7IgbBEOT9M4AigoY08M0WWZFISt1Yw2axZ_IiE4pqg",
		},
	)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("%+v\n", response.Data)
```

Primary response fields:
- `response.Data.Result`

### Reject a call

Trigger a follow-up action in an existing workflow rather than creating a new top-level resource.

`client.Calls.Actions.Reject()` — `POST /calls/{call_control_id}/actions/reject`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `Cause` | enum (CALL_REJECTED, NOT_FOUND, TEMPORARILY_UNAVAILABLE, USER_BUSY) | Yes | Cause for call rejection. |
| `CallControlId` | string (UUID) | Yes | Unique identifier and token for controlling the call |
| `ClientState` | string | No | Use this field to add state to every subsequent webhook. |
| `CommandId` | string (UUID) | No | Use this field to avoid duplicate commands. |

```go
	response, err := client.Calls.Actions.Reject(
		context.Background(),
		"call_control_id",
		telnyx.CallActionRejectParams{
			Cause: telnyx.CallActionRejectParamsCauseUserBusy,
		},
	)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("%+v\n", response.Data)
```

Primary response fields:
- `response.Data.Result`

### Retrieve a call status

Fetch the current state before updating, deleting, or making control-flow decisions.

`client.Calls.GetStatus()` — `GET /calls/{call_control_id}`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `CallControlId` | string (UUID) | Yes | Unique identifier and token for controlling the call |

```go
	response, err := client.Calls.GetStatus(context.Background(), "call_control_id")
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("%+v\n", response.Data)
```

Primary response fields:
- `response.Data.CallControlID`
- `response.Data.CallDuration`
- `response.Data.CallLegID`
- `response.Data.CallSessionID`
- `response.Data.ClientState`
- `response.Data.EndTime`

### List all active calls for given connection

Fetch the current state before updating, deleting, or making control-flow decisions.

`client.Connections.ListActiveCalls()` — `GET /connections/{connection_id}/active_calls`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `ConnectionId` | string (UUID) | Yes | Telnyx connection id |
| `Page` | object | No | Consolidated page parameter (deepObject style). |

```go
	page, err := client.Connections.ListActiveCalls(
		context.Background(),
		"1293384261075731461",
		telnyx.ConnectionListActiveCallsParams{},
	)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("%+v\n", page)
```

Response wrapper:
- items: `page.data`
- pagination: `page.meta`

Primary item fields:
- `CallControlID`
- `CallDuration`
- `CallLegID`
- `CallSessionID`
- `ClientState`
- `RecordType`

### List call control applications

Inspect available resources or choose an existing resource before mutating it.

`client.CallControlApplications.List()` — `GET /call_control_applications`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `Sort` | enum (created_at, connection_name, active) | No | Specifies the sort order for results. |
| `Filter` | object | No | Consolidated filter parameter (deepObject style). |
| `Page` | object | No | Consolidated page parameter (deepObject style). |

```go
	page, err := client.CallControlApplications.List(context.Background(), telnyx.CallControlApplicationListParams{})
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("%+v\n", page)
```

Response wrapper:
- items: `page.data`
- pagination: `page.meta`

Primary item fields:
- `ID`
- `CreatedAt`
- `UpdatedAt`
- `Active`
- `AnchorsiteOverride`
- `ApplicationName`

---

## Additional Operations

Use the core tasks above first. The operations below are indexed here with exact SDK methods and required params; use the Optional Parameters section below and the shared SDK API Details reference for full optional params, response schemas, and lower-frequency webhook payloads.
Before using any operation below, read the Optional Parameters section below and [the response-schemas section](../../references/sdk-api-details/voice.md#response-schemas) so you do not guess missing fields.

| Operation | SDK method | Endpoint | Use when | Required params |
|-----------|------------|----------|----------|-----------------|
| Create a call control application | `client.CallControlApplications.New()` | `POST /call_control_applications` | Create or provision an additional resource when the core tasks do not cover this flow. | `ApplicationName`, `WebhookEventUrl` |
| Retrieve a call control application | `client.CallControlApplications.Get()` | `GET /call_control_applications/{id}` | Fetch the current state before updating, deleting, or making control-flow decisions. | `Id` |
| Update a call control application | `client.CallControlApplications.Update()` | `PATCH /call_control_applications/{id}` | Modify an existing resource without recreating it. | `ApplicationName`, `WebhookEventUrl`, `Id` |
| Delete a call control application | `client.CallControlApplications.Delete()` | `DELETE /call_control_applications/{id}` | Remove, detach, or clean up an existing resource. | `Id` |
| SIP Refer a call | `client.Calls.Actions.Refer()` | `POST /calls/{call_control_id}/actions/refer` | Trigger a follow-up action in an existing workflow rather than creating a new top-level resource. | `SipAddress`, `CallControlId` |
| Send SIP info | `client.Calls.Actions.SendSipInfo()` | `POST /calls/{call_control_id}/actions/send_sip_info` | Trigger a follow-up action in an existing workflow rather than creating a new top-level resource. | `ContentType`, `Body`, `CallControlId` |
| List dial metrics | `client.DialMetrics.List()` | `GET /dial_metrics` | Inspect available resources or choose an existing resource before mutating it. | None |

### Other Webhook Events

| Event | `data.event_type` | Description |
|-------|-------------------|-------------|
| `callBridged` | `call.bridged` | Call Bridged |

---

For exhaustive optional parameters, full response schemas, and complete webhook payloads, see the Optional Parameters section below and the shared SDK API Details reference.
---

**Do not guess optional fields. Response schemas and webhook payload fields are in [the shared SDK API Details reference](../../references/sdk-api-details/voice.md). Optional parameters for this language are in the Optional Parameters section below.**

## Optional Parameters

### Create a call control application — `client.CallControlApplications.New()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `Active` | boolean | Specifies whether the connection can be used. |
| `AnchorsiteOverride` | enum (Latency, Chicago, IL, Ashburn, VA, San Jose, CA, London, UK, ...) | `Latency` directs Telnyx to route media through the site with the lowest roun... |
| `DtmfType` | enum (RFC 2833, Inband, SIP INFO) | Sets the type of DTMF digits sent from Telnyx to this Connection. |
| `FirstCommandTimeout` | boolean | Specifies whether calls to phone numbers associated with this connection shou... |
| `FirstCommandTimeoutSecs` | integer | Specifies how many seconds to wait before timing out a dial command. |
| `Inbound` | object |  |
| `Outbound` | object |  |
| `WebhookApiVersion` | enum (1, 2) | Determines which webhook format will be used, Telnyx API v1 or v2. |
| `WebhookEventFailoverUrl` | string (URL) | The failover URL where webhooks related to this connection will be sent if se... |
| `WebhookTimeoutSecs` | integer | Specifies how many seconds to wait before timing out a webhook. |
| `CallCostInWebhooks` | boolean | Specifies if call cost webhooks should be sent for this Call Control Applicat... |
| `RedactDtmfDebugLogging` | boolean | When enabled, DTMF digits entered by users will be redacted in debug logs to ... |

### Update a call control application — `client.CallControlApplications.Update()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `CallCostInWebhooks` | boolean | Specifies if call cost webhooks should be sent for this Call Control Applicat... |
| `Active` | boolean | Specifies whether the connection can be used. |
| `AnchorsiteOverride` | enum (Latency, Chicago, IL, Ashburn, VA, San Jose, CA, London, UK, ...) | `Latency` directs Telnyx to route media through the site with the lowest roun... |
| `DtmfType` | enum (RFC 2833, Inband, SIP INFO) | Sets the type of DTMF digits sent from Telnyx to this Connection. |
| `FirstCommandTimeout` | boolean | Specifies whether calls to phone numbers associated with this connection shou... |
| `FirstCommandTimeoutSecs` | integer | Specifies how many seconds to wait before timing out a dial command. |
| `Tags` | array[string] | Tags assigned to the Call Control Application. |
| `Inbound` | object |  |
| `Outbound` | object |  |
| `WebhookApiVersion` | enum (1, 2) | Determines which webhook format will be used, Telnyx API v1 or v2. |
| `WebhookEventFailoverUrl` | string (URL) | The failover URL where webhooks related to this connection will be sent if se... |
| `WebhookTimeoutSecs` | integer | Specifies how many seconds to wait before timing out a webhook. |
| `RedactDtmfDebugLogging` | boolean | When enabled, DTMF digits entered by users will be redacted in debug logs to ... |

### Dial — `client.Calls.Dial()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `Assistant` | object | AI Assistant configuration and per-call overrides. |
| `ConversationRelayConfig` | object | Starts a Conversation Relay session automatically when the answered/dialed ca... |
| `Diversion` | string | The `to` number of an active inbound call, in +E164 format. |
| `FromDisplayName` | string | The `from_display_name` string to be used as the caller id name (SIP From Dis... |
| `Privacy` | enum (id, none) | Indicates the privacy level to be used for the call. |
| `AudioUrl` | string (URL) | The URL of a file to be played back to the callee when the call is answered. |
| `SendDigitsOnAnswer` | string | DTMF digits to send automatically after the called party answers. |
| `MediaName` | string | The media_name of a file to be played back to the callee when the call is ans... |
| `PreferredCodecs` | string | The list of comma-separated codecs in a preferred order for the forked media ... |
| `TimeoutSecs` | integer | The number of seconds that Telnyx will wait for the call to be answered by th... |
| `RetryOnTimeout` | boolean | Whether to keep trying the remaining routing paths (e.g. |
| `TimeLimitSecs` | integer | Sets the maximum duration of a Call Control Leg in seconds. |
| `AnsweringMachineDetection` | enum (premium, premium_ios_call_screening_detection, detect, detect_beep, detect_words, ...) | Enables Answering Machine Detection. |
| `AnsweringMachineDetectionConfig` | object | Optional configuration parameters to modify 'answering_machine_detection' per... |
| `DeepfakeDetection` | object | Enables deepfake detection on the call. |
| `ConferenceConfig` | object | Optional configuration parameters to dial new participant into a conference. |
| `CustomHeaders` | array[object] | Custom headers to be added to the SIP INVITE. |
| `BillingGroupId` | string (UUID) | Use this field to set the Billing Group ID for the call. |
| `ClientState` | string | Use this field to add state to every subsequent webhook. |
| `CommandId` | string (UUID) | Use this field to avoid duplicate commands. |
| `LinkTo` | string | Use another call's control id for sharing the same call session id |
| `BridgeIntent` | boolean | Indicates the intent to bridge this call with the call specified in link_to. |
| `BridgeOnAnswer` | boolean | Whether to automatically bridge answered call to the call specified in link_to. |
| `PreventDoubleBridge` | boolean | Prevents bridging and hangs up the call if the target is already bridged. |
| `ParkAfterUnbridge` | string | If supplied with the value `self`, the current leg will be parked after unbri... |
| `MediaEncryption` | enum (disabled, SRTP, DTLS) | Defines whether media should be encrypted on the call. |
| `SipAuthUsername` | string | SIP Authentication username used for SIP challenges. |
| `SipAuthPassword` | string | SIP Authentication password used for SIP challenges. |
| `SipHeaders` | array[object] | SIP headers to be added to the SIP INVITE request. |
| `SipTransportProtocol` | enum (UDP, TCP, TLS) | Defines SIP transport protocol to be used on the call. |
| `SoundModifications` | object | Use this field to modify sound effects, for example adjust the pitch. |
| `StreamUrl` | string (URL) | The destination WebSocket address where the stream is going to be delivered. |
| `StreamTrack` | enum (inbound_track, outbound_track, both_tracks) | Specifies which track should be streamed. |
| `StreamCodec` | enum (PCMU, PCMA, G722, OPUS, AMR-WB, ...) | Specifies the codec to be used for the streamed audio. |
| `StreamBidirectionalMode` | enum (mp3, rtp) | Configures method of bidirectional streaming (mp3, rtp). |
| `StreamBidirectionalCodec` | enum (PCMU, PCMA, G722, OPUS, AMR-WB, ...) | Indicates codec for bidirectional streaming RTP payloads. |
| `StreamBidirectionalTargetLegs` | enum (both, self, opposite) | Specifies which call legs should receive the bidirectional stream audio. |
| `StreamBidirectionalSamplingRate` | enum (8000, 16000, 22050, 24000, 48000) | Audio sampling rate. |
| `StreamEstablishBeforeCallOriginate` | boolean | Establish websocket connection before dialing the destination. |
| `SendSilenceWhenIdle` | boolean | Generate silence RTP packets when no transmission available. |
| `WebhookUrl` | string (URL) | Use this field to override the URL for which Telnyx will send subsequent webh... |
| `WebhookUrlMethod` | enum (POST, GET) | HTTP request type used for `webhook_url`. |
| `WebhookUrls` | object | A map of event types to arrays of webhook URLs. |
| `WebhookUrlsMethod` | enum (POST, GET) | HTTP request method to invoke `webhook_urls`. |
| `WebhookRetriesPolicies` | object | A map of event types to retry policies. |
| `Record` | enum (record-from-answer) | Start recording automatically after an event. |
| `RecordChannels` | enum (single, dual) | Defines which channel should be recorded ('single' or 'dual') when `record` i... |
| `RecordFormat` | enum (wav, mp3) | Defines the format of the recording ('wav' or 'mp3') when `record` is specified. |
| `RecordMaxLength` | integer | Defines the maximum length for the recording in seconds when `record` is spec... |
| `RecordTimeoutSecs` | integer | The number of seconds that Telnyx will wait for the recording to be stopped i... |
| `RecordTrack` | enum (both, inbound, outbound) | The audio track to be recorded. |
| `RecordTrim` | enum (trim-silence) | When set to `trim-silence`, silence will be removed from the beginning and en... |
| `RecordCustomFileName` | string | The custom recording file name to be used instead of the default `call_leg_id`. |
| `SuperviseCallControlId` | string (UUID) | The call leg which will be supervised by the new call. |
| `SupervisorRole` | enum (barge, whisper, monitor) | The role of the supervisor call. |
| `EnableDialogflow` | boolean | Enables Dialogflow for the current call. |
| `DialogflowConfig` | object |  |
| `Transcription` | boolean | Enable transcription upon call answer. |
| `TranscriptionConfig` | object |  |
| `SipRegion` | enum (US, Europe, Canada, Australia, Middle East) | Defines the SIP region to be used for the call. |
| `StreamAuthToken` | string | An authentication token to be sent as part of the WebSocket connection when u... |
| `RouteToMobile` | boolean | When set to true, routes the call directly to the mobile device associated wi... |

### Answer call — `client.Calls.Actions.Answer()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `Assistant` | object | AI Assistant configuration and per-call overrides. |
| `ConversationRelayConfig` | object | Starts a Conversation Relay session automatically when the answered/dialed ca... |
| `BillingGroupId` | string (UUID) | Use this field to set the Billing Group ID for the call. |
| `ClientState` | string | Use this field to add state to every subsequent webhook. |
| `CommandId` | string (UUID) | Use this field to avoid duplicate commands. |
| `CustomHeaders` | array[object] | Custom headers to be added to the SIP INVITE response. |
| `PreferredCodecs` | enum (G722,PCMU,PCMA,G729,OPUS,VP8,H264) | The list of comma-separated codecs in a preferred order for the forked media ... |
| `SipHeaders` | array[object] | SIP headers to be added to the SIP INVITE response. |
| `SoundModifications` | object | Use this field to modify sound effects, for example adjust the pitch. |
| `StreamUrl` | string (URL) | The destination WebSocket address where the stream is going to be delivered. |
| `StreamTrack` | enum (inbound_track, outbound_track, both_tracks) | Specifies which track should be streamed. |
| `StreamCodec` | enum (PCMU, PCMA, G722, OPUS, AMR-WB, ...) | Specifies the codec to be used for the streamed audio. |
| `StreamBidirectionalMode` | enum (mp3, rtp) | Configures method of bidirectional streaming (mp3, rtp). |
| `StreamBidirectionalCodec` | enum (PCMU, PCMA, G722, OPUS, AMR-WB, ...) | Indicates codec for bidirectional streaming RTP payloads. |
| `StreamBidirectionalTargetLegs` | enum (both, self, opposite) | Specifies which call legs should receive the bidirectional stream audio. |
| `SendSilenceWhenIdle` | boolean | Generate silence RTP packets when no transmission available. |
| `WebhookUrl` | string (URL) | Use this field to override the URL for which Telnyx will send subsequent webh... |
| `WebhookUrlMethod` | enum (POST, GET) | HTTP request type used for `webhook_url`. |
| `Transcription` | boolean | Enable standalone call transcription upon call answer. |
| `TranscriptionConfig` | object |  |
| `Record` | enum (record-from-answer) | Start recording automatically after an event. |
| `RecordChannels` | enum (single, dual) | Defines which channel should be recorded ('single' or 'dual') when `record` i... |
| `RecordFormat` | enum (wav, mp3) | Defines the format of the recording ('wav' or 'mp3') when `record` is specified. |
| `RecordMaxLength` | integer | Defines the maximum length for the recording in seconds when `record` is spec... |
| `RecordTimeoutSecs` | integer | The number of seconds that Telnyx will wait for the recording to be stopped i... |
| `RecordTrack` | enum (both, inbound, outbound) | The audio track to be recorded. |
| `RecordTrim` | enum (trim-silence) | When set to `trim-silence`, silence will be removed from the beginning and en... |
| `RecordCustomFileName` | string | The custom recording file name to be used instead of the default `call_leg_id`. |
| `WebhookUrls` | object | A map of event types to arrays of webhook URLs. |
| `WebhookUrlsMethod` | enum (POST, GET) | HTTP request method to invoke `webhook_urls`. |
| `WebhookRetriesPolicies` | object | A map of event types to retry policies. |
| `DeepfakeDetection` | object | Enables deepfake detection on the call. |

### Bridge calls — `client.Calls.Actions.Bridge()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `ClientState` | string | Use this field to add state to every subsequent webhook. |
| `CommandId` | string (UUID) | Use this field to avoid duplicate commands. |
| `Queue` | string | The name of the queue you want to bridge with, can't be used together with ca... |
| `VideoRoomId` | string (UUID) | The ID of the video room you want to bridge with, can't be used together with... |
| `VideoRoomContext` | string | The additional parameter that will be passed to the video conference. |
| `PreventDoubleBridge` | boolean | When set to `true`, it prevents bridging if the target call is already bridge... |
| `ParkAfterUnbridge` | string | Specifies behavior after the bridge ends (i.e. |
| `PlayRingtone` | boolean | Specifies whether to play a ringtone if the call you want to bridge with has ... |
| `Ringtone` | enum (at, au, be, bg, br, ...) | Specifies which country ringtone to play when `play_ringtone` is set to `true`. |
| `Record` | enum (record-from-answer) | Start recording automatically after an event. |
| `RecordChannels` | enum (single, dual) | Defines which channel should be recorded ('single' or 'dual') when `record` i... |
| `RecordFormat` | enum (wav, mp3) | Defines the format of the recording ('wav' or 'mp3') when `record` is specified. |
| `RecordMaxLength` | integer | Defines the maximum length for the recording in seconds when `record` is spec... |
| `RecordTimeoutSecs` | integer | The number of seconds that Telnyx will wait for the recording to be stopped i... |
| `RecordTrack` | enum (both, inbound, outbound) | The audio track to be recorded. |
| `RecordTrim` | enum (trim-silence) | When set to `trim-silence`, silence will be removed from the beginning and en... |
| `RecordCustomFileName` | string | The custom recording file name to be used instead of the default `call_leg_id`. |
| `MuteDtmf` | enum (none, both, self, opposite) | When enabled, DTMF tones are not passed to the call participant. |
| `HoldAfterUnbridge` | boolean | Specifies behavior after the bridge ends. |

### Hangup call — `client.Calls.Actions.Hangup()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `ClientState` | string | Use this field to add state to every subsequent webhook. |
| `CommandId` | string (UUID) | Use this field to avoid duplicate commands. |
| `CustomHeaders` | array[object] | Custom headers to be added to the SIP BYE message. |
| `Reason` | string | Text for the SIP `Reason` header (RFC 3326) sent when cancelling an unanswere... |

### SIP Refer a call — `client.Calls.Actions.Refer()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `ClientState` | string | Use this field to add state to every subsequent webhook. |
| `CommandId` | string (UUID) | Use this field to avoid execution of duplicate commands. |
| `CustomHeaders` | array[object] | Custom headers to be added to the SIP INVITE. |
| `SipAuthUsername` | string | SIP Authentication username used for SIP challenges. |
| `SipAuthPassword` | string | SIP Authentication password used for SIP challenges. |
| `SipHeaders` | array[object] | SIP headers to be added to the request. |

### Reject a call — `client.Calls.Actions.Reject()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `ClientState` | string | Use this field to add state to every subsequent webhook. |
| `CommandId` | string (UUID) | Use this field to avoid duplicate commands. |

### Send SIP info — `client.Calls.Actions.SendSipInfo()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `ClientState` | string | Use this field to add state to every subsequent webhook. |
| `CommandId` | string (UUID) | Use this field to avoid duplicate commands. |

### Transfer call — `client.Calls.Actions.Transfer()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `From` | string (E.164) | The `from` number to be used as the caller id presented to the destination (`... |
| `Diversion` | string | The `to` number of an active inbound call, in +E164 format. |
| `FromDisplayName` | string | The `from_display_name` string to be used as the caller id name (SIP From Dis... |
| `Privacy` | enum (id, none) | Indicates the privacy level to be used for the call. |
| `AudioUrl` | string (URL) | The URL of a file to be played back when the transfer destination answers bef... |
| `SendDigitsOnAnswer` | string | DTMF digits to send automatically after the transfer destination answers. |
| `EarlyMedia` | boolean | If set to false, early media will not be passed to the originating leg. |
| `MediaName` | string | The media_name of a file to be played back when the transfer destination answ... |
| `TimeoutSecs` | integer | The number of seconds that Telnyx will wait for the call to be answered by th... |
| `TimeLimitSecs` | integer | Sets the maximum duration of a Call Control Leg in seconds. |
| `ParkAfterUnbridge` | string | Specifies behavior after the bridge ends (i.e. |
| `AnsweringMachineDetection` | enum (premium, premium_ios_call_screening_detection, detect, detect_beep, detect_words, ...) | Enables Answering Machine Detection. |
| `AnsweringMachineDetectionConfig` | object | Optional configuration parameters to modify 'answering_machine_detection' per... |
| `CustomHeaders` | array[object] | Custom headers to be added to the SIP INVITE. |
| `ClientState` | string | Use this field to add state to every subsequent webhook. |
| `TargetLegClientState` | string | Use this field to add state to every subsequent webhook for the new leg. |
| `CommandId` | string (UUID) | Use this field to avoid duplicate commands. |
| `MediaEncryption` | enum (disabled, SRTP, DTLS) | Defines whether media should be encrypted on the new call leg. |
| `SipAuthUsername` | string | SIP Authentication username used for SIP challenges. |
| `SipAuthPassword` | string | SIP Authentication password used for SIP challenges. |
| `SipHeaders` | array[object] | SIP headers to be added to the SIP INVITE. |
| `SipTransportProtocol` | enum (UDP, TCP, TLS) | Defines SIP transport protocol to be used on the call. |
| `SoundModifications` | object | Use this field to modify sound effects, for example adjust the pitch. |
| `WebhookUrl` | string (URL) | Use this field to override the URL for which Telnyx will send subsequent webh... |
| `WebhookUrlMethod` | enum (POST, GET) | HTTP request type used for `webhook_url`. |
| `MuteDtmf` | enum (none, both, self, opposite) | When enabled, DTMF tones are not passed to the call participant. |
| `Record` | enum (record-from-answer) | Start recording automatically after an event. |
| `RecordChannels` | enum (single, dual) | Defines which channel should be recorded ('single' or 'dual') when `record` i... |
| `RecordFormat` | enum (wav, mp3) | Defines the format of the recording ('wav' or 'mp3') when `record` is specified. |
| `RecordMaxLength` | integer | Defines the maximum length for the recording in seconds when `record` is spec... |
| `RecordTimeoutSecs` | integer | The number of seconds that Telnyx will wait for the recording to be stopped i... |
| `RecordTrack` | enum (both, inbound, outbound) | The audio track to be recorded. |
| `RecordTrim` | enum (trim-silence) | When set to `trim-silence`, silence will be removed from the beginning and en... |
| `RecordCustomFileName` | string | The custom recording file name to be used instead of the default `call_leg_id`. |
| `SipRegion` | enum (US, Europe, Canada, Australia, Middle East) | Defines the SIP region to be used for the call. |
| `PreferredCodecs` | string | The list of comma-separated codecs in order of preference to be used during t... |
| `WebhookUrls` | object | A map of event types to arrays of webhook URLs. |
| `WebhookUrlsMethod` | enum (POST, GET) | HTTP request method to invoke `webhook_urls`. |
| `WebhookRetriesPolicies` | object | A map of event types to retry policies. |
| `RouteToMobile` | boolean | When set to true, routes the call directly to the mobile device associated wi... |
