<!-- SDK reference: telnyx-ai-assistants-java -->

# Telnyx AI Assistants - Java

## Installation

```text
<!-- Maven -->
<dependency>
    <groupId>com.telnyx.sdk</groupId>
    <artifactId>telnyx</artifactId>
    <version>6.95.0</version>
</dependency>

// Gradle
implementation("com.telnyx.sdk:telnyx:6.95.0")
```

## Setup

```java
import com.telnyx.sdk.client.TelnyxClient;
import com.telnyx.sdk.client.okhttp.TelnyxOkHttpClient;

// fromEnv() reads TELNYX_API_KEY and TELNYX_PUBLIC_KEY (the public key is required for
// client.webhooks().unwrap() — webhook verification)
TelnyxClient client = TelnyxOkHttpClient.fromEnv();
```

All examples below assume `client` is already initialized as shown above.

## Error Handling

All API calls can fail with network errors, rate limits (429), validation errors (422),
or authentication errors (401). Always handle errors in production code:

```java
import com.telnyx.sdk.models.ai.assistants.AssistantCreateParams;
import com.telnyx.sdk.models.ai.assistants.InferenceEmbedding;
import com.telnyx.sdk.errors.TelnyxServiceException;

try {
    AssistantCreateParams params = AssistantCreateParams.builder()
        .instructions("You are a helpful assistant.")
        .name("my-resource")
        .model("openai/gpt-4o")
        .build();
    InferenceEmbedding assistant = client.ai().assistants().create(params);
} catch (TelnyxServiceException e) {
    System.err.println("API error " + e.statusCode() + ": " + e.getMessage());
    if (e.statusCode() == 422) {
        System.err.println("Validation error — check required fields and formats");
    } else if (e.statusCode() == 429) {
        // Rate limited — wait, then retry the request (bounded exponential backoff)
        Thread.sleep(1000);
        // ...retry the call here (give up after a few attempts)
    }
    throw e; // Re-throw: a failed request must never look like success to the caller
}
```

Common error codes: `401` invalid API key, `403` insufficient permissions,
`404` resource not found, `422` validation error (check field formats),
`429` rate limited (retry with exponential backoff).

## Important Notes

- **Phone numbers** must be in E.164 format (e.g., `+13125550001`). Include the `+` prefix and country code. No spaces, dashes, or parentheses.
- **Pagination:** List methods return a page. Use `.autoPager()` for automatic iteration: `for (var item : page.autoPager()) { ... }`. For manual control, use `.hasNextPage()` and `.nextPage()`.

## Reference Use Rules

Do not invent Telnyx parameters, enums, response fields, or webhook fields.

- If the parameter, enum, or response field you need is not shown inline in this skill, read the Optional Parameters section below and the shared SDK API Details reference before writing code.
- Before using any operation in `## Additional Operations`, read the Optional Parameters section below and [the response-schemas section](../../references/sdk-api-details/ai-assistants.md#response-schemas).

## Core Tasks

### Create an assistant

Assistant creation is the entrypoint for any AI assistant integration. Agents need the exact creation method and the top-level fields returned by the SDK.

`client.ai().assistants().create()` — `POST /ai/assistants`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `name` | string | Yes |  |
| `instructions` | string | Yes | System instructions for the assistant. |
| `tags` | array[string] | No | Tags associated with the assistant. |
| `model` | string | No | ID of the model to use when `external_llm` is not set. |
| `tools` | array[object] | No | Deprecated for new integrations. |
| ... | | | +28 optional params in the Optional Parameters section below and the shared SDK API Details reference |

```java
import com.telnyx.sdk.models.ai.assistants.AssistantCreateParams;
import com.telnyx.sdk.models.ai.assistants.InferenceEmbedding;

AssistantCreateParams params = AssistantCreateParams.builder()
    .instructions("You are a helpful assistant.")
    .name("my-resource")
    .model("openai/gpt-4o")
    .build();
InferenceEmbedding assistant = client.ai().assistants().create(params);
```

Primary response fields:
- `assistant.id`
- `assistant.name`
- `assistant.model`
- `assistant.instructions`
- `assistant.createdAt`
- `assistant.a2aAgents`

### Chat with an assistant

Chat is the primary runtime path. Agents need the exact assistant method and the response content field.

`client.ai().assistants().chat()` — `POST /ai/assistants/{assistant_id}/chat`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `content` | string | Yes | The message content sent by the client to the assistant |
| `conversationId` | string (UUID) | Yes | A unique identifier for the conversation thread, used to mai... |
| `assistantId` | string (UUID) | Yes | Unique identifier of the assistant. |
| `name` | string | No | The optional display name of the user sending the message |
| `stream` | boolean | No | When true, the response is streamed as Server-Sent Events (`... |

```java
import com.telnyx.sdk.models.ai.assistants.AssistantChatParams;
import com.telnyx.sdk.models.ai.assistants.AssistantChatResponse;

AssistantChatParams params = AssistantChatParams.builder()
    .assistantId("550e8400-e29b-41d4-a716-446655440000")
    .content("Tell me a joke about cats")
    .conversationId("42b20469-1215-4a9a-8964-c36f66b406f4")
    .build();
AssistantChatResponse response = client.ai().assistants().chat(params);
```

Primary response fields:
- `response.content`

### Create an assistant test

Test creation is the main validation path for production assistant behavior before deployment.

`client.ai().assistants().tests().create()` — `POST /ai/assistants/tests`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `name` | string | Yes | A descriptive name for the assistant test. |
| `destination` | string | Yes | The target destination for the test conversation. |
| `instructions` | string | Yes | Detailed instructions that define the test scenario and what... |
| `rubric` | array[object] | Yes | Evaluation criteria used to assess the assistant's performan... |
| `description` | string | No | Optional detailed description of what this test evaluates an... |
| `telnyxConversationChannel` | object | No | The communication channel through which the test will be con... |
| `maxDurationSeconds` | integer | No | Maximum duration in seconds that the test conversation shoul... |
| ... | | | +2 optional params in the Optional Parameters section below and the shared SDK API Details reference |

```java
import com.telnyx.sdk.models.ai.assistants.tests.AssistantTest;
import com.telnyx.sdk.models.ai.assistants.tests.TestCreateParams;

TestCreateParams params = TestCreateParams.builder()
    .destination("+15551234567")
    .instructions("Act as a frustrated customer who received a damaged product. Ask for a refund and escalate if not satisfied with the initial response.")
    .name("Customer Support Bot Test")
    .addRubric(TestCreateParams.Rubric.builder()
        .criteria("Assistant responds within 30 seconds")
        .name("Response Time")
        .build())
    .addRubric(TestCreateParams.Rubric.builder()
        .criteria("Provides correct product information")
        .name("Accuracy")
        .build())
    .build();
AssistantTest assistantTest = client.ai().assistants().tests().create(params);
```

Primary response fields:
- `assistantTest.testId`
- `assistantTest.name`
- `assistantTest.destination`
- `assistantTest.createdAt`
- `assistantTest.instructions`
- `assistantTest.description`

---

## Important Supporting Operations

Use these when the core tasks above are close to your flow, but you need a common variation or follow-up step.

### Get an assistant

Fetch the current state before updating, deleting, or making control-flow decisions.

`client.ai().assistants().retrieve()` — `GET /ai/assistants/{assistant_id}`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `assistantId` | string (UUID) | Yes | Unique identifier of the assistant. |
| `callControlId` | string (UUID) | No | Filter results by call control id. |
| `fetchDynamicVariablesFromWebhook` | boolean | No | Whether to fetch dynamic variables from the configured webho... |
| `from` | string (E.164) | No | Start of the filter range. |
| ... | | | +1 optional params in the Optional Parameters section below and the shared SDK API Details reference |

```java
import com.telnyx.sdk.models.ai.assistants.AssistantRetrieveParams;
import com.telnyx.sdk.models.ai.assistants.InferenceEmbedding;

InferenceEmbedding assistant = client.ai().assistants().retrieve("550e8400-e29b-41d4-a716-446655440000");
```

Primary response fields:
- `assistant.id`
- `assistant.name`
- `assistant.createdAt`
- `assistant.a2aAgents`
- `assistant.avatarSettings`
- `assistant.conversationFlow`

### Update an assistant

Create or provision an additional resource when the core tasks do not cover this flow.

`client.ai().assistants().update()` — `POST /ai/assistants/{assistant_id}`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `assistantId` | string (UUID) | Yes | Unique identifier of the assistant. |
| `tags` | array[string] | No | Tags associated with the assistant. |
| `name` | string | No |  |
| `model` | string | No | ID of the model to use when `external_llm` is not set. |
| ... | | | +31 optional params in the Optional Parameters section below and the shared SDK API Details reference |

```java
import com.telnyx.sdk.models.ai.assistants.AssistantUpdateParams;
import com.telnyx.sdk.models.ai.assistants.InferenceEmbedding;

InferenceEmbedding assistant = client.ai().assistants().update("550e8400-e29b-41d4-a716-446655440000");
```

Primary response fields:
- `assistant.id`
- `assistant.name`
- `assistant.createdAt`
- `assistant.a2aAgents`
- `assistant.avatarSettings`
- `assistant.conversationFlow`

### List assistants

Inspect available resources or choose an existing resource before mutating it.

`client.ai().assistants().list()` — `GET /ai/assistants`

```java
import com.telnyx.sdk.models.ai.assistants.AssistantListParams;
import com.telnyx.sdk.models.ai.assistants.AssistantsList;

AssistantsList assistantsList = client.ai().assistants().list();
```

Response wrapper:
- items: `assistantsList.data`

Primary item fields:
- `id`
- `name`
- `createdAt`
- `a2aAgents`
- `avatarSettings`
- `conversationFlow`

### List deleted assistants

Inspect available resources or choose an existing resource before mutating it.

`client.ai().assistants().deleted().list()` — `GET /ai/assistants/deleted`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `page[number]` | integer | No | Page number to retrieve (1-based). |
| `page[size]` | integer | No | Number of items to return per page. |

```java
var page = client.ai().assistants().deleted().list();
```

Response wrapper:
- items: `page.data`
- pagination: `page.meta`

Primary item fields:
- `id`
- `name`
- `createdAt`
- `a2aAgents`
- `avatarSettings`
- `conversationFlow`

### Import assistants from external provider

Import existing assistants from an external provider instead of creating from scratch.

`client.ai().assistants().imports()` — `POST /ai/assistants/import`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `provider` | enum (elevenlabs, vapi, retell) | Yes | The external provider to import assistants from. |
| `apiKeyRef` | string | Yes | Integration secret pointer that refers to the API key for th... |
| `importIds` | array[string] | No | Optional list of assistant IDs to import from the external p... |
| `Idempotency-Key` | string | No | Optional opaque, unquoted key for safely retrying the same l... |

```java
import com.telnyx.sdk.models.ai.assistants.AssistantImportsParams;
import com.telnyx.sdk.models.ai.assistants.AssistantsList;

AssistantImportsParams params = AssistantImportsParams.builder()
    .apiKeyRef("my-openai-key")
    .provider(AssistantImportsParams.Provider.ELEVENLABS)
    .build();
AssistantsList assistantsList = client.ai().assistants().imports(params);
```

Response wrapper:
- items: `assistantsList.data`

Primary item fields:
- `id`
- `name`
- `createdAt`
- `a2aAgents`
- `avatarSettings`
- `conversationFlow`

### Get All Tags

Inspect available resources or choose an existing resource before mutating it.

`client.ai().assistants().tags().list()` — `GET /ai/assistants/tags`

```java
import com.telnyx.sdk.models.ai.assistants.tags.TagListParams;
import com.telnyx.sdk.models.ai.assistants.tags.TagListResponse;

TagListResponse tags = client.ai().assistants().tags().list();
```

Primary response fields:
- `tags.tags`

### List assistant tests with pagination

Inspect available resources or choose an existing resource before mutating it.

`client.ai().assistants().tests().list()` — `GET /ai/assistants/tests`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `testSuite` | string | No | Filter tests by test suite name |
| `telnyxConversationChannel` | string | No | Filter tests by communication channel (e.g., 'web_chat', 'sm... |
| `destination` | string | No | Filter tests by destination (phone number, webhook URL, etc.... |
| ... | | | +1 optional params in the Optional Parameters section below and the shared SDK API Details reference |

```java
import com.telnyx.sdk.models.ai.assistants.tests.TestListPage;
import com.telnyx.sdk.models.ai.assistants.tests.TestListParams;

TestListPage page = client.ai().assistants().tests().list();
```

Response wrapper:
- items: `page.data`
- pagination: `page.meta`

Primary item fields:
- `name`
- `createdAt`
- `description`
- `destination`
- `instructions`
- `maxDurationSeconds`

### Get all test suite names

Inspect available resources or choose an existing resource before mutating it.

`client.ai().assistants().tests().testSuites().list()` — `GET /ai/assistants/tests/test-suites`

```java
import com.telnyx.sdk.models.ai.assistants.tests.testsuites.TestSuiteListParams;
import com.telnyx.sdk.models.ai.assistants.tests.testsuites.TestSuiteListResponse;

TestSuiteListResponse testSuites = client.ai().assistants().tests().testSuites().list();
```

Response wrapper:
- items: `testSuites.data`

Primary item fields:
- `data`

---

## Additional Operations

Use the core tasks above first. The operations below are indexed here with exact SDK methods and required params; use the Optional Parameters section below and the shared SDK API Details reference for full optional params, response schemas, and lower-frequency webhook payloads.
Before using any operation below, read the Optional Parameters section below and [the response-schemas section](../../references/sdk-api-details/ai-assistants.md#response-schemas) so you do not guess missing fields.

| Operation | SDK method | Endpoint | Use when | Required params |
|-----------|------------|----------|----------|-----------------|
| Get test suite run history | `client.ai().assistants().tests().testSuites().runs().list()` | `GET /ai/assistants/tests/test-suites/{suite_name}/runs` | Fetch the current state before updating, deleting, or making control-flow decisions. | `suiteName` |
| Trigger test suite execution | `client.ai().assistants().tests().testSuites().runs().trigger()` | `POST /ai/assistants/tests/test-suites/{suite_name}/runs` | Trigger a follow-up action in an existing workflow rather than creating a new top-level resource. | `suiteName` |
| Get assistant test by ID | `client.ai().assistants().tests().retrieve()` | `GET /ai/assistants/tests/{test_id}` | Fetch the current state before updating, deleting, or making control-flow decisions. | `testId` |
| Update an assistant test | `client.ai().assistants().tests().update()` | `PUT /ai/assistants/tests/{test_id}` | Modify an existing resource without recreating it. | `testId` |
| Delete an assistant test | `client.ai().assistants().tests().delete()` | `DELETE /ai/assistants/tests/{test_id}` | Remove, detach, or clean up an existing resource. | `testId` |
| Get test run history for a specific test | `client.ai().assistants().tests().runs().list()` | `GET /ai/assistants/tests/{test_id}/runs` | Fetch the current state before updating, deleting, or making control-flow decisions. | `testId` |
| Trigger a manual test run | `client.ai().assistants().tests().runs().trigger()` | `POST /ai/assistants/tests/{test_id}/runs` | Trigger a follow-up action in an existing workflow rather than creating a new top-level resource. | `testId` |
| Get specific test run details | `client.ai().assistants().tests().runs().retrieve()` | `GET /ai/assistants/tests/{test_id}/runs/{run_id}` | Fetch the current state before updating, deleting, or making control-flow decisions. | `testId`, `runId` |
| Delete an assistant | `client.ai().assistants().delete()` | `DELETE /ai/assistants/{assistant_id}` | Remove, detach, or clean up an existing resource. | `assistantId` |
| Get Canary Deploy | `client.ai().assistants().canaryDeploys().retrieve()` | `GET /ai/assistants/{assistant_id}/canary-deploys` | Fetch the current state before updating, deleting, or making control-flow decisions. | `assistantId` |
| Create Canary Deploy | `client.ai().assistants().canaryDeploys().create()` | `POST /ai/assistants/{assistant_id}/canary-deploys` | Create or provision an additional resource when the core tasks do not cover this flow. | `assistantId` |
| Update Canary Deploy | `client.ai().assistants().canaryDeploys().update()` | `PUT /ai/assistants/{assistant_id}/canary-deploys` | Modify an existing resource without recreating it. | `assistantId` |
| Delete Canary Deploy | `client.ai().assistants().canaryDeploys().delete()` | `DELETE /ai/assistants/{assistant_id}/canary-deploys` | Remove, detach, or clean up an existing resource. | `assistantId` |
| Assistant Sms Chat | `client.ai().assistants().sendSms()` | `POST /ai/assistants/{assistant_id}/chat/sms` | Run assistant chat over SMS instead of direct API chat. | `from`, `to`, `assistantId` |
| Assistant WhatsApp Chat | `client.ai().assistants().whatsapp()` | `POST /ai/assistants/{assistant_id}/chat/whatsapp` | Create or provision an additional resource when the core tasks do not cover this flow. | `from`, `to`, `content`, `assistantId` |
| Clone Assistant | `client.ai().assistants().clone()` | `POST /ai/assistants/{assistant_id}/clone` | Trigger a follow-up action in an existing workflow rather than creating a new top-level resource. | `assistantId` |
| Get a deleted assistant | `client.ai().assistants().deleted().get()` | `GET /ai/assistants/{assistant_id}/deleted` | Fetch the current state before updating, deleting, or making control-flow decisions. | `assistantId` |
| Enhance Assistant Instructions | `client.ai().assistants().instructions().enhance()` | `POST /ai/assistants/{assistant_id}/instructions/enhance` | Create or provision an additional resource when the core tasks do not cover this flow. | `assistantId` |
| Restore an assistant | `client.ai().assistants().restore()` | `POST /ai/assistants/{assistant_id}/restore` | Create or provision an additional resource when the core tasks do not cover this flow. | `assistantId` |
| List scheduled events | `client.ai().assistants().scheduledEvents().list()` | `GET /ai/assistants/{assistant_id}/scheduled_events` | Fetch the current state before updating, deleting, or making control-flow decisions. | `assistantId` |
| Create a scheduled event | `client.ai().assistants().scheduledEvents().create()` | `POST /ai/assistants/{assistant_id}/scheduled_events` | Create or provision an additional resource when the core tasks do not cover this flow. | `telnyxConversationChannel`, `telnyxEndUserTarget`, `telnyxAgentTarget`, `scheduledAtFixedDatetime`, +1 more |
| Get a scheduled event | `client.ai().assistants().scheduledEvents().retrieve()` | `GET /ai/assistants/{assistant_id}/scheduled_events/{event_id}` | Fetch the current state before updating, deleting, or making control-flow decisions. | `assistantId`, `eventId` |
| Delete a scheduled event | `client.ai().assistants().scheduledEvents().delete()` | `DELETE /ai/assistants/{assistant_id}/scheduled_events/{event_id}` | Remove, detach, or clean up an existing resource. | `assistantId`, `eventId` |
| Add Assistant Tag | `client.ai().assistants().tags().add()` | `POST /ai/assistants/{assistant_id}/tags` | Create or provision an additional resource when the core tasks do not cover this flow. | `tag`, `assistantId` |
| Remove Assistant Tag | `client.ai().assistants().tags().remove()` | `DELETE /ai/assistants/{assistant_id}/tags/{tag}` | Remove, detach, or clean up an existing resource. | `assistantId`, `tag` |
| Get assistant texml | `client.ai().assistants().getTexml()` | `GET /ai/assistants/{assistant_id}/texml` | Fetch the current state before updating, deleting, or making control-flow decisions. | `assistantId` |
| Add Assistant Tool | `client.ai().assistants().tools().add()` | `PUT /ai/assistants/{assistant_id}/tools/{tool_id}` | Modify an existing resource without recreating it. | `assistantId`, `toolId` |
| Remove Assistant Tool | `client.ai().assistants().tools().remove()` | `DELETE /ai/assistants/{assistant_id}/tools/{tool_id}` | Remove, detach, or clean up an existing resource. | `assistantId`, `toolId` |
| Test Assistant Tool | `client.ai().assistants().tools().test()` | `POST /ai/assistants/{assistant_id}/tools/{tool_id}/test` | Trigger a follow-up action in an existing workflow rather than creating a new top-level resource. | `assistantId`, `toolId` |
| Get all versions of an assistant | `client.ai().assistants().versions().list()` | `GET /ai/assistants/{assistant_id}/versions` | Fetch the current state before updating, deleting, or making control-flow decisions. | `assistantId` |
| Get a specific assistant version | `client.ai().assistants().versions().retrieve()` | `GET /ai/assistants/{assistant_id}/versions/{version_id}` | Fetch the current state before updating, deleting, or making control-flow decisions. | `assistantId`, `versionId` |
| Update a specific assistant version | `client.ai().assistants().versions().update()` | `POST /ai/assistants/{assistant_id}/versions/{version_id}` | Create or provision an additional resource when the core tasks do not cover this flow. | `assistantId`, `versionId` |
| Delete a specific assistant version | `client.ai().assistants().versions().delete()` | `DELETE /ai/assistants/{assistant_id}/versions/{version_id}` | Remove, detach, or clean up an existing resource. | `assistantId`, `versionId` |
| Promote an assistant version to main | `client.ai().assistants().versions().promote()` | `POST /ai/assistants/{assistant_id}/versions/{version_id}/promote` | Trigger a follow-up action in an existing workflow rather than creating a new top-level resource. | `assistantId`, `versionId` |
| List MCP Servers | `client.ai().mcpServers().list()` | `GET /ai/mcp_servers` | Inspect available resources or choose an existing resource before mutating it. | None |
| Create MCP Server | `client.ai().mcpServers().create()` | `POST /ai/mcp_servers` | Create or provision an additional resource when the core tasks do not cover this flow. | `name`, `type`, `url` |
| Get MCP Server | `client.ai().mcpServers().retrieve()` | `GET /ai/mcp_servers/{mcp_server_id}` | Fetch the current state before updating, deleting, or making control-flow decisions. | `mcpServerId` |
| Update MCP Server | `client.ai().mcpServers().update()` | `PUT /ai/mcp_servers/{mcp_server_id}` | Modify an existing resource without recreating it. | `mcpServerId` |
| Delete MCP Server | `client.ai().mcpServers().delete()` | `DELETE /ai/mcp_servers/{mcp_server_id}` | Remove, detach, or clean up an existing resource. | `mcpServerId` |
| List Tools | `client.ai().tools().list()` | `GET /ai/tools` | Inspect available resources or choose an existing resource before mutating it. | None |
| Create Tool | `client.ai().tools().create()` | `POST /ai/tools` | Create or provision an additional resource when the core tasks do not cover this flow. | `type`, `displayName` |
| Get Tool | `client.ai().tools().retrieve()` | `GET /ai/tools/{tool_id}` | Fetch the current state before updating, deleting, or making control-flow decisions. | `toolId` |
| Update Tool | `client.ai().tools().update()` | `PATCH /ai/tools/{tool_id}` | Modify an existing resource without recreating it. | `toolId` |
| Delete Tool | `client.ai().tools().delete()` | `DELETE /ai/tools/{tool_id}` | Remove, detach, or clean up an existing resource. | `toolId` |

---

For exhaustive optional parameters, full response schemas, and complete webhook payloads, see the Optional Parameters section below and the shared SDK API Details reference.
---

**Do not guess optional fields. Response schemas and webhook payload fields are in [the shared SDK API Details reference](../../references/sdk-api-details/ai-assistants.md). Optional parameters for this language are in the Optional Parameters section below.**

## Optional Parameters

### Create an assistant — `client.ai().assistants().create()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `model` | string | ID of the model to use when `external_llm` is not set. |
| `tools` | array[object] | Deprecated for new integrations. |
| `mcpServers` | array[object] | MCP servers attached to the assistant. |
| `a2aAgents` | array[object] | A2A agents this assistant can delegate to. |
| `toolIds` | array[string] | IDs of shared tools to attach to the assistant. |
| `description` | string |  |
| `greeting` | string | Text that the assistant will use to start the conversation. |
| `llmApiKeyRef` | string | This is only needed when using third-party inference providers selected by `m... |
| `externalLlm` | object |  |
| `fallbackConfig` | object |  |
| `voiceSettings` | object |  |
| `avatarSettings` | object | **Beta:** Optional avatar configuration for supported realtime browser conver... |
| `transcription` | object |  |
| `telephonySettings` | object |  |
| `messagingSettings` | object |  |
| `enabledFeatures` | array[string] |  |
| `insightSettings` | object |  |
| `privacySettings` | object |  |
| `dynamicVariablesWebhookUrl` | string (URL) | If `dynamic_variables_webhook_url` is set, Telnyx sends a POST request to thi... |
| `dynamicVariablesWebhookTimeoutMs` | integer | Timeout in milliseconds for the dynamic variables webhook. |
| `dynamicVariables` | object | Map of dynamic variables and their default values |
| `widgetSettings` | object | Configuration settings for the assistant's web widget. |
| `interruptionSettings` | object | Settings for interruptions and how the assistant decides the user has finishe... |
| `integrations` | array[object] | Connected integrations attached to the assistant. |
| `observabilitySettings` | object |  |
| `tags` | array[string] | Tags associated with the assistant. |
| `postConversationSettings` | object | Configuration for post-conversation processing. |
| `delegationSettings` | object | Splits the conversation between a frontend model that talks to the caller and... |
| `websocketSettings` | object | Streams conversation and telephony events to a WebSocket server you host, and... |
| `conversationFlow` | object | Conversation flow as supplied by API clients (create / update). |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Import assistants from external provider — `client.ai().assistants().imports()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `importIds` | array[string] | Optional list of assistant IDs to import from the external provider. |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Create a new assistant test — `client.ai().assistants().tests().create()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `description` | string | Optional detailed description of what this test evaluates and its purpose. |
| `telnyxConversationChannel` | object | The communication channel through which the test will be conducted. |
| `maxDurationSeconds` | integer | Maximum duration in seconds that the test conversation should run before timi... |
| `testSuite` | string | Optional test suite name to group related tests together. |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Trigger test suite execution — `client.ai().assistants().tests().testSuites().runs().trigger()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `destinationVersionId` | string (UUID) | Optional assistant version ID to use for all test runs in this suite. |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Update an assistant test — `client.ai().assistants().tests().update()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `name` | string | Updated name for the assistant test. |
| `description` | string | Updated description of the test's purpose and evaluation criteria. |
| `telnyxConversationChannel` | enum (phone_call, web_call, sms_chat, web_chat) |  |
| `destination` | string | Updated target destination for test conversations. |
| `maxDurationSeconds` | integer | Updated maximum test duration in seconds. |
| `testSuite` | string | Updated test suite assignment for better organization. |
| `instructions` | string | Updated test scenario instructions and objectives. |
| `rubric` | array[object] | Updated evaluation criteria for assessing assistant performance. |

### Trigger a manual test run — `client.ai().assistants().tests().runs().trigger()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `destinationVersionId` | string (UUID) | Optional assistant version ID to use for this test run. |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Update an assistant — `client.ai().assistants().update()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `name` | string |  |
| `model` | string | ID of the model to use when `external_llm` is not set. |
| `instructions` | string | System instructions for the assistant. |
| `tools` | array[object] | Deprecated for new integrations. |
| `mcpServers` | array[object] | MCP servers attached to the assistant. |
| `a2aAgents` | array[object] | A2A agents this assistant can delegate to. |
| `toolIds` | array[string] | IDs of shared tools to attach to the assistant. |
| `description` | string |  |
| `greeting` | string | Text that the assistant will use to start the conversation. |
| `llmApiKeyRef` | string | This is only needed when using third-party inference providers selected by `m... |
| `externalLlm` | object |  |
| `fallbackConfig` | object |  |
| `voiceSettings` | object |  |
| `avatarSettings` | object | **Beta:** Replaces the assistant's avatar configuration. |
| `transcription` | object |  |
| `telephonySettings` | object |  |
| `messagingSettings` | object |  |
| `enabledFeatures` | array[string] |  |
| `insightSettings` | object |  |
| `privacySettings` | object |  |
| `dynamicVariablesWebhookUrl` | string (URL) | If `dynamic_variables_webhook_url` is set, Telnyx sends a POST request to thi... |
| `dynamicVariablesWebhookTimeoutMs` | integer | Timeout in milliseconds for the dynamic variables webhook. |
| `dynamicVariables` | object | Map of dynamic variables and their default values |
| `widgetSettings` | object | Configuration settings for the assistant's web widget. |
| `interruptionSettings` | object | Settings for interruptions and how the assistant decides the user has finishe... |
| `integrations` | array[object] | Connected integrations attached to the assistant. |
| `observabilitySettings` | object |  |
| `tags` | array[string] | Tags associated with the assistant. |
| `versionName` | string | Human-readable name for the assistant version. |
| `postConversationSettings` | object | Configuration for post-conversation processing. |
| `delegationSettings` | object | Splits the conversation between a frontend model that talks to the caller and... |
| `websocketSettings` | object | Streams conversation and telephony events to a WebSocket server you host, and... |
| `conversationFlow` | object | Conversation flow as supplied by API clients (create / update). |
| `promoteToMain` | boolean | Indicates whether the assistant should be promoted to the main version. |

### Create Canary Deploy — `client.ai().assistants().canaryDeploys().create()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `rules` | array[object] |  |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Update Canary Deploy — `client.ai().assistants().canaryDeploys().update()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `rules` | array[object] |  |

### Assistant Chat — `client.ai().assistants().chat()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `name` | string | The optional display name of the user sending the message |
| `stream` | boolean | When true, the response is streamed as Server-Sent Events (`text/event-stream... |

### Assistant Sms Chat — `client.ai().assistants().sendSms()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `text` | string |  |
| `conversationMetadata` | object |  |
| `shouldCreateConversation` | boolean |  |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Assistant WhatsApp Chat — `client.ai().assistants().whatsapp()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `conversationMetadata` | object | Metadata stored on the conversation. |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Clone Assistant — `client.ai().assistants().clone()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Enhance Assistant Instructions — `client.ai().assistants().instructions().enhance()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `enhancementPrompt` | object | Optional guidance describing how the instructions should be enhanced. |
| `instructions` | object | The instructions to enhance. |

### Create a scheduled event — `client.ai().assistants().scheduledEvents().create()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `text` | string | Required for sms scheduled events. |
| `conversationMetadata` | object | Metadata associated with the conversation. |
| `dynamicVariables` | object | A map of dynamic variable names to values. |
| `maxRetriesClientErrors` | integer | Configure number of retries on client errors: busy, no-answer, failed, cancel... |
| `retryIntervalSecs` | integer |  |
| `callSettings` | object | Per-call telephony overrides applied when a scheduled phone-call event dispat... |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Test Assistant Tool — `client.ai().assistants().tools().test()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `arguments` | object | Key-value arguments to use for the webhook test |
| `dynamicVariables` | object | Key-value dynamic variables to use for the webhook test |

### Update a specific assistant version — `client.ai().assistants().versions().update()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `name` | string |  |
| `model` | string | ID of the model to use when `external_llm` is not set. |
| `instructions` | string | System instructions for the assistant. |
| `tools` | array[object] | Deprecated for new integrations. |
| `mcpServers` | array[object] | MCP servers attached to the assistant. |
| `a2aAgents` | array[object] | A2A agents this assistant can delegate to. |
| `toolIds` | array[string] | IDs of shared tools to attach to the assistant. |
| `description` | string |  |
| `greeting` | string | Text that the assistant will use to start the conversation. |
| `llmApiKeyRef` | string | This is only needed when using third-party inference providers selected by `m... |
| `externalLlm` | object |  |
| `fallbackConfig` | object |  |
| `voiceSettings` | object |  |
| `avatarSettings` | object | **Beta:** Replaces the assistant's avatar configuration. |
| `transcription` | object |  |
| `telephonySettings` | object |  |
| `messagingSettings` | object |  |
| `enabledFeatures` | array[string] |  |
| `insightSettings` | object |  |
| `privacySettings` | object |  |
| `dynamicVariablesWebhookUrl` | string (URL) | If `dynamic_variables_webhook_url` is set, Telnyx sends a POST request to thi... |
| `dynamicVariablesWebhookTimeoutMs` | integer | Timeout in milliseconds for the dynamic variables webhook. |
| `dynamicVariables` | object | Map of dynamic variables and their default values |
| `widgetSettings` | object | Configuration settings for the assistant's web widget. |
| `interruptionSettings` | object | Settings for interruptions and how the assistant decides the user has finishe... |
| `integrations` | array[object] | Connected integrations attached to the assistant. |
| `observabilitySettings` | object |  |
| `tags` | array[string] | Tags associated with the assistant. |
| `versionName` | string | Human-readable name for the assistant version. |
| `postConversationSettings` | object | Configuration for post-conversation processing. |
| `delegationSettings` | object | Splits the conversation between a frontend model that talks to the caller and... |
| `websocketSettings` | object | Streams conversation and telephony events to a WebSocket server you host, and... |
| `conversationFlow` | object | Conversation flow as supplied by API clients (create / update). |

### Create MCP Server — `client.ai().mcpServers().create()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `apiKeyRef` | string |  |
| `allowedTools` | array[string] |  |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Update MCP Server — `client.ai().mcpServers().update()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `id` | string (UUID) |  |
| `name` | string |  |
| `type` | string |  |
| `url` | string (URL) |  |
| `apiKeyRef` | string |  |
| `allowedTools` | array[string] |  |
| `createdAt` | string (date-time) |  |

### Create Tool — `client.ai().tools().create()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `function` | object |  |
| `retrieval` | object |  |
| `handoff` | object |  |
| `invite` | object |  |
| `webhook` | object |  |
| `pay` | object |  |
| `clientSideTool` | object |  |
| `updateDynamicVariables` | object | Configuration for an update_dynamic_variables tool. |
| `vision` | object |  |
| `timeoutMs` | integer |  |
| `Idempotency-Key` | string | Optional opaque, unquoted key for safely retrying the same logical request. |

### Update Tool — `client.ai().tools().update()`

| Parameter | Type | Description |
|-----------|------|-------------|
| `type` | string |  |
| `displayName` | string |  |
| `function` | object |  |
| `retrieval` | object |  |
| `handoff` | object |  |
| `invite` | object |  |
| `webhook` | object |  |
| `pay` | object |  |
| `clientSideTool` | object |  |
| `updateDynamicVariables` | object | Configuration for an update_dynamic_variables tool. |
| `vision` | object |  |
| `timeoutMs` | integer |  |
