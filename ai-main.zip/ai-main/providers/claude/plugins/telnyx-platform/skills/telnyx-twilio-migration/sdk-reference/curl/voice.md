<!-- SDK reference: telnyx-voice-curl -->

# Telnyx Voice - curl

## Installation

```text
# curl is pre-installed on macOS, Linux, and Windows 10+
```

## Setup

```bash
export TELNYX_API_KEY="YOUR_API_KEY_HERE"
```

All examples below use `$TELNYX_API_KEY` for authentication.

## Error Handling

All API calls can fail with network errors, rate limits (429), validation errors (422),
or authentication errors (401). Always handle errors in production code:

```bash
curl \
  -X POST \
  -H "Authorization: Bearer $TELNYX_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
  "to": "+13125550001",
  "from": "+18005550101",
  "connection_id": "550e8400-e29b-41d4-a716-446655440000"
}' \
  "https://api.telnyx.com/v2/calls"
```

Common error codes: `401` invalid API key, `403` insufficient permissions,
`404` resource not found, `422` validation error (check field formats),
`429` rate limited (retry with exponential backoff).

## Important Notes

- **Phone numbers** must be in E.164 format (e.g., `+13125550001`). Include the `+` prefix and country code. No spaces, dashes, or parentheses.
- **Pagination:** List endpoints return paginated results. Use `page[number]` and `page[size]` query parameters to navigate pages. Check `meta.total_pages` in the response.

## Operational Caveats

- Call Control is event-driven. After `dial()` or an inbound webhook, issue follow-up commands from webhook handlers using the `call_control_id` in the event payload.
- Outbound and inbound flows are different: outbound calls start with `dial()`, while inbound calls must be answered from the incoming webhook before other commands run.
- A publicly reachable webhook endpoint is required for real call control. Without it, calls may connect but your application cannot drive the live call state.

## Reference Use Rules

Do not invent Telnyx parameters, enums, response fields, or webhook fields.

- If the parameter, enum, or response field you need is not shown inline in this skill, read the Optional Parameters section below and the shared SDK API Details reference before writing code.
- Before using any operation in `## Additional Operations`, read the Optional Parameters section below and [the response-schemas section](../../references/sdk-api-details/voice.md#response-schemas).
- Before reading or matching webhook fields beyond the inline examples, read [the webhook payload reference](../../references/sdk-api-details/voice.md#webhook-payload-fields).

## Core Tasks

### Dial an outbound call

Primary voice entrypoint. Agents need the async call-control identifiers returned here.

`POST /calls`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `to` | string (E.164) | Yes | The DID or SIP URI to dial out to. |
| `from` | string (E.164) | Yes | The `from` number to be used as the caller id presented to t... |
| `connection_id` | string (UUID) | Yes | The ID of the Call Control App (formerly ID of the connectio... |
| `timeout_secs` | integer | No | The number of seconds that Telnyx will wait for the call to ... |
| `billing_group_id` | string (UUID) | No | Use this field to set the Billing Group ID for the call. |
| `client_state` | string | No | Use this field to add state to every subsequent webhook. |
| ... | | | +59 optional params in the Optional Parameters section below and the shared SDK API Details reference |

```bash
curl \
  -X POST \
  -H "Authorization: Bearer $TELNYX_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
  "to": "+13125550001",
  "from": "+18005550101",
  "connection_id": "550e8400-e29b-41d4-a716-446655440000"
}' \
  "https://api.telnyx.com/v2/calls"
```

Primary response fields:
- `.data.call_control_id`
- `.data.call_leg_id`
- `.data.call_session_id`
- `.data.is_alive`
- `.data.recording_id`
- `.data.call_duration`

### Answer an inbound call

Primary inbound call-control command.

`POST /calls/{call_control_id}/actions/answer`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `call_control_id` | string (UUID) | Yes | Unique identifier and token for controlling the call |
| `billing_group_id` | string (UUID) | No | Use this field to set the Billing Group ID for the call. |
| `client_state` | string | No | Use this field to add state to every subsequent webhook. |
| `webhook_url` | string (URL) | No | Use this field to override the URL for which Telnyx will sen... |
| ... | | | +29 optional params in the Optional Parameters section below and the shared SDK API Details reference |

```bash
curl \
  -X POST \
  -H "Authorization: Bearer $TELNYX_API_KEY" \
  -H "Content-Type: application/json" \
  "https://api.telnyx.com/v2/calls/v3:550e8400-e29b-41d4-a716-446655440000_gRU1OGRkYQ/actions/answer"
```

Primary response fields:
- `.data.result`
- `.data.recording_id`

### Transfer a live call

Common post-answer control path with downstream webhook implications.

`POST /calls/{call_control_id}/actions/transfer`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `to` | string (E.164) | Yes | The DID or SIP URI to dial out to. |
| `call_control_id` | string (UUID) | Yes | Unique identifier and token for controlling the call |
| `timeout_secs` | integer | No | The number of seconds that Telnyx will wait for the call to ... |
| `client_state` | string | No | Use this field to add state to every subsequent webhook. |
| `webhook_url` | string (URL) | No | Use this field to override the URL for which Telnyx will sen... |
| ... | | | +37 optional params in the Optional Parameters section below and the shared SDK API Details reference |

```bash
curl \
  -X POST \
  -H "Authorization: Bearer $TELNYX_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
  "to": "+18005550100"
}' \
  "https://api.telnyx.com/v2/calls/v3:550e8400-e29b-41d4-a716-446655440000_gRU1OGRkYQ/actions/transfer"
```

Primary response fields:
- `.data.result`

---

### Webhook Verification

Telnyx signs webhooks with Ed25519. Each request includes `telnyx-signature-ed25519`
and `telnyx-timestamp` headers. Always verify signatures in production:

Verification needs your account's **public key** (Mission Control Portal → API Keys → Public Key).
Keep it in `TELNYX_PUBLIC_KEY` and pass it to whatever Ed25519 library verifies the signature;
without it no webhook can be verified.

```bash
# Telnyx signs webhooks with Ed25519 (asymmetric — NOT HMAC/Standard Webhooks).
# Headers sent with each webhook:
#   telnyx-signature-ed25519: base64-encoded Ed25519 signature
#   telnyx-timestamp: Unix timestamp (reject if >5 minutes old for replay protection)
#
# Get your public key from: Telnyx Portal > Account Settings > Keys & Credentials
# Use the Telnyx SDK in your language for verification (client.webhooks.unwrap).
# Your endpoint MUST return 2xx within 2 seconds or Telnyx will retry (up to 3 attempts).
# Configure a failover URL in Telnyx Portal for additional reliability.
```

## Webhooks

These webhook payload fields are inline because they are part of the primary integration path.

### Call Answered

| Field | Type | Description |
|-------|------|-------------|
| `data.record_type` | enum: event | Identifies the type of the resource. |
| `data.event_type` | enum: call.answered | The type of event being delivered. |
| `data.id` | uuid | Identifies the type of resource. |
| `data.occurred_at` | date-time | ISO 8601 datetime of when the event occurred. |
| `data.payload.call_control_id` | string | Call ID used to issue commands via Call Control API. |
| `data.payload.connection_id` | string | Call Control App ID (formerly Telnyx connection ID) used in the call. |
| `data.payload.call_leg_id` | string | ID that is unique to the call and can be used to correlate webhook events. |
| `data.payload.call_session_id` | string | ID that is unique to the call session and can be used to correlate webhook ev... |

### Call Hangup

| Field | Type | Description |
|-------|------|-------------|
| `data.record_type` | enum: event | Identifies the type of the resource. |
| `data.event_type` | enum: call.hangup | The type of event being delivered. |
| `data.id` | uuid | Identifies the type of resource. |
| `data.occurred_at` | date-time | ISO 8601 datetime of when the event occurred. |
| `data.payload.call_control_id` | string | Call ID used to issue commands via Call Control API. |
| `data.payload.connection_id` | string | Call Control App ID (formerly Telnyx connection ID) used in the call. |
| `data.payload.call_leg_id` | string | ID that is unique to the call and can be used to correlate webhook events. |
| `data.payload.call_session_id` | string | ID that is unique to the call session and can be used to correlate webhook ev... |

### Call Initiated

| Field | Type | Description |
|-------|------|-------------|
| `data.record_type` | enum: event | Identifies the type of the resource. |
| `data.event_type` | enum: call.initiated | The type of event being delivered. |
| `data.id` | uuid | Identifies the type of resource. |
| `data.occurred_at` | date-time | ISO 8601 datetime of when the event occurred. |
| `data.payload.call_control_id` | string | Call ID used to issue commands via Call Control API. |
| `data.payload.connection_id` | string | Call Control App ID (formerly Telnyx connection ID) used in the call. |
| `data.payload.connection_codecs` | string | The list of comma-separated codecs enabled for the connection. |
| `data.payload.offered_codecs` | string | The list of comma-separated codecs offered by caller. |

If you need webhook fields that are not listed inline here, read [the webhook payload reference](../../references/sdk-api-details/voice.md#webhook-payload-fields) before writing the handler.

---

## Important Supporting Operations

Use these when the core tasks above are close to your flow, but you need a common variation or follow-up step.

### Hangup call

End a live call from your webhook-driven control flow.

`POST /calls/{call_control_id}/actions/hangup`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `call_control_id` | string (UUID) | Yes | Unique identifier and token for controlling the call |
| `client_state` | string | No | Use this field to add state to every subsequent webhook. |
| `command_id` | string (UUID) | No | Use this field to avoid duplicate commands. |
| `custom_headers` | array[object] | No | Custom headers to be added to the SIP BYE message. |
| ... | | | +1 optional params in the Optional Parameters section below and the shared SDK API Details reference |

```bash
curl \
  -X POST \
  -H "Authorization: Bearer $TELNYX_API_KEY" \
  -H "Content-Type: application/json" \
  "https://api.telnyx.com/v2/calls/v3:550e8400-e29b-41d4-a716-446655440000_gRU1OGRkYQ/actions/hangup"
```

Primary response fields:
- `.data.result`

### Bridge calls

Trigger a follow-up action in an existing workflow rather than creating a new top-level resource.

`POST /calls/{call_control_id}/actions/bridge`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `call_control_id` | string (UUID) | Yes | The Call Control ID of the call you want to bridge with, can... |
| `call_control_id` | string (UUID) | Yes | Unique identifier and token for controlling the call |
| `client_state` | string | No | Use this field to add state to every subsequent webhook. |
| `command_id` | string (UUID) | No | Use this field to avoid duplicate commands. |
| `video_room_id` | string (UUID) | No | The ID of the video room you want to bridge with, can't be u... |
| ... | | | +16 optional params in the Optional Parameters section below and the shared SDK API Details reference |

```bash
curl \
  -X POST \
  -H "Authorization: Bearer $TELNYX_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
  "call_control_id": "v3:MdI91X4lWFEs7IgbBEOT9M4AigoY08M0WWZFISt1Yw2axZ_IiE4pqg"
}' \
  "https://api.telnyx.com/v2/calls/v3:550e8400-e29b-41d4-a716-446655440000_gRU1OGRkYQ/actions/bridge"
```

Primary response fields:
- `.data.result`

### Reject a call

Trigger a follow-up action in an existing workflow rather than creating a new top-level resource.

`POST /calls/{call_control_id}/actions/reject`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `cause` | enum (CALL_REJECTED, NOT_FOUND, TEMPORARILY_UNAVAILABLE, USER_BUSY) | Yes | Cause for call rejection. |
| `call_control_id` | string (UUID) | Yes | Unique identifier and token for controlling the call |
| `client_state` | string | No | Use this field to add state to every subsequent webhook. |
| `command_id` | string (UUID) | No | Use this field to avoid duplicate commands. |

```bash
curl \
  -X POST \
  -H "Authorization: Bearer $TELNYX_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
  "cause": "USER_BUSY"
}' \
  "https://api.telnyx.com/v2/calls/v3:550e8400-e29b-41d4-a716-446655440000_gRU1OGRkYQ/actions/reject"
```

Primary response fields:
- `.data.result`

### Retrieve a call status

Fetch the current state before updating, deleting, or making control-flow decisions.

`GET /calls/{call_control_id}`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `call_control_id` | string (UUID) | Yes | Unique identifier and token for controlling the call |

```bash
curl -H "Authorization: Bearer $TELNYX_API_KEY" "https://api.telnyx.com/v2/calls/v3:550e8400-e29b-41d4-a716-446655440000_gRU1OGRkYQ"
```

Primary response fields:
- `.data.call_control_id`
- `.data.call_duration`
- `.data.call_leg_id`
- `.data.call_session_id`
- `.data.client_state`
- `.data.end_time`

### List all active calls for given connection

Fetch the current state before updating, deleting, or making control-flow decisions.

`GET /connections/{connection_id}/active_calls`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `connection_id` | string (UUID) | Yes | Telnyx connection id |
| `page` | object | No | Consolidated page parameter (deepObject style). |

```bash
curl -H "Authorization: Bearer $TELNYX_API_KEY" "https://api.telnyx.com/v2/connections/1293384261075731461/active_calls"
```

Response wrapper:
- items: `.data`
- pagination: `.meta`

Primary item fields:
- `call_control_id`
- `call_duration`
- `call_leg_id`
- `call_session_id`
- `client_state`
- `record_type`

### List call control applications

Inspect available resources or choose an existing resource before mutating it.

`GET /call_control_applications`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `sort` | enum (created_at, connection_name, active) | No | Specifies the sort order for results. |
| `filter` | object | No | Consolidated filter parameter (deepObject style). |
| `page` | object | No | Consolidated page parameter (deepObject style). |

```bash
curl -H "Authorization: Bearer $TELNYX_API_KEY" "https://api.telnyx.com/v2/call_control_applications?sort=connection_name"
```

Response wrapper:
- items: `.data`
- pagination: `.meta`

Primary item fields:
- `id`
- `created_at`
- `updated_at`
- `active`
- `anchorsite_override`
- `application_name`

---

## Additional Operations

Use the core tasks above first. The operations below are indexed here with exact SDK methods and required params; use the Optional Parameters section below and the shared SDK API Details reference for full optional params, response schemas, and lower-frequency webhook payloads.
Before using any operation below, read the Optional Parameters section below and [the response-schemas section](../../references/sdk-api-details/voice.md#response-schemas) so you do not guess missing fields.

| Operation | SDK method | Endpoint | Use when | Required params |
|-----------|------------|----------|----------|-----------------|
| Create a call control application | HTTP only | `POST /call_control_applications` | Create or provision an additional resource when the core tasks do not cover this flow. | `application_name`, `webhook_event_url` |
| Retrieve a call control application | HTTP only | `GET /call_control_applications/{id}` | Fetch the current state before updating, deleting, or making control-flow decisions. | `id` |
| Update a call control application | HTTP only | `PATCH /call_control_applications/{id}` | Modify an existing resource without recreating it. | `application_name`, `webhook_event_url`, `id` |
| Delete a call control application | HTTP only | `DELETE /call_control_applications/{id}` | Remove, detach, or clean up an existing resource. | `id` |
| SIP Refer a call | HTTP only | `POST /calls/{call_control_id}/actions/refer` | Trigger a follow-up action in an existing workflow rather than creating a new top-level resource. | `sip_address`, `call_control_id` |
| Send SIP info | HTTP only | `POST /calls/{call_control_id}/actions/send_sip_info` | Trigger a follow-up action in an existing workflow rather than creating a new top-level resource. | `content_type`, `body`, `call_control_id` |
| List dial metrics | HTTP only | `GET /dial_metrics` | Inspect available resources or choose an existing resource before mutating it. | None |

### Other Webhook Events

| Event | `data.event_type` | Description |
|-------|-------------------|-------------|
| `callBridged` | `call.bridged` | Call Bridged |

---

For exhaustive optional parameters, full response schemas, and complete webhook payloads, see the Optional Parameters section below and the shared SDK API Details reference.
---

**Do not guess optional fields. Response schemas and webhook payload fields are in [the shared SDK API Details reference](../../references/sdk-api-details/voice.md). Optional parameters for this language are in the Optional Parameters section below.**

## Optional Parameters

### Create a call control application

| Parameter | Type | Description |
|-----------|------|-------------|
| `active` | boolean | Specifies whether the connection can be used. |
| `anchorsite_override` | enum (Latency, Chicago, IL, Ashburn, VA, San Jose, CA, London, UK, ...) | `Latency` directs Telnyx to route media through the site with the lowest roun... |
| `dtmf_type` | enum (RFC 2833, Inband, SIP INFO) | Sets the type of DTMF digits sent from Telnyx to this Connection. |
| `first_command_timeout` | boolean | Specifies whether calls to phone numbers associated with this connection shou... |
| `first_command_timeout_secs` | integer | Specifies how many seconds to wait before timing out a dial command. |
| `inbound` | object |  |
| `outbound` | object |  |
| `webhook_api_version` | enum (1, 2) | Determines which webhook format will be used, Telnyx API v1 or v2. |
| `webhook_event_failover_url` | string (URL) | The failover URL where webhooks related to this connection will be sent if se... |
| `webhook_timeout_secs` | integer | Specifies how many seconds to wait before timing out a webhook. |
| `call_cost_in_webhooks` | boolean | Specifies if call cost webhooks should be sent for this Call Control Applicat... |
| `redact_dtmf_debug_logging` | boolean | When enabled, DTMF digits entered by users will be redacted in debug logs to ... |

### Update a call control application

| Parameter | Type | Description |
|-----------|------|-------------|
| `call_cost_in_webhooks` | boolean | Specifies if call cost webhooks should be sent for this Call Control Applicat... |
| `active` | boolean | Specifies whether the connection can be used. |
| `anchorsite_override` | enum (Latency, Chicago, IL, Ashburn, VA, San Jose, CA, London, UK, ...) | `Latency` directs Telnyx to route media through the site with the lowest roun... |
| `dtmf_type` | enum (RFC 2833, Inband, SIP INFO) | Sets the type of DTMF digits sent from Telnyx to this Connection. |
| `first_command_timeout` | boolean | Specifies whether calls to phone numbers associated with this connection shou... |
| `first_command_timeout_secs` | integer | Specifies how many seconds to wait before timing out a dial command. |
| `tags` | array[string] | Tags assigned to the Call Control Application. |
| `inbound` | object |  |
| `outbound` | object |  |
| `webhook_api_version` | enum (1, 2) | Determines which webhook format will be used, Telnyx API v1 or v2. |
| `webhook_event_failover_url` | string (URL) | The failover URL where webhooks related to this connection will be sent if se... |
| `webhook_timeout_secs` | integer | Specifies how many seconds to wait before timing out a webhook. |
| `redact_dtmf_debug_logging` | boolean | When enabled, DTMF digits entered by users will be redacted in debug logs to ... |

### Dial

| Parameter | Type | Description |
|-----------|------|-------------|
| `assistant` | object | AI Assistant configuration and per-call overrides. |
| `conversation_relay_config` | object | Starts a Conversation Relay session automatically when the answered/dialed ca... |
| `diversion` | string | The `to` number of an active inbound call, in +E164 format. |
| `from_display_name` | string | The `from_display_name` string to be used as the caller id name (SIP From Dis... |
| `privacy` | enum (id, none) | Indicates the privacy level to be used for the call. |
| `audio_url` | string (URL) | The URL of a file to be played back to the callee when the call is answered. |
| `send_digits_on_answer` | string | DTMF digits to send automatically after the called party answers. |
| `media_name` | string | The media_name of a file to be played back to the callee when the call is ans... |
| `preferred_codecs` | string | The list of comma-separated codecs in a preferred order for the forked media ... |
| `timeout_secs` | integer | The number of seconds that Telnyx will wait for the call to be answered by th... |
| `retry_on_timeout` | boolean | Whether to keep trying the remaining routing paths (e.g. |
| `time_limit_secs` | integer | Sets the maximum duration of a Call Control Leg in seconds. |
| `answering_machine_detection` | enum (premium, premium_ios_call_screening_detection, detect, detect_beep, detect_words, ...) | Enables Answering Machine Detection. |
| `answering_machine_detection_config` | object | Optional configuration parameters to modify 'answering_machine_detection' per... |
| `deepfake_detection` | object | Enables deepfake detection on the call. |
| `conference_config` | object | Optional configuration parameters to dial new participant into a conference. |
| `custom_headers` | array[object] | Custom headers to be added to the SIP INVITE. |
| `billing_group_id` | string (UUID) | Use this field to set the Billing Group ID for the call. |
| `client_state` | string | Use this field to add state to every subsequent webhook. |
| `command_id` | string (UUID) | Use this field to avoid duplicate commands. |
| `link_to` | string | Use another call's control id for sharing the same call session id |
| `bridge_intent` | boolean | Indicates the intent to bridge this call with the call specified in link_to. |
| `bridge_on_answer` | boolean | Whether to automatically bridge answered call to the call specified in link_to. |
| `prevent_double_bridge` | boolean | Prevents bridging and hangs up the call if the target is already bridged. |
| `park_after_unbridge` | string | If supplied with the value `self`, the current leg will be parked after unbri... |
| `media_encryption` | enum (disabled, SRTP, DTLS) | Defines whether media should be encrypted on the call. |
| `sip_auth_username` | string | SIP Authentication username used for SIP challenges. |
| `sip_auth_password` | string | SIP Authentication password used for SIP challenges. |
| `sip_headers` | array[object] | SIP headers to be added to the SIP INVITE request. |
| `sip_transport_protocol` | enum (UDP, TCP, TLS) | Defines SIP transport protocol to be used on the call. |
| `sound_modifications` | object | Use this field to modify sound effects, for example adjust the pitch. |
| `stream_url` | string (URL) | The destination WebSocket address where the stream is going to be delivered. |
| `stream_track` | enum (inbound_track, outbound_track, both_tracks) | Specifies which track should be streamed. |
| `stream_codec` | enum (PCMU, PCMA, G722, OPUS, AMR-WB, ...) | Specifies the codec to be used for the streamed audio. |
| `stream_bidirectional_mode` | enum (mp3, rtp) | Configures method of bidirectional streaming (mp3, rtp). |
| `stream_bidirectional_codec` | enum (PCMU, PCMA, G722, OPUS, AMR-WB, ...) | Indicates codec for bidirectional streaming RTP payloads. |
| `stream_bidirectional_target_legs` | enum (both, self, opposite) | Specifies which call legs should receive the bidirectional stream audio. |
| `stream_bidirectional_sampling_rate` | enum (8000, 16000, 22050, 24000, 48000) | Audio sampling rate. |
| `stream_establish_before_call_originate` | boolean | Establish websocket connection before dialing the destination. |
| `send_silence_when_idle` | boolean | Generate silence RTP packets when no transmission available. |
| `webhook_url` | string (URL) | Use this field to override the URL for which Telnyx will send subsequent webh... |
| `webhook_url_method` | enum (POST, GET) | HTTP request type used for `webhook_url`. |
| `webhook_urls` | object | A map of event types to arrays of webhook URLs. |
| `webhook_urls_method` | enum (POST, GET) | HTTP request method to invoke `webhook_urls`. |
| `webhook_retries_policies` | object | A map of event types to retry policies. |
| `record` | enum (record-from-answer) | Start recording automatically after an event. |
| `record_channels` | enum (single, dual) | Defines which channel should be recorded ('single' or 'dual') when `record` i... |
| `record_format` | enum (wav, mp3) | Defines the format of the recording ('wav' or 'mp3') when `record` is specified. |
| `record_max_length` | integer | Defines the maximum length for the recording in seconds when `record` is spec... |
| `record_timeout_secs` | integer | The number of seconds that Telnyx will wait for the recording to be stopped i... |
| `record_track` | enum (both, inbound, outbound) | The audio track to be recorded. |
| `record_trim` | enum (trim-silence) | When set to `trim-silence`, silence will be removed from the beginning and en... |
| `record_custom_file_name` | string | The custom recording file name to be used instead of the default `call_leg_id`. |
| `supervise_call_control_id` | string (UUID) | The call leg which will be supervised by the new call. |
| `supervisor_role` | enum (barge, whisper, monitor) | The role of the supervisor call. |
| `enable_dialogflow` | boolean | Enables Dialogflow for the current call. |
| `dialogflow_config` | object |  |
| `transcription` | boolean | Enable transcription upon call answer. |
| `transcription_config` | object |  |
| `sip_region` | enum (US, Europe, Canada, Australia, Middle East) | Defines the SIP region to be used for the call. |
| `stream_auth_token` | string | An authentication token to be sent as part of the WebSocket connection when u... |
| `route_to_mobile` | boolean | When set to true, routes the call directly to the mobile device associated wi... |

### Answer call

| Parameter | Type | Description |
|-----------|------|-------------|
| `assistant` | object | AI Assistant configuration and per-call overrides. |
| `conversation_relay_config` | object | Starts a Conversation Relay session automatically when the answered/dialed ca... |
| `billing_group_id` | string (UUID) | Use this field to set the Billing Group ID for the call. |
| `client_state` | string | Use this field to add state to every subsequent webhook. |
| `command_id` | string (UUID) | Use this field to avoid duplicate commands. |
| `custom_headers` | array[object] | Custom headers to be added to the SIP INVITE response. |
| `preferred_codecs` | enum (G722,PCMU,PCMA,G729,OPUS,VP8,H264) | The list of comma-separated codecs in a preferred order for the forked media ... |
| `sip_headers` | array[object] | SIP headers to be added to the SIP INVITE response. |
| `sound_modifications` | object | Use this field to modify sound effects, for example adjust the pitch. |
| `stream_url` | string (URL) | The destination WebSocket address where the stream is going to be delivered. |
| `stream_track` | enum (inbound_track, outbound_track, both_tracks) | Specifies which track should be streamed. |
| `stream_codec` | enum (PCMU, PCMA, G722, OPUS, AMR-WB, ...) | Specifies the codec to be used for the streamed audio. |
| `stream_bidirectional_mode` | enum (mp3, rtp) | Configures method of bidirectional streaming (mp3, rtp). |
| `stream_bidirectional_codec` | enum (PCMU, PCMA, G722, OPUS, AMR-WB, ...) | Indicates codec for bidirectional streaming RTP payloads. |
| `stream_bidirectional_target_legs` | enum (both, self, opposite) | Specifies which call legs should receive the bidirectional stream audio. |
| `send_silence_when_idle` | boolean | Generate silence RTP packets when no transmission available. |
| `webhook_url` | string (URL) | Use this field to override the URL for which Telnyx will send subsequent webh... |
| `webhook_url_method` | enum (POST, GET) | HTTP request type used for `webhook_url`. |
| `transcription` | boolean | Enable standalone call transcription upon call answer. |
| `transcription_config` | object |  |
| `record` | enum (record-from-answer) | Start recording automatically after an event. |
| `record_channels` | enum (single, dual) | Defines which channel should be recorded ('single' or 'dual') when `record` i... |
| `record_format` | enum (wav, mp3) | Defines the format of the recording ('wav' or 'mp3') when `record` is specified. |
| `record_max_length` | integer | Defines the maximum length for the recording in seconds when `record` is spec... |
| `record_timeout_secs` | integer | The number of seconds that Telnyx will wait for the recording to be stopped i... |
| `record_track` | enum (both, inbound, outbound) | The audio track to be recorded. |
| `record_trim` | enum (trim-silence) | When set to `trim-silence`, silence will be removed from the beginning and en... |
| `record_custom_file_name` | string | The custom recording file name to be used instead of the default `call_leg_id`. |
| `webhook_urls` | object | A map of event types to arrays of webhook URLs. |
| `webhook_urls_method` | enum (POST, GET) | HTTP request method to invoke `webhook_urls`. |
| `webhook_retries_policies` | object | A map of event types to retry policies. |
| `deepfake_detection` | object | Enables deepfake detection on the call. |

### Bridge calls

| Parameter | Type | Description |
|-----------|------|-------------|
| `client_state` | string | Use this field to add state to every subsequent webhook. |
| `command_id` | string (UUID) | Use this field to avoid duplicate commands. |
| `queue` | string | The name of the queue you want to bridge with, can't be used together with ca... |
| `video_room_id` | string (UUID) | The ID of the video room you want to bridge with, can't be used together with... |
| `video_room_context` | string | The additional parameter that will be passed to the video conference. |
| `prevent_double_bridge` | boolean | When set to `true`, it prevents bridging if the target call is already bridge... |
| `park_after_unbridge` | string | Specifies behavior after the bridge ends (i.e. |
| `play_ringtone` | boolean | Specifies whether to play a ringtone if the call you want to bridge with has ... |
| `ringtone` | enum (at, au, be, bg, br, ...) | Specifies which country ringtone to play when `play_ringtone` is set to `true`. |
| `record` | enum (record-from-answer) | Start recording automatically after an event. |
| `record_channels` | enum (single, dual) | Defines which channel should be recorded ('single' or 'dual') when `record` i... |
| `record_format` | enum (wav, mp3) | Defines the format of the recording ('wav' or 'mp3') when `record` is specified. |
| `record_max_length` | integer | Defines the maximum length for the recording in seconds when `record` is spec... |
| `record_timeout_secs` | integer | The number of seconds that Telnyx will wait for the recording to be stopped i... |
| `record_track` | enum (both, inbound, outbound) | The audio track to be recorded. |
| `record_trim` | enum (trim-silence) | When set to `trim-silence`, silence will be removed from the beginning and en... |
| `record_custom_file_name` | string | The custom recording file name to be used instead of the default `call_leg_id`. |
| `mute_dtmf` | enum (none, both, self, opposite) | When enabled, DTMF tones are not passed to the call participant. |
| `hold_after_unbridge` | boolean | Specifies behavior after the bridge ends. |

### Hangup call

| Parameter | Type | Description |
|-----------|------|-------------|
| `client_state` | string | Use this field to add state to every subsequent webhook. |
| `command_id` | string (UUID) | Use this field to avoid duplicate commands. |
| `custom_headers` | array[object] | Custom headers to be added to the SIP BYE message. |
| `reason` | string | Text for the SIP `Reason` header (RFC 3326) sent when cancelling an unanswere... |

### SIP Refer a call

| Parameter | Type | Description |
|-----------|------|-------------|
| `client_state` | string | Use this field to add state to every subsequent webhook. |
| `command_id` | string (UUID) | Use this field to avoid execution of duplicate commands. |
| `custom_headers` | array[object] | Custom headers to be added to the SIP INVITE. |
| `sip_auth_username` | string | SIP Authentication username used for SIP challenges. |
| `sip_auth_password` | string | SIP Authentication password used for SIP challenges. |
| `sip_headers` | array[object] | SIP headers to be added to the request. |

### Reject a call

| Parameter | Type | Description |
|-----------|------|-------------|
| `client_state` | string | Use this field to add state to every subsequent webhook. |
| `command_id` | string (UUID) | Use this field to avoid duplicate commands. |

### Send SIP info

| Parameter | Type | Description |
|-----------|------|-------------|
| `client_state` | string | Use this field to add state to every subsequent webhook. |
| `command_id` | string (UUID) | Use this field to avoid duplicate commands. |

### Transfer call

| Parameter | Type | Description |
|-----------|------|-------------|
| `from` | string (E.164) | The `from` number to be used as the caller id presented to the destination (`... |
| `diversion` | string | The `to` number of an active inbound call, in +E164 format. |
| `from_display_name` | string | The `from_display_name` string to be used as the caller id name (SIP From Dis... |
| `privacy` | enum (id, none) | Indicates the privacy level to be used for the call. |
| `audio_url` | string (URL) | The URL of a file to be played back when the transfer destination answers bef... |
| `send_digits_on_answer` | string | DTMF digits to send automatically after the transfer destination answers. |
| `early_media` | boolean | If set to false, early media will not be passed to the originating leg. |
| `media_name` | string | The media_name of a file to be played back when the transfer destination answ... |
| `timeout_secs` | integer | The number of seconds that Telnyx will wait for the call to be answered by th... |
| `time_limit_secs` | integer | Sets the maximum duration of a Call Control Leg in seconds. |
| `park_after_unbridge` | string | Specifies behavior after the bridge ends (i.e. |
| `answering_machine_detection` | enum (premium, premium_ios_call_screening_detection, detect, detect_beep, detect_words, ...) | Enables Answering Machine Detection. |
| `answering_machine_detection_config` | object | Optional configuration parameters to modify 'answering_machine_detection' per... |
| `custom_headers` | array[object] | Custom headers to be added to the SIP INVITE. |
| `client_state` | string | Use this field to add state to every subsequent webhook. |
| `target_leg_client_state` | string | Use this field to add state to every subsequent webhook for the new leg. |
| `command_id` | string (UUID) | Use this field to avoid duplicate commands. |
| `media_encryption` | enum (disabled, SRTP, DTLS) | Defines whether media should be encrypted on the new call leg. |
| `sip_auth_username` | string | SIP Authentication username used for SIP challenges. |
| `sip_auth_password` | string | SIP Authentication password used for SIP challenges. |
| `sip_headers` | array[object] | SIP headers to be added to the SIP INVITE. |
| `sip_transport_protocol` | enum (UDP, TCP, TLS) | Defines SIP transport protocol to be used on the call. |
| `sound_modifications` | object | Use this field to modify sound effects, for example adjust the pitch. |
| `webhook_url` | string (URL) | Use this field to override the URL for which Telnyx will send subsequent webh... |
| `webhook_url_method` | enum (POST, GET) | HTTP request type used for `webhook_url`. |
| `mute_dtmf` | enum (none, both, self, opposite) | When enabled, DTMF tones are not passed to the call participant. |
| `record` | enum (record-from-answer) | Start recording automatically after an event. |
| `record_channels` | enum (single, dual) | Defines which channel should be recorded ('single' or 'dual') when `record` i... |
| `record_format` | enum (wav, mp3) | Defines the format of the recording ('wav' or 'mp3') when `record` is specified. |
| `record_max_length` | integer | Defines the maximum length for the recording in seconds when `record` is spec... |
| `record_timeout_secs` | integer | The number of seconds that Telnyx will wait for the recording to be stopped i... |
| `record_track` | enum (both, inbound, outbound) | The audio track to be recorded. |
| `record_trim` | enum (trim-silence) | When set to `trim-silence`, silence will be removed from the beginning and en... |
| `record_custom_file_name` | string | The custom recording file name to be used instead of the default `call_leg_id`. |
| `sip_region` | enum (US, Europe, Canada, Australia, Middle East) | Defines the SIP region to be used for the call. |
| `preferred_codecs` | string | The list of comma-separated codecs in order of preference to be used during t... |
| `webhook_urls` | object | A map of event types to arrays of webhook URLs. |
| `webhook_urls_method` | enum (POST, GET) | HTTP request method to invoke `webhook_urls`. |
| `webhook_retries_policies` | object | A map of event types to retry policies. |
| `route_to_mobile` | boolean | When set to true, routes the call directly to the mobile device associated wi... |
