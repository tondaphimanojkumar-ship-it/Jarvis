import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { mkdtempSync, mkdirSync, readFileSync, writeFileSync, chmodSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const CLI = join(__dirname, "..", "bin", "telnyx-agent.ts");

type AuthMode = "none" | "oauth" | "api_key" | "expired_oauth" | "unknown";
type FakeEdgeOptions = {
  auth?: AuthMode;
  rootStatus?: "pass" | "fail" | "unknown";
  inspect?: boolean;
  actorInstances?: boolean;
  actorMetrics?: boolean;
  actorMetricsTypeUsage?: boolean;
  actorMetricsSince?: boolean;
  actorMetricsJson?: boolean;
  newFuncFromDir?: boolean;
  secretsAdd?: boolean;
  ship?: boolean;
  shipStatusFunctionUsage?: boolean;
  shipStatusLogs?: boolean;
  runtimeLogsFunctionUsage?: boolean;
  runtimeLogsSince?: boolean;
  runtimeLogsLast?: boolean;
  runtimeLogsJson?: boolean;
  invocationLogsType?: boolean;
  invocationLogsRuntime?: boolean;
  invocationLogsInvocations?: boolean;
  liveLogTail?: boolean;
  logExport?: boolean;
  logExportEndpoint?: boolean;
  logExportHeader?: boolean;
  logExportRuntime?: boolean;
  logExportInvocations?: boolean;
  logExportGetJson?: boolean;
  logExportDeleteYes?: boolean;
  metrics?: boolean;
  metricsFunctionUsage?: boolean;
  metricsSince?: boolean;
  metricsErrors?: boolean;
  metricsJson?: boolean;
  deployments?: boolean;
  deploymentsFunctionUsage?: boolean;
  deploymentsJson?: boolean;
  deploymentsFailureReason?: boolean;
  resetFunc?: boolean;
  resetNoninteractiveConfirmation?: boolean;
  noninteractiveConfirmation?: boolean;
  types?: boolean;
  typesHelp?: string;
  kvStorage?: boolean;
  kvKeyManagement?: boolean;
  sqlDatabases?: boolean;
  sqlParam?: boolean;
  sqlParamJson?: boolean;
  sqlDatabaseExport?: boolean;
  sqlDatabaseExportNoSchema?: boolean;
  sqlDatabaseExportStdout?: boolean;
  sqlStdinImport?: boolean;
  customDomainCommands?: Array<"add" | "verify" | "list" | "delete" | "cert">;
  customDomainCertUpload?: boolean;
  customDomainCertFlag?: boolean;
  customDomainKeyFlag?: boolean;
  customDomainDeleteYes?: boolean;
  argLog?: boolean;
};

function withFakeEdgeCli(options: FakeEdgeOptions | AuthMode = "api_key") {
  const config: FakeEdgeOptions = typeof options === "string" ? { auth: options } : options;
  const auth = config.auth ?? "api_key";
  const rootStatus = config.rootStatus ?? (auth === "api_key" || auth === "oauth" ? "pass" : "fail");
  const inspect = config.inspect ?? true;
  const actorInstances = config.actorInstances ?? true;
  const actorMetrics = config.actorMetrics ?? true;
  const actorMetricsTypeUsage = config.actorMetricsTypeUsage ?? true;
  const actorMetricsSince = config.actorMetricsSince ?? true;
  const actorMetricsJson = config.actorMetricsJson ?? true;
  const newFuncFromDir = config.newFuncFromDir ?? true;
  const secretsAdd = config.secretsAdd ?? true;
  const ship = config.ship ?? true;
  const shipStatusFunctionUsage = config.shipStatusFunctionUsage ?? true;
  const shipStatusLogs = config.shipStatusLogs ?? true;
  const runtimeLogsFunctionUsage = config.runtimeLogsFunctionUsage ?? true;
  const runtimeLogsSince = config.runtimeLogsSince ?? true;
  const runtimeLogsLast = config.runtimeLogsLast ?? true;
  const runtimeLogsJson = config.runtimeLogsJson ?? true;
  const invocationLogsType = config.invocationLogsType ?? true;
  const invocationLogsRuntime = config.invocationLogsRuntime ?? true;
  const invocationLogsInvocations = config.invocationLogsInvocations ?? true;
  const liveLogTail = config.liveLogTail ?? true;
  const logExport = config.logExport ?? true;
  const logExportEndpoint = config.logExportEndpoint ?? true;
  const logExportHeader = config.logExportHeader ?? true;
  const logExportRuntime = config.logExportRuntime ?? true;
  const logExportInvocations = config.logExportInvocations ?? true;
  const logExportGetJson = config.logExportGetJson ?? true;
  const logExportDeleteYes = config.logExportDeleteYes ?? true;
  const metrics = config.metrics ?? true;
  const metricsFunctionUsage = config.metricsFunctionUsage ?? true;
  const metricsSince = config.metricsSince ?? true;
  const metricsErrors = config.metricsErrors ?? true;
  const metricsJson = config.metricsJson ?? true;
  const deployments = config.deployments ?? true;
  const deploymentsFunctionUsage = config.deploymentsFunctionUsage ?? true;
  const deploymentsJson = config.deploymentsJson ?? true;
  const deploymentsFailureReason = config.deploymentsFailureReason ?? true;
  const resetFunc = config.resetFunc ?? true;
  const resetNoninteractiveConfirmation = config.resetNoninteractiveConfirmation ?? false;
  const noninteractiveConfirmation = config.noninteractiveConfirmation ?? true;
  const types = config.types ?? true;
  const typesHelp = config.typesHelp ?? "Generate TypeScript binding types\nUsage: telnyx-edge types [flags]";
  const kvStorage = config.kvStorage ?? true;
  const kvKeyManagement = config.kvKeyManagement ?? true;
  const sqlDatabases = config.sqlDatabases ?? true;
  const sqlParam = config.sqlParam ?? true;
  const sqlParamJson = config.sqlParamJson ?? true;
  const sqlDatabaseExport = config.sqlDatabaseExport ?? true;
  const sqlDatabaseExportNoSchema = config.sqlDatabaseExportNoSchema ?? true;
  const sqlDatabaseExportStdout = config.sqlDatabaseExportStdout ?? true;
  const sqlStdinImport = config.sqlStdinImport ?? true;
  const customDomainCommands = config.customDomainCommands ?? ["add", "verify", "list", "delete", "cert"];
  const customDomainCertUpload = config.customDomainCertUpload ?? true;
  const customDomainCertFlag = config.customDomainCertFlag ?? true;
  const customDomainKeyFlag = config.customDomainKeyFlag ?? true;
  const customDomainDeleteYes = config.customDomainDeleteYes ?? true;
  const tempDir = mkdtempSync(join(tmpdir(), "telnyx-edge-fake-"));
  const binDir = join(tempDir, "bin");
  const argsLog = join(tempDir, "args.jsonl");
  mkdirSync(binDir, { recursive: true });
  const fakeEdge = join(binDir, "telnyx-edge");
  writeFileSync(
    fakeEdge,
    `#!/usr/bin/env node
const args = process.argv.slice(2);
if (process.env.EDGE_ARGS_LOG) {
  require('node:fs').appendFileSync(process.env.EDGE_ARGS_LOG, JSON.stringify(args) + "\\n");
}
if (args.includes('--version')) {
  console.log('telnyx-edge v0.5.0');
  process.exit(0);
}
if (args[0] === 'new-func' && args.includes('--help')) {
  console.log(['Create a new edge computing function', '', 'Usage: telnyx-edge new-func [flags]', '', 'Flags:', '      --actor             Scaffold a StatefulActor project', ...(${newFuncFromDir} ? ['      --from-dir string   Copy files from existing directory'] : []), '  -h, --help              help for new-func', '  -n, --name string       Name of the function to create'].join('\\n'));
  process.exit(0);
}
if (args[0] === 'auth' && args[1] === 'api-key' && args[2] === 'set' && args.includes('--help')) {
  console.log('Set API key for authentication. The API key must be provided as an argument.');
  process.exit(0);
}
if (args[0] === 'secrets' && args[1] === 'add' && args.includes('--help')) {
  if (${secretsAdd}) {
    console.log('Add or update a secret\\nUsage: telnyx-edge secrets add <key> <value> [flags]');
    process.exit(0);
  }
  process.stderr.write('unknown command "add"\\n');
  process.exit(1);
}
if (args[0] === 'ship' && args[1] === 'status' && args.includes('--help')) {
  console.log(['Show why a function ship failed', 'Usage: telnyx-edge ship status ${shipStatusFunctionUsage ? "<function>" : "[flags]"}', ...(${shipStatusLogs} ? ['      --logs  Also print the build log or crash output'] : [])].join('\\n'));
  process.exit(0);
}
if (args[0] === 'logs' && args.includes('--help')) {
  console.log(['Read deployed function runtime logs', 'Usage: telnyx-edge logs ${runtimeLogsFunctionUsage ? "<function>" : "[flags]"}', ...(${runtimeLogsSince} ? ['      --since duration  Look back over a historical window'] : []), ...(${runtimeLogsLast} ? ['  -n, --last int  Maximum number of log lines'] : []), ...(${runtimeLogsJson} ? ['      --json  Print JSON output'] : []), ...(${liveLogTail} ? ['      --tail  Stream live logs until interrupted'] : []), ...(${invocationLogsType} ? ['      --type string  Select ' + (${invocationLogsRuntime} ? 'runtime' : '') + (${invocationLogsInvocations} ? ' invocations' : '') + ' logs'] : [])].join('\\n'));
  process.exit(0);
}
if (args[0] === 'log-export' && args[1] === 'set' && args.includes('--help')) {
  if (${logExport}) {
    console.log(['Configure OTLP log export', 'Usage: telnyx-edge log-export set <function> [flags]', ...(${logExportEndpoint} ? ['      --endpoint string  HTTPS OTLP endpoint'] : []), ...(${logExportHeader} ? ['      --header strings  Header to attach to every export'] : []), ...(${logExportRuntime} ? ['      --runtime  Export runtime logs'] : []), ...(${logExportInvocations} ? ['      --invocations  Export invocation logs'] : [])].join('\\n'));
    process.exit(0);
  }
  process.stderr.write('unknown command "log-export"\\n');
  process.exit(1);
}
if (args[0] === 'log-export' && args[1] === 'get' && args.includes('--help')) {
  if (${logExport}) {
    console.log(['Show OTLP log-export configuration', 'Usage: telnyx-edge log-export get <function> [flags]', ...(${logExportGetJson} ? ['      --json  Print JSON output'] : [])].join('\\n'));
    process.exit(0);
  }
  process.stderr.write('unknown command "log-export"\\n');
  process.exit(1);
}
if (args[0] === 'log-export' && args[1] === 'delete' && args.includes('--help')) {
  if (${logExport}) {
    console.log(['Delete OTLP log-export configuration', 'Usage: telnyx-edge log-export delete <function> [flags]', ...(${logExportDeleteYes} ? ['  -y, --yes  Skip the confirmation prompt'] : [])].join('\\n'));
    process.exit(0);
  }
  process.stderr.write('unknown command "log-export"\\n');
  process.exit(1);
}
if (args[0] === 'metrics' && args.includes('--help')) {
  if (${metrics}) {
    console.log(['Summarize function request and resource metrics', 'Usage: telnyx-edge metrics ${metricsFunctionUsage ? "<function>" : "[flags]"}', ...(${metricsSince} ? ['      --since duration  Look back over a window'] : []), ...(${metricsErrors} ? ['      --errors  Show the HTTP-error view'] : []), ...(${metricsJson} ? ['      --json  Print raw aggregate JSON'] : [])].join('\\n'));
    process.exit(0);
  }
  process.stderr.write('unknown command "metrics"\\n');
  process.exit(1);
}
if (args[0] === 'deployments' && args.includes('--help')) {
  if (${deployments}) {
    console.log(['Show function deploy history with failure reasons', 'Usage: telnyx-edge deployments ${deploymentsFunctionUsage ? "<function>" : "[flags]"}', ...(${deploymentsJson} ? ['      --json  Print API response JSON'] : []), ...(${deploymentsFailureReason} ? ['Show each failed ship stage and reason'] : [])].join('\\n'));
    process.exit(0);
  }
  process.stderr.write('unknown command "deployments"\\n');
  process.exit(1);
}
if (args[0] === 'ship' && args.includes('--help')) {
  if (${ship}) {
    console.log('Ship a function to Telnyx edge infrastructure\\nUsage: telnyx-edge ship [flags]');
    process.exit(0);
  }
  process.stderr.write('unknown command "ship"\\n');
  process.exit(1);
}
if (args[0] === 'reset-func' && args.includes('--help')) {
  if (${resetFunc}) {
    console.log(['Reset a failed function back to the created state', 'Usage: telnyx-edge reset-func <function-name> [flags]', ...(${resetNoninteractiveConfirmation} ? ['  -y, --yes  Skip the confirmation prompt (for scripts and CI)'] : [])].join('\\n'));
    process.exit(0);
  }
  process.stderr.write('unknown command "reset-func"\\n');
  process.exit(1);
}
if (args[0] === 'delete-func' && args.includes('--help')) {
  if (${noninteractiveConfirmation}) {
    console.log('Delete an edge function after confirmation\\n  -y, --yes  Skip the confirmation prompt (for scripts and CI)');
    process.exit(0);
  }
  console.log('Delete an edge function');
  process.exit(0);
}
if (args[0] === 'types' && args.includes('--help')) {
  if (${types}) {
    console.log(${JSON.stringify(typesHelp)});
    process.exit(0);
  }
  process.stderr.write('unknown command "types"\\n');
  process.exit(1);
}
if (args[0] === 'storage' && args[1] === 'kv' && args[2] === 'key' && args.includes('--help')) {
  if (${kvKeyManagement}) {
    console.log('Manage keys in a KV namespace\\nUsage: telnyx-edge storage kv key [command]\\nCommands: list get put delete');
    process.exit(0);
  }
  process.stderr.write('unknown command "key"\\n');
  process.exit(1);
}
if (args[0] === 'storage' && args[1] === 'kv' && args.includes('--help')) {
  if (${kvStorage}) {
    console.log('Manage KV storage namespaces\\nUsage: telnyx-edge storage kv [command]\\nCommands: create list get delete key');
    process.exit(0);
  }
  process.stderr.write('unknown command "kv"\\n');
  process.exit(1);
}
if (args[0] === 'storage' && args[1] === 'sqldb' && args[2] === 'execute' && args.includes('--help')) {
  if (${sqlDatabases}) {
    console.log(['Run SQL against a SQL database', 'Usage: telnyx-edge storage sqldb execute <database> [flags]', '--remote  --command string  --file string', ...(${sqlStdinImport} ? ['Use --file - for standard input'] : []), ...(${sqlParam} ? ['--param string'] : []), ...(${sqlParamJson} ? ['--param-json string'] : [])].join('\\n'));
    process.exit(0);
  }
  console.log('Usage: telnyx-edge storage sqldb execute <database> [flags]\\n--remote --command string');
  process.exit(0);
}
if (args[0] === 'storage' && args[1] === 'sqldb' && args[2] === 'export' && args.includes('--help')) {
  if (${sqlDatabaseExport}) {
    console.log(['Export a remote SQL database', 'Usage: telnyx-edge storage sqldb export <database> [flags]', '--remote  --table strings  --no-data', '--output string  Path to SQL file' + (${sqlDatabaseExportStdout} ? ' (- writes to stdout)' : ''), ...(${sqlDatabaseExportNoSchema} ? ['--no-schema'] : [])].join('\\n'));
    process.exit(0);
  }
  process.stderr.write('unknown command "export"\\n');
  process.exit(1);
}
if (args[0] === 'domains' && args[1] === 'cert' && args[2] === 'upload' && args.includes('--help')) {
  if (${customDomainCertUpload}) {
    console.log(['Upload a TLS certificate for a custom domain', 'Usage: telnyx-edge domains cert upload <hostname> [flags]', ...(${customDomainCertFlag} ? ['      --cert string  Path to PEM-encoded TLS certificate file'] : []), ...(${customDomainKeyFlag} ? ['      --key string   Path to PEM-encoded private key file'] : [])].join('\\n'));
    process.exit(0);
  }
  process.stderr.write('unknown command "upload"\\n');
  process.exit(1);
}
if (args[0] === 'domains' && args[1] === 'delete' && args.includes('--help')) {
  console.log(['Delete a custom domain mapping', 'Usage: telnyx-edge domains delete <hostname> [flags]', ...(${customDomainDeleteYes} ? ['  -y, --yes  Skip the confirmation prompt (for scripts and CI)'] : [])].join('\\n'));
  process.exit(0);
}
if (args[0] === 'domains' && args.length === 2 && args.includes('--help')) {
  const commands = ${JSON.stringify(customDomainCommands)};
  console.log(['Manage custom domains for edge computing functions', 'Usage: telnyx-edge domains [command]', 'Available Commands:', ...commands.map((command) => '  ' + command)].join('\\n'));
  process.exit(0);
}
if (args[0] === 'inspect' && args.includes('--help')) {
  if (${inspect}) {
    console.log('Usage: telnyx-edge inspect <function>\\nShow a function full details and actor bindings');
    process.exit(0);
  }
  process.stderr.write('unknown command "inspect"\\n');
  process.exit(1);
}
if (args[0] === 'actors' && args[1] === 'instances' && args.includes('--help')) {
  if (${actorInstances}) {
    console.log('Usage: telnyx-edge actors instances <type>\\nList persisted instances of an actor type');
    process.exit(0);
  }
  process.stderr.write('unknown command "instances"\\n');
  process.exit(1);
}
if (args[0] === 'actors' && args[1] === 'metrics' && args.includes('--help')) {
  if (${actorMetrics}) {
    console.log(['Summarize StatefulActor request and resource metrics', 'Usage: telnyx-edge actors metrics ${actorMetricsTypeUsage ? "<type>" : "[flags]"}', ...(${actorMetricsSince} ? ['      --since duration  Look back over a window'] : []), ...(${actorMetricsJson} ? ['      --json  Print raw aggregate JSON'] : [])].join('\\n'));
    process.exit(0);
  }
  process.stderr.write('unknown command "metrics"\\n');
  process.exit(1);
}
if (args.length === 1 && args[0] === '--help') {
  console.log(['Telnyx Edge CLI v0.5.0', '', 'Available Commands:', '  actors      Manage StatefulActor types', '  inspect     Show function details', '  auth        Authentication commands', '  ship        Ship a function', '  storage     Manage storage'].join('\\n'));
  process.exit(0);
}
if (args[0] === 'auth' && args[1] === 'status') {
  if ('${auth}' === 'none') {
    console.log(['API Endpoint: https://api.telnyx.com', '', 'Authentication Status: None', 'Status: ❌ Not authenticated'].join('\\n'));
    process.exit(0);
  }
  if ('${auth}' === 'unknown') {
    console.log('Authentication cache loaded; contact support for details');
    process.exit(0);
  }
  if ('${auth}' === 'expired_oauth') {
    console.log(['API Endpoint: https://api.telnyx.com', '', 'Authentication Status: OAuth 2.0', 'Status: ⚠️ Token expired - run telnyx-edge auth login to refresh'].join('\\n'));
    process.exit(0);
  }
  if ('${auth}' === 'oauth') {
    console.log(['API Endpoint: https://api.telnyx.com', '', 'Authentication Status: OAuth 2.0', 'Status: ✓ Authenticated'].join('\\n'));
    process.exit(0);
  }
  console.log(['API Endpoint: https://api.telnyx.com', '', 'Authentication Status: API Key', 'Status: ✓ Authenticated'].join('\\n'));
  process.exit(0);
}
if (args.length === 1 && args[0] === 'status') {
  if ('${rootStatus}' === 'pass') {
    console.log(['Telnyx Edge CLI Status Check', '✅ Config file OK', '✅ Reachable: https://api.telnyx.com (HTTP 200)', '✅ API key is valid', '', '✅ All checks passed - CLI is ready to use'].join('\\n'));
    process.exit(0);
  }
  if ('${rootStatus}' === 'unknown') {
    console.log('Status command completed');
    process.exit(0);
  }
  console.log(['Telnyx Edge CLI Status Check', '✅ Config file OK', '❌ Failed: Cannot reach https://api.telnyx.com', '', '❌ Some checks failed - please review the issues above'].join('\\n'));
  process.exit(0);
}
console.log('ok');
`,
  );
  chmodSync(fakeEdge, 0o755);
  return {
    argsLog,
    env: {
      ...process.env,
      PATH: `${binDir}:${process.env.PATH}`,
      TELNYX_EDGE_PATH: fakeEdge,
      ...(config.argLog ? { EDGE_ARGS_LOG: argsLog } : {}),
    },
  };
}

function run(args: string[], env?: NodeJS.ProcessEnv): string {
  return execFileSync("npx", ["tsx", CLI, ...args], {
    encoding: "utf8",
    timeout: 30000,
    env: env ?? { ...process.env },
  });
}

function runError(args: string[], env?: NodeJS.ProcessEnv): string {
  try {
    run(args, env);
    assert.fail("expected command to fail");
  } catch (err: any) {
    return `${err?.stdout?.toString?.() ?? ""}${err?.stderr?.toString?.() ?? ""}`;
  }
}

describe("CLI — Edge Compute handoff", () => {
  it("help lists edge handoff commands", () => {
    const output = run(["help"]);
    assert.ok(output.includes("edge-doctor"));
    assert.ok(output.includes("setup-edge-mcp"));
    assert.ok(output.includes("setup-edge-webhook"));
  });

  it("capabilities JSON includes edge handoff and stateful actor entries", () => {
    const data = JSON.parse(run(["capabilities", "--json"]));
    const category = Object.keys(data.api_capabilities || {}).find((key) => key.includes("Edge Compute"));
    assert.ok(category);
    const commands = data.composite_commands.map((entry: any) => entry.name || entry.command || entry);
    assert.ok(commands.some((command: string) => command.includes("edge-doctor")));
    assert.ok(commands.some((command: string) => command.includes("setup-edge-mcp")));
    assert.ok(commands.some((command: string) => command.includes("setup-edge-webhook")));
    const actor = data.api_capabilities[category as string]
      .find((entry: { name: string }) => entry.name === "Stateful Actors");
    assert.ok(actor?.description.toLowerCase().includes("per-entity"));
  });

  it("edge-doctor requires positive auth and the root connectivity/status check", () => {
    const fake = withFakeEdgeCli({ auth: "api_key", rootStatus: "pass" });
    const data = JSON.parse(run(["edge-doctor", "--json"], fake.env));
    assert.equal(data.ready, true);
    assert.equal(data.telnyx_edge_installed, true);
    assert.equal(data.telnyx_edge_version, "v0.5.0");
    assert.equal(data.authenticated, true);
    assert.equal(data.auth_mode, "api_key");
    assert.equal(data.root_status_passed, true);
    assert.equal(data.api_key_auth_supported, true);
    assert.equal(data.new_func_from_dir_supported, true);
    assert.equal(data.secrets_add_supported, true);
    assert.equal(data.ship_supported, true);
    assert.equal(data.ship_status_supported, true);
    assert.equal(data.runtime_logs_supported, true);
    assert.equal(data.invocation_logs_supported, true);
    assert.equal(data.live_log_tail_supported, true);
    assert.equal(data.log_export_supported, true);
    assert.equal(data.function_metrics_supported, true);
    assert.equal(data.deployments_supported, true);
    assert.equal(data.stateful_actors_supported, true);
    assert.equal(data.inspect_supported, true);
    assert.equal(data.actor_instances_supported, true);
    assert.equal(data.actor_metrics_supported, true);
    assert.equal(data.reset_func_supported, true);
    assert.equal(data.noninteractive_confirmation_supported, true);
    assert.equal(data.types_supported, true);
    assert.equal(data.kv_storage_supported, true);
    assert.equal(data.kv_key_management_supported, true);
    assert.equal(data.sql_databases_supported, true);
    assert.equal(data.sql_bound_parameters_supported, true);
    assert.equal(data.sql_database_export_supported, true);
    assert.equal(data.sql_stdin_import_supported, true);
    assert.equal(data.custom_domains_supported, true);
  });

  it("edge-doctor stays unready when root status exits zero but reports a failed check", () => {
    const fake = withFakeEdgeCli({ auth: "api_key", rootStatus: "fail" });
    const data = JSON.parse(run(["edge-doctor", "--json"], fake.env));
    assert.equal(data.authenticated, true);
    assert.equal(data.root_status_passed, false);
    assert.equal(data.ready, false);
    assert.ok(data.next_steps.some((step: string) => step.includes("telnyx-edge status")));
  });

  it("edge-doctor does not treat unknown auth output as authenticated", () => {
    const fake = withFakeEdgeCli({ auth: "unknown", rootStatus: "pass" });
    const data = JSON.parse(run(["edge-doctor", "--json"], fake.env));
    assert.equal(data.auth_mode, "unknown");
    assert.equal(data.authenticated, false);
    assert.equal(data.root_status_passed, true);
    assert.equal(data.ready, false);
  });

  it("edge-doctor rejects none and expired OAuth auth states", () => {
    for (const auth of ["none", "expired_oauth"] as const) {
      const fake = withFakeEdgeCli({ auth });
      const data = JSON.parse(run(["edge-doctor", "--json"], fake.env));
      assert.equal(data.authenticated, false);
      assert.equal(data.ready, false);
    }
  });

  it("edge-doctor probes inspect and actor instances instead of inferring from version", () => {
    const fake = withFakeEdgeCli({ auth: "api_key", inspect: false, actorInstances: false, argLog: true });
    const data = JSON.parse(run(["edge-doctor", "--json"], fake.env));
    assert.equal(data.telnyx_edge_version, "v0.5.0");
    assert.equal(data.inspect_supported, false);
    assert.equal(data.actor_instances_supported, false);
    const calls = readFileSync(fake.argsLog, "utf8").trim().split("\n").map((line) => JSON.parse(line));
    assert.ok(calls.some((args) => JSON.stringify(args) === JSON.stringify(["inspect", "--help"])));
    assert.ok(calls.some((args) => JSON.stringify(args) === JSON.stringify(["actors", "instances", "--help"])));
  });

  it("edge-doctor probes optional capabilities conservatively instead of inferring from version", () => {
    const fake = withFakeEdgeCli({
      auth: "api_key",
      resetFunc: false,
      noninteractiveConfirmation: false,
      types: false,
      kvStorage: false,
      kvKeyManagement: false,
      sqlDatabases: false,
      shipStatusFunctionUsage: false,
      shipStatusLogs: false,
      runtimeLogsSince: false,
      invocationLogsType: false,
      liveLogTail: false,
      logExport: false,
      metrics: false,
      deployments: false,
      sqlParam: false,
      sqlParamJson: false,
      sqlDatabaseExport: false,
      sqlStdinImport: false,
      actorMetrics: false,
      argLog: true,
    });
    const data = JSON.parse(run(["edge-doctor", "--json"], fake.env));
    assert.equal(data.telnyx_edge_version, "v0.5.0");
    assert.equal(data.ready, true, "optional capabilities do not block the core handoff");
    assert.equal(data.ship_status_supported, false);
    assert.equal(data.runtime_logs_supported, false);
    assert.equal(data.invocation_logs_supported, false);
    assert.equal(data.live_log_tail_supported, false);
    assert.equal(data.log_export_supported, false);
    assert.equal(data.function_metrics_supported, false);
    assert.equal(data.deployments_supported, false);
    assert.equal(data.reset_func_supported, false);
    assert.equal(data.noninteractive_confirmation_supported, false);
    assert.equal(data.types_supported, false);
    assert.equal(data.kv_storage_supported, false);
    assert.equal(data.kv_key_management_supported, false);
    assert.equal(data.sql_databases_supported, false);
    assert.equal(data.sql_bound_parameters_supported, false);
    assert.equal(data.sql_database_export_supported, false);
    assert.equal(data.sql_stdin_import_supported, false);
    assert.equal(data.actor_metrics_supported, false);
    assert.ok(data.next_steps.some((step: string) => step.includes("Optional capabilities not detected")));
    const calls = readFileSync(fake.argsLog, "utf8").trim().split("\n").map((line) => JSON.parse(line));
    for (const expected of [
      ["reset-func", "--help"],
      ["ship", "status", "--help"],
      ["logs", "--help"],
      ["log-export", "set", "--help"],
      ["metrics", "--help"],
      ["deployments", "--help"],
      ["delete-func", "--help"],
      ["secrets", "add", "--help"],
      ["types", "--help"],
      ["storage", "kv", "--help"],
      ["storage", "kv", "key", "--help"],
      ["storage", "sqldb", "execute", "--help"],
      ["storage", "sqldb", "export", "--help"],
      ["actors", "metrics", "--help"],
    ]) {
      assert.ok(calls.some((args) => JSON.stringify(args) === JSON.stringify(expected)), `missing probe ${expected.join(" ")}`);
    }
  });

  it("requires function usage and --logs on the ship status help surface", () => {
    for (const config of [
      { shipStatusFunctionUsage: false },
      { shipStatusLogs: false },
    ]) {
      const fake = withFakeEdgeCli({ auth: "api_key", ...config, argLog: true });
      const data = JSON.parse(run(["edge-doctor", "--json"], fake.env));
      assert.equal(data.ready, true, "ship diagnostics remain optional for setup handoffs");
      assert.equal(data.ship_supported, true, "the existing ship compatibility field is unchanged");
      assert.equal(data.ship_status_supported, false);
      assert.ok(data.next_steps.some((step: string) => step.includes("ship status <function> --logs diagnostics")));
      const calls = readFileSync(fake.argsLog, "utf8").trim().split("\n").map((line) => JSON.parse(line));
      assert.ok(calls.some((args) => JSON.stringify(args) === JSON.stringify(["ship", "status", "--help"])));
    }
  });

  it("detects only the released runtime-log help surface", () => {
    const positive = withFakeEdgeCli({ auth: "api_key", argLog: true });
    const available = JSON.parse(run(["edge-doctor", "--json"], positive.env));
    assert.equal(available.ready, true);
    assert.equal(available.runtime_logs_supported, true);
    assert.ok(available.checks.some((check: { name: string; ok: boolean }) =>
      check.name === "Function runtime logs" && check.ok));
    assert.ok(available.next_steps.some((step: string) =>
      step.includes("telnyx-edge logs <function-name> --since 10m --last 200")));
    const calls = readFileSync(positive.argsLog, "utf8").trim().split("\n").map((line) => JSON.parse(line));
    assert.ok(calls.some((args) => JSON.stringify(args) === JSON.stringify(["logs", "--help"])));

    for (const config of [
      { runtimeLogsFunctionUsage: false },
      { runtimeLogsSince: false },
      { runtimeLogsLast: false },
      { runtimeLogsJson: false },
    ]) {
      const fake = withFakeEdgeCli({ auth: "api_key", ...config });
      const data = JSON.parse(run(["edge-doctor", "--json"], fake.env));
      assert.equal(data.ready, true, "runtime logs must remain optional for setup handoffs");
      assert.equal(data.runtime_logs_supported, false);
      assert.ok(data.next_steps.some((step: string) => step.includes("runtime logs")));
    }
  });

  it("requires complete v0.5.3 live-tail and OTLP export help plus current actor metrics help", () => {
    const positive = withFakeEdgeCli({ auth: "api_key", argLog: true });
    const available = JSON.parse(run(["edge-doctor", "--json"], positive.env));
    assert.equal(available.ready, true);
    assert.equal(available.live_log_tail_supported, true);
    assert.equal(available.log_export_supported, true);
    assert.equal(available.actor_metrics_supported, true);
    assert.ok(available.checks.some((check: { name: string; ok: boolean }) =>
      check.name === "Live log tail" && check.ok));
    assert.ok(available.checks.some((check: { name: string; ok: boolean }) =>
      check.name === "OTLP log export" && check.ok));
    assert.ok(available.checks.some((check: { name: string; ok: boolean }) =>
      check.name === "Actor metrics supported" && check.ok));
    assert.ok(available.next_steps.some((step: string) =>
      step.includes("logs <function-name> --tail")));
    assert.ok(available.next_steps.some((step: string) =>
      step.includes("log-export set <function-name> --endpoint https://<otlp-endpoint>")));
    assert.ok(available.next_steps.some((step: string) =>
      step.includes("actors metrics <type> --since 24h")));
    const calls = readFileSync(positive.argsLog, "utf8").trim().split("\n").map((line) => JSON.parse(line));
    for (const expected of [
      ["logs", "--help"],
      ["log-export", "set", "--help"],
      ["log-export", "get", "--help"],
      ["log-export", "delete", "--help"],
      ["actors", "metrics", "--help"],
    ]) {
      assert.ok(calls.some((args) => JSON.stringify(args) === JSON.stringify(expected)), `missing probe ${expected.join(" ")}`);
    }

    const incomplete: Array<[FakeEdgeOptions, string, string]> = [
      [{ liveLogTail: false }, "live_log_tail_supported", "logs <function-name> --tail"],
      [{ logExport: false }, "log_export_supported", "log-export set <function-name>"],
      [{ logExportEndpoint: false }, "log_export_supported", "log-export set <function-name>"],
      [{ logExportHeader: false }, "log_export_supported", "log-export set <function-name>"],
      [{ logExportRuntime: false }, "log_export_supported", "log-export set <function-name>"],
      [{ logExportInvocations: false }, "log_export_supported", "log-export set <function-name>"],
      [{ logExportGetJson: false }, "log_export_supported", "log-export set <function-name>"],
      [{ logExportDeleteYes: false }, "log_export_supported", "log-export set <function-name>"],
      [{ actorMetrics: false }, "actor_metrics_supported", "actors metrics <type>"],
      [{ actorMetricsTypeUsage: false }, "actor_metrics_supported", "actors metrics <type>"],
      [{ actorMetricsSince: false }, "actor_metrics_supported", "actors metrics <type>"],
      [{ actorMetricsJson: false }, "actor_metrics_supported", "actors metrics <type>"],
    ];
    for (const [config, capability, suggestion] of incomplete) {
      const fake = withFakeEdgeCli({ auth: "api_key", ...config });
      const data = JSON.parse(run(["edge-doctor", "--json"], fake.env));
      assert.equal(data.ready, true, "freshness capabilities remain optional for setup handoffs");
      assert.equal(data[capability], false, `partial help must not report ${capability} as supported`);
      assert.ok(!data.next_steps.some((step: string) => step.includes(suggestion)));
    }
  });

  it("requires complete v0.5.2 observability and deployment-history help surfaces", () => {
    const positive = withFakeEdgeCli({ auth: "api_key", argLog: true });
    const available = JSON.parse(run(["edge-doctor", "--json"], positive.env));
    assert.equal(available.ready, true);
    assert.equal(available.invocation_logs_supported, true);
    assert.equal(available.function_metrics_supported, true);
    assert.equal(available.deployments_supported, true);
    assert.ok(available.next_steps.some((step: string) =>
      step.includes("logs <function-name> --type invocations --since 10m --last 200")));
    assert.ok(available.next_steps.some((step: string) =>
      step.includes("metrics <function-name> --since 24h")));
    assert.ok(available.next_steps.some((step: string) =>
      step.includes("deployments <function-name>")));
    const calls = readFileSync(positive.argsLog, "utf8").trim().split("\n").map((line) => JSON.parse(line));
    for (const expected of [["logs", "--help"], ["metrics", "--help"], ["deployments", "--help"]]) {
      assert.ok(calls.some((args) => JSON.stringify(args) === JSON.stringify(expected)), `missing probe ${expected.join(" ")}`);
    }

    const incomplete = [
      [{ invocationLogsType: false }, "invocation_logs_supported", "logs <function-name> --type invocations"],
      [{ invocationLogsRuntime: false }, "invocation_logs_supported", "logs <function-name> --type invocations"],
      [{ invocationLogsInvocations: false }, "invocation_logs_supported", "logs <function-name> --type invocations"],
      [{ runtimeLogsSince: false }, "invocation_logs_supported", "logs <function-name> --type invocations"],
      [{ runtimeLogsLast: false }, "invocation_logs_supported", "logs <function-name> --type invocations"],
      [{ metrics: false }, "function_metrics_supported", "metrics <function-name>"],
      [{ metricsFunctionUsage: false }, "function_metrics_supported", "metrics <function-name>"],
      [{ metricsSince: false }, "function_metrics_supported", "metrics <function-name>"],
      [{ metricsErrors: false }, "function_metrics_supported", "metrics <function-name>"],
      [{ metricsJson: false }, "function_metrics_supported", "metrics <function-name>"],
      [{ deployments: false }, "deployments_supported", "deployments <function-name>"],
      [{ deploymentsFunctionUsage: false }, "deployments_supported", "deployments <function-name>"],
      [{ deploymentsJson: false }, "deployments_supported", "deployments <function-name>"],
      [{ deploymentsFailureReason: false }, "deployments_supported", "deployments <function-name>"],
    ] as const;
    for (const [config, capability, suggestion] of incomplete) {
      const fake = withFakeEdgeCli({ auth: "api_key", ...config });
      const data = JSON.parse(run(["edge-doctor", "--json"], fake.env));
      assert.equal(data.ready, true, "v0.5.2 observability remains optional for setup handoffs");
      assert.equal(data[capability], false, `partial help must not report ${capability} as supported`);
      assert.ok(!data.next_steps.some((step: string) => step.includes(suggestion)));
    }
  });

  it("requires complete SQL export and standard-input help surfaces", () => {
    const positive = withFakeEdgeCli({ auth: "api_key", argLog: true });
    const available = JSON.parse(run(["edge-doctor", "--json"], positive.env));
    assert.equal(available.ready, true);
    assert.equal(available.sql_database_export_supported, true);
    assert.equal(available.sql_stdin_import_supported, true);
    assert.ok(available.next_steps.some((step: string) =>
      step.includes("storage sqldb export <source-database> --remote --output - | telnyx-edge storage sqldb execute <destination-database> --remote --file -")));
    const calls = readFileSync(positive.argsLog, "utf8").trim().split("\n").map((line) => JSON.parse(line));
    assert.ok(calls.some((args) => JSON.stringify(args) === JSON.stringify(["storage", "sqldb", "export", "--help"])));
    assert.ok(calls.some((args) => JSON.stringify(args) === JSON.stringify(["storage", "sqldb", "execute", "--help"])));

    for (const [config, exportSupported, stdinSupported] of [
      [{ sqlDatabaseExport: false }, false, true],
      [{ sqlDatabaseExportNoSchema: false }, false, true],
      [{ sqlDatabaseExportStdout: false }, false, true],
      [{ sqlStdinImport: false }, true, false],
    ] as const) {
      const fake = withFakeEdgeCli({ auth: "api_key", ...config });
      const data = JSON.parse(run(["edge-doctor", "--json"], fake.env));
      assert.equal(data.ready, true, "SQL export/import must remain optional for setup handoffs");
      assert.equal(data.sql_database_export_supported, exportSupported);
      assert.equal(data.sql_stdin_import_supported, stdinSupported);
      assert.equal(data.next_steps.some((step: string) => step.includes('--output - |')), exportSupported && stdinSupported);
    }
  });

  it("requires both SQL parameter flags without changing SQL or handoff compatibility", () => {
    for (const config of [
      { sqlParam: false },
      { sqlParamJson: false },
    ]) {
      const fake = withFakeEdgeCli({ auth: "api_key", ...config });
      const data = JSON.parse(run(["edge-doctor", "--json"], fake.env));
      assert.equal(data.ready, true, "bound SQL parameters remain optional for setup handoffs");
      assert.equal(data.sql_databases_supported, true, "the existing SQL compatibility field is unchanged");
      assert.equal(data.sql_bound_parameters_supported, false);
      assert.ok(data.next_steps.some((step: string) => step.includes("SQL --param/--param-json bindings")));
    }
  });

  it("detects the complete v0.5.0 custom-domain help surfaces", () => {
    const fake = withFakeEdgeCli({ auth: "api_key", argLog: true });
    const data = JSON.parse(run(["edge-doctor", "--json"], fake.env));
    assert.equal(data.ready, true);
    assert.equal(data.custom_domains_supported, true);
    assert.ok(data.checks.some((check: { name: string; ok: boolean }) =>
      check.name === "Custom domains" && check.ok));
    assert.ok(data.next_steps.some((step: string) => step.includes("telnyx-edge domains add")));
    const calls = readFileSync(fake.argsLog, "utf8").trim().split("\n").map((line) => JSON.parse(line));
    for (const expected of [
      ["domains", "--help"],
      ["domains", "cert", "upload", "--help"],
      ["domains", "delete", "--help"],
    ]) {
      assert.ok(calls.some((args) => JSON.stringify(args) === JSON.stringify(expected)), `missing probe ${expected.join(" ")}`);
    }
  });

  it("rejects partial custom-domain help without affecting core handoff readiness", () => {
    const allCommands: NonNullable<FakeEdgeOptions["customDomainCommands"]> = ["add", "verify", "list", "delete", "cert"];
    const partialConfigs: FakeEdgeOptions[] = [
      ...allCommands.map((missing) => ({
        customDomainCommands: allCommands.filter((command) => command !== missing),
      })),
      { customDomainCertUpload: false },
      { customDomainCertFlag: false },
      { customDomainKeyFlag: false },
      { customDomainDeleteYes: false },
    ];
    for (const config of partialConfigs) {
      const fake = withFakeEdgeCli({ auth: "api_key", ...config });
      const data = JSON.parse(run(["edge-doctor", "--json"], fake.env));
      assert.equal(data.ready, true, "custom domains must remain optional for setup handoffs");
      assert.equal(data.custom_domains_supported, false);
      assert.ok(data.next_steps.some((step: string) =>
        step.includes("Optional capabilities not detected") && step.includes("custom domains")));
    }
  });

  it("detects types support from the documented manifest wording", () => {
    const fake = withFakeEdgeCli({
      typesHelp: "Generate types for your environment from the manifest in TypeScript (telnyx-env.d.ts)",
    });
    const data = JSON.parse(run(["edge-doctor", "--json"], fake.env));
    assert.equal(data.types_supported, true);
  });

  it("rejects generic TypeScript help without a types-generation indicator", () => {
    const fake = withFakeEdgeCli({
      typesHelp: "Compile JavaScript modules; TypeScript projects are supported",
    });
    const data = JSON.parse(run(["edge-doctor", "--json"], fake.env));
    assert.equal(data.types_supported, false);
  });

  it("probes reset-func --yes independently from delete-func --yes", () => {
    const deleteOnly = withFakeEdgeCli({
      resetFunc: true,
      resetNoninteractiveConfirmation: false,
      noninteractiveConfirmation: true,
    });
    const withoutResetYes = JSON.parse(run(["edge-doctor", "--json"], deleteOnly.env));
    assert.equal(withoutResetYes.noninteractive_confirmation_supported, true);
    assert.equal(withoutResetYes.reset_func_noninteractive_confirmation_supported, false);
    assert.ok(withoutResetYes.next_steps.some((step: string) => step.includes("reset-func <function-name>")));
    assert.ok(!withoutResetYes.next_steps.some((step: string) => step.includes("reset-func <function-name> --yes")));

    const resetOnly = withFakeEdgeCli({
      resetFunc: true,
      resetNoninteractiveConfirmation: true,
      noninteractiveConfirmation: false,
    });
    const withResetYes = JSON.parse(run(["edge-doctor", "--json"], resetOnly.env));
    assert.equal(withResetYes.noninteractive_confirmation_supported, false);
    assert.equal(withResetYes.reset_func_noninteractive_confirmation_supported, true);
    const resetStep = withResetYes.next_steps.find((step: string) => step.includes("reset-func <function-name> --yes"));
    assert.ok(resetStep);
    const resetCommand = resetStep.slice(resetStep.indexOf(": ") + 2);
    assert.doesNotMatch(resetCommand, /\([^)]*\)/, "copyable reset command must not contain inline annotations");
    assert.doesNotThrow(() => execFileSync("/bin/sh", ["-n", "-c", resetCommand]));
  });

  it("requires every capability emitted by setup handoffs", () => {
    for (const missing of ["newFuncFromDir", "secretsAdd", "ship"] as const) {
      const fake = withFakeEdgeCli({ auth: "api_key", [missing]: false });
      const doctor = JSON.parse(run(["edge-doctor", "--json"], fake.env));
      assert.equal(doctor.authenticated, true);
      assert.equal(doctor.root_status_passed, true);
      assert.equal(doctor.ready, false);
      assert.ok(doctor.next_steps.some((step: string) => step.includes("Upgrade telnyx-edge")));
      for (const command of ["setup-edge-mcp", "setup-edge-webhook"]) {
        const data = JSON.parse(run([command, "--json"], fake.env));
        assert.equal(data.ready, false, `${command} must reject missing ${missing}`);
        assert.equal(data.root_status_passed, true);
        assert.equal(data[missing === "newFuncFromDir" ? "new_func_from_dir_supported" : missing === "secretsAdd" ? "secrets_add_supported" : "ship_supported"], false);
        assert.ok(data.next_steps.some((step: string) => step.includes("Upgrade telnyx-edge")));
      }
    }
  });

  it("setup handoffs require the root status success marker", () => {
    const fake = withFakeEdgeCli({ auth: "api_key", rootStatus: "fail" });
    for (const command of ["setup-edge-mcp", "setup-edge-webhook"]) {
      const data = JSON.parse(run([command, "--json"], fake.env));
      assert.equal(data.authenticated, true);
      assert.equal(data.root_status_passed, false);
      assert.equal(data.ready, false);
      assert.ok(data.next_steps.some((step: string) => step.includes("telnyx-edge status")));
    }
  });

  it("setup-edge-mcp emits a repository-aware secure build/deploy/inspect flow", () => {
    const fake = withFakeEdgeCli("api_key");
    const output = run(["setup-edge-mcp", "--json", "--name", "demo-mcp"], {
      ...fake.env,
      SHARED_SECRET: "must-not-appear-in-output",
    });
    const data = JSON.parse(output);
    assert.equal(data.ready, true);
    assert.equal(data.telnyx_edge_installed, true);
    assert.equal(data.root_status_passed, true);
    assert.equal(data.new_func_from_dir_supported, true);
    assert.equal(data.secrets_add_supported, true);
    assert.equal(data.ship_supported, true);
    assert.equal(data.inspect_supported, true);
    assert.equal(data.actor_instances_supported, true);
    assert.equal(data.source_repo, "https://github.com/team-telnyx/edge-compute.git");
    assert.equal(data.source_path, "examples/ts/mcp-server");
    assert.ok(data.deploy_command.includes("git clone --depth 1"));
    assert.ok(data.deploy_command.includes("npm install"));
    assert.ok(data.deploy_command.includes("npm run build"));
    assert.ok(data.deploy_command.includes('secrets add TELNYX_API_KEY "$TELNYX_API_KEY"'));
    assert.ok(data.deploy_command.includes('secrets add SHARED_SECRET "$SHARED_SECRET"'));
    assert.ok(data.deploy_command.includes("telnyx-edge ship"));
    assert.ok(data.deploy_command.includes("telnyx-edge inspect demo-mcp"));
    assert.ok(!data.deploy_command.includes("<your-api-key>"));
    assert.ok(data.next_steps.some((step: string) => step.includes("Authorization: Bearer $SHARED_SECRET")));
    assert.ok(!data.next_steps.some((step: string) => step.includes("Bearer ***")));
    assert.ok(!output.includes("must-not-appear-in-output"));
  });

  it("setup-edge-webhook emits a repository-aware HMAC-secured deploy/inspect flow", () => {
    const fake = withFakeEdgeCli("api_key");
    const data = JSON.parse(run(["setup-edge-webhook", "--json", "--name", "demo-webhook"], fake.env));
    assert.equal(data.ready, true);
    assert.equal(data.source_path, "examples/js/webhook-receiver");
    assert.ok(data.deploy_command.includes("git clone --depth 1"));
    assert.ok(data.deploy_command.includes('secrets add WEBHOOK_SECRET "$WEBHOOK_SECRET"'));
    assert.ok(data.deploy_command.includes("telnyx-edge ship"));
    assert.ok(data.deploy_command.includes("telnyx-edge inspect demo-webhook"));
    assert.ok(data.notes.some((note: string) => note.includes("HMAC-SHA256")));
    assert.ok(data.next_steps.some((step: string) => step.includes("HMAC-sign")));
  });

  it("setup handoffs omit inspect from executable flows when the authenticated CLI does not support it", () => {
    const fake = withFakeEdgeCli({ auth: "api_key", inspect: false });
    for (const [command, name] of [
      ["setup-edge-mcp", "demo-mcp"],
      ["setup-edge-webhook", "demo-webhook"],
    ]) {
      const data = JSON.parse(run([command, "--json", "--name", name], fake.env));
      assert.equal(data.authenticated, true);
      assert.equal(data.ready, true);
      assert.equal(data.inspect_supported, false);
      assert.ok(data.deploy_command.includes("telnyx-edge ship"));
      assert.ok(!data.deploy_command.includes("telnyx-edge inspect"));
      assert.ok(!data.setup_commands.some((step: string) => step.includes("telnyx-edge inspect")));
    }
  });

  it("setup handoffs conservatively reject unknown auth output", () => {
    const fake = withFakeEdgeCli({ auth: "unknown" });
    for (const command of ["setup-edge-mcp", "setup-edge-webhook"]) {
      const data = JSON.parse(run([command, "--json"], fake.env));
      assert.equal(data.authenticated, false);
      assert.equal(data.auth_mode, "unknown");
      assert.equal(data.ready, false);
    }
  });

  it("validates Edge function names before building shell commands", () => {
    const fake = withFakeEdgeCli("api_key");
    const leadingDash = runError(["setup-edge-mcp", "--json", "--name", "-bad"], fake.env);
    assert.match(leadingDash, /Invalid Edge function name/);
    const injection = runError(["setup-edge-webhook", "--json", "--name", "bad;touch-pwned"], fake.env);
    assert.match(injection, /Invalid Edge function name/);
    const tooLong = runError(["setup-edge-mcp", "--json", "--name", "a".repeat(65)], fake.env);
    assert.match(tooLong, /1–64/);
  });
});
